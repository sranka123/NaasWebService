package com.safelogic.naas.ach.manager.web.customer.group;

import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.safelogic.naas.ach.manager.web.model.AccountHolder;
import com.safelogic.naas.ach.manager.web.model.Customer;
import com.safelogic.naas.ach.manager.web.model.NaasEntity;

@Entity
@Table(name="customer_group")
public class CustomerGroup extends NaasEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4517413292537345288L;
	

	@ManyToOne
	@JoinColumn(name="ach_id")
	AccountHolder accountHolder;
	
	@OneToMany(mappedBy = "customerGroup", fetch=FetchType.EAGER, cascade = CascadeType.ALL)
	List<ConditionLine> conditionLines;
	
	@ManyToMany(cascade=CascadeType.ALL)
    @JoinTable(name="customer_group_mapping", joinColumns=@JoinColumn(name="group_id"),inverseJoinColumns= @JoinColumn(name="customer_id"))
	List<Customer> customers = null;

	public CustomerGroup() {
		super();
	}
	public AccountHolder getAccountHolder() {
		return accountHolder;
	}

	public void setAccountHolder(AccountHolder accountHolder) {
		this.accountHolder = accountHolder;
	}

	public List<ConditionLine> getConditionLines() {
		return conditionLines;
	}

	public void setConditionLines(List<ConditionLine> conditionLines) {
		this.conditionLines = conditionLines;
	}
	
	
	public List<Customer> getCustomers() {
		return customers;
	}

	
	public void setCustomers(List<Customer> customers) {
		this.customers = customers;
	}
	
	public String getSQLQuery() {
		
		StringBuffer sqlQuery  = new StringBuffer();
		
		sqlQuery.append("select id, firstName, lastName, useEmail, emailId, usePhone, phoneNumber ")
				.append(" from customer ")
				.append(getSQLWhereClause());		

		return sqlQuery.toString();
	}
	
	public String getSQLWhereClause() {
		
		StringBuffer sqlQuery  = new StringBuffer(" where ");

		String whereClause = getConditionLines().stream().map(ConditionLine::getSQLWhereClause).collect(Collectors.joining(" and "));
		sqlQuery.append(whereClause);//hack for now
		
		sqlQuery.append(" and ")
		.append(" ach_id = ")
		.append(accountHolder.getId());

		return sqlQuery.toString();
	}

}
