/**
 * 
 */
package com.safelogic.naas.ach.manager.web.service;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.StringReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.HashMap;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.xml.sax.InputSource;

import com.safelogic.naas.ach.manager.web.customer.group.Field;
import com.safelogic.naas.ach.manager.web.util.XMLUtil;

public class BulkUploadService {
	
	public Map<String, Field> getFieldMap() throws Exception {
		
		Map<String, Field> fieldMap = new HashMap<String, Field>();
		
		Connection connection = null;
		try {
			connection = getConnection();
			PreparedStatement ps = connection.prepareStatement("SELECT * FROM naas_db.field;");
			
			ResultSet rs = ps.executeQuery();
			Field field = null;
			while(rs.next()) {
				field = new Field();
				
				field.setId(rs.getInt("id"));
				field.setName(rs.getString("name"));
				field.setDisplayText(rs.getString("display_text"));
				field.setxPath(rs.getString("xpath"));
				field.setMetadata(rs.getBoolean("isMetaData"));
				
				fieldMap.put(field.getName(), field);
			}
			
			System.out.println("Got FieldMap !!! " + fieldMap);
		} catch (Exception e) {
			e.printStackTrace(); 
			throw e;
		} finally {
			try {
				
				if(connection != null)
					connection.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		
		return fieldMap;
	}
	
	public static Connection getConnection() throws Exception {
		Connection dbConnection = null;		
			
		Class.forName("com.mysql.jdbc.Driver");
		dbConnection = DriverManager.getConnection("jdbc:mysql://localhost:3306/naas_db", "naas_root", "xxxxxx");
		
		return dbConnection;
	}
	

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		/**
		 * 1. Load fields from database to a Map
		 * 2. Read input file
		 * 3. Generate insert statements (Customer basic columns and metadata)
		 */
	
		FileReader reader = null;
		Connection connection = null;
		try {
			BulkUploadService buService = new BulkUploadService();
			Map<String, Field> fieldMap = buService.getFieldMap();
			System.out.println("fieldMap size - " + fieldMap.size());
			
			reader = new FileReader("C:/Projects/NAAS/AustinInfinit_Data/GoLive_Data/AI-Finance_2015-09-01_2016-09-05.txt");
			
			BufferedReader br = new BufferedReader(reader);
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();  
		    DocumentBuilder builder = factory.newDocumentBuilder();  
		    
			String dataRec = null;
			String data[] = null;
			String columnName[] = null;
			int  rowId = 0;
			Field field = null;
			String xpath = null;
			Document metadataDoc = null;
			String sql = null;
					
			//"INSERT INTO naas_db.customer (firstName, lastName, middleName, emailId, phoneNumber, useEmail, usePhone, " + 
					//" accountHolder_ach_id, address1, address2, city, state, zipcode, metadata) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?);";
			
			connection = getConnection();
			PreparedStatement ps = null;
			while((dataRec = br.readLine()) != null) {
				rowId++;
				
				if(rowId == 1) {
					columnName = dataRec.split("\t");
					System.out.println("columnName length - " + columnName.length);
					
					StringBuffer selectColumns = new StringBuffer("accountHolder_ach_id,");
					StringBuffer valueSubstitue = new StringBuffer("?,");
					for(int i=0; i<columnName.length; i++) {
						field = fieldMap.get(columnName[i]);
						if(field != null && !field.isMetadata()) {
							selectColumns.append(field.getName());
							selectColumns.append(",");
							
							valueSubstitue.append("?");
							valueSubstitue.append(",");
						}
					}
					
					
					selectColumns.append("metadata");
					valueSubstitue.append("?");
					
					sql = "INSERT INTO naas_db.customer (" + selectColumns.toString() + ") VALUES(" + valueSubstitue.toString() + ");";
					System.out.println("sql: " + sql);
					
					ps = connection.prepareStatement(sql);
					
					continue;
				}
				
				data = dataRec.split("\t");
				if(columnName.length != data.length) {
					System.out.println("Data record length does not match with the column name length. Ignoring this data record - " + rowId);
					continue;
				}
				
			    metadataDoc = builder.parse( new InputSource( new StringReader( "<metaData />" ) ) ); 
		        ps.setInt(1, 1); // set account it
		        int idx = 1;
				for(int i=0; i<columnName.length; i++) {
					field = fieldMap.get(columnName[i]);
					if(field == null) {
						xpath = "/metaData/other/" + columnName[i];
					} else if(field.isMetadata()) {
						xpath = field.getxPath();
					}
					
					if(xpath != null) {
						XMLUtil.setElementValueUsingXpath(metadataDoc, xpath, data[i]);
					}
					
					if(!field.isMetadata()){
						ps.setString(++idx, data[i]);
					}
				}
				
				ps.setString(++idx, XMLUtil.toString(metadataDoc));
				ps.addBatch();
				System.out.println("metadata added: " + rowId);
				
				/*
				if(rowId > 3) {
					break;
				}
				*/
				
			}
			
			if(ps != null) {
				ps.executeBatch();
				System.out.println("Batch inserted executed successfull !!! ");
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				
				if(connection != null)
					connection.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		

	}

}
