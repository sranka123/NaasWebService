package com.safelogic.naas.ach.manager.web.controller;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.safelogic.naas.ach.manager.web.NaasException;
import com.safelogic.naas.ach.manager.web.NaasURIConstants;
import com.safelogic.naas.ach.manager.web.customer.group.ConditionLine;
import com.safelogic.naas.ach.manager.web.customer.group.ConditionLineTO;
import com.safelogic.naas.ach.manager.web.customer.group.CustomerGroup;
import com.safelogic.naas.ach.manager.web.customer.group.CustomerGroupTO;
import com.safelogic.naas.ach.manager.web.customer.group.DataType;
import com.safelogic.naas.ach.manager.web.customer.group.Field;
import com.safelogic.naas.ach.manager.web.customer.group.Operator;
import com.safelogic.naas.ach.manager.web.dao.AccountHolderDAO;
import com.safelogic.naas.ach.manager.web.model.AccountHolder;
import com.safelogic.naas.ach.manager.web.model.Customer;
import com.safelogic.naas.ach.manager.web.model.CustomerGroupBasicInfo;
import com.safelogic.naas.ach.manager.web.service.CustomerGroupService;

@RestController
@RequestMapping(value=NaasURIConstants.customerGroupBase)
public class CustomerGroupRestController {
	
	private Logger logger = LoggerFactory.getLogger(CustomerGroupRestController.class);
	
	@Autowired
	private CustomerGroupService customerGroupService;
	
	private AccountHolderDAO accountHolderDao;
	
	@RequestMapping(value="/getAllFields", method=RequestMethod.GET, produces=MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody List<Field> getAllFields(HttpSession session){
		System.out.println("In getAllFields... ");
		
		Map<Long, Field> fieldMap = getFieldMap(session);
		
		System.out.println("fields size: " + fieldMap.size());
		List<Field> fieldList = new ArrayList<Field>();
		fieldList.addAll(fieldMap.values());
		
		sortFieldListByName(fieldList);
		
		return fieldList;
	}
	
	@RequestMapping(value="/getOperatorsForFieldId", method=RequestMethod.GET, produces=MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody List<Operator> getOperatorsForFieldId(HttpSession session, long fieldId){
		System.out.println("In getOperatorsForField... fieldId=" + fieldId);
		
		Map<Long, Field> fieldMap = getFieldMap(session);
		Map<Long, DataType> dataTypeMap = getDataTypeMap(session);
		
		Field field = fieldMap.get(fieldId);
		
		return dataTypeMap.get(field.getDataType().getId()).getOperators();
	}
	
	@RequestMapping(value="/getAllDataTypes", method=RequestMethod.POST, produces=MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody List<DataType> getAllDataTypes(){
		System.out.println("In getAllDataTypes... ");
		
		List<DataType> dataTypes = customerGroupService.getAllDataTypes();		
		return dataTypes;
	}
	// Redundant Code due to change in DB structure and Request structure
	/*@RequestMapping(value="/saveCustomerGroup", method=RequestMethod.POST)
	public @ResponseBody String saveCustomerGroup(@RequestParam String conditions, @RequestParam String name, 
			HttpSession session, @AuthenticationPrincipal NaasAccountHolderUser currentUser){
		System.out.println("In saveCustomerGroup... ");
		
		CustomerGroup searchQuery = (CustomerGroup) session.getAttribute("searchQuery");
		String loggedInUser = (String) session.getAttribute("loggedInUser");
		AccountHolder accountHolder = (AccountHolder) session.getAttribute("accountHolder");
		
		String pageAction = (String) session.getAttribute("pageAction");
		
		if(pageAction.equals("new")) {
			searchQuery = new CustomerGroup();
			searchQuery.setAccountHolder(accountHolder);
			searchQuery.setCreateDate(new Date());
			searchQuery.setCreatedByUser(loggedInUser);
		}
		
		searchQuery.setName(name);
		populateConditionLines(conditions, session, searchQuery);
		
		searchQuery.setModifiedDate(new Date());
		searchQuery.setModifiedByUser(loggedInUser);
		
		if(pageAction.equals("new")) {
			searchQuery = customerGroupService.createCustomerGroup(searchQuery);
		} else {
			searchQuery = customerGroupService.updateCustomerGroup(searchQuery);
		}
		
		session.setAttribute("searchQuery", searchQuery);
		session.setAttribute("pageAction", "edit");
		
		System.out.println("Sql Query: " + searchQuery.getSQLQuery());
		
		return "Customer Group Saved";
	}*/
	
	@RequestMapping(value="/showCustomers", method=RequestMethod.POST, produces=MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody List<Customer> showCustomers(@RequestParam String conditions, HttpSession session){
		System.out.println("In showCustomers... ");
		
		CustomerGroup searchQuery = new CustomerGroup();
		searchQuery.setAccountHolder((AccountHolder)session.getAttribute("accountHolder"));
		populateConditionLines(conditions, session, searchQuery);
		System.out.println("Number of conditions: " + searchQuery.getConditionLines().size());
		
		if(searchQuery.getConditionLines().size() == 0) {
			return new ArrayList<Customer>();
		}
		
		String sqlWhereClause = searchQuery.getSQLWhereClause();
		System.out.println("Sql Where Clause: " + sqlWhereClause);
		List<Customer> customers = customerGroupService.getCustomers(sqlWhereClause);
		
		return customers;
	}
	
	@RequestMapping(value="/list",method=RequestMethod.GET ,produces = {MediaType.APPLICATION_JSON_VALUE})
	public List<CustomerGroupBasicInfo> getAllCustomerGroups(@RequestHeader("achId") Long achId){

		if(null == achId) {
			logger.error("GetAllCustomerGroups method with no account holder id info in the request");
			throw new NaasException("Invalid Data for GetAllCustomerGroups. Please contact support.");
		}
		AccountHolder accountHolder = accountHolderDao.findById(achId);
		if(null == accountHolder) {
			logger.error("createCustomerGroup-Could not find account holder for achId = "+achId);
			throw new NaasException("Could not find account holder information for achId = "+achId+" , Please contact support.");
		}
		return customerGroupService.getAllCustomerGroups(achId);
	}

	@RequestMapping(value="/createCustomerGroup", method=RequestMethod.POST,consumes = MediaType.APPLICATION_JSON_VALUE,produces= MediaType.APPLICATION_JSON_VALUE)
	public Long createCustomerGroup(@RequestHeader("achId")Long achId,@RequestBody CustomerGroupTO customerGroupRequest,HttpSession session) throws NaasException {
		
		
		if(null == achId || null == customerGroupRequest || StringUtils.isBlank(customerGroupRequest.getName()) || null == customerGroupRequest.getConditionLines() || customerGroupRequest.getConditionLines().isEmpty()) {
			logger.error("createCustomerGroup - Invalid Request Information for Create Customer Group Service.");
			throw new NaasException("Invalid Data for Create Customer Group. Please contact support.");
		}
		logger.debug("createCustomerGroup request with achId = "+achId+" , groupName = "+customerGroupRequest.getName()+" ,size of conditionlines "+customerGroupRequest.getConditionLines().size());
		AccountHolder accountHolder = accountHolderDao.findById(achId);
		if(null == accountHolder) {
			logger.error("createCustomerGroup-Could not find account holder for achId = "+achId);
			throw new NaasException("Could not find account holder information for achId = "+achId+" , Please contact support.");
		}
		
		try {

			CustomerGroup customerGroup = new CustomerGroup();
			customerGroup.setAccountHolder(accountHolder);
			customerGroup.setCreateDate(new Date());
			customerGroup.setModifiedDate(new Date());
			customerGroup.setName(customerGroupRequest.getName());
			populateConditionLines(customerGroupRequest.getConditionLines(), session, customerGroup);

			CustomerGroup response = customerGroupService.createCustomerGroup(customerGroup);
			if(null == response)
			{
				return 0L;
			}
			logger.debug("Customer Group "+response.getName()+" ,Saved with Id = " + response.getId());
			return response.getId();

		} catch (Exception exp) {
			logger.error("Error happened in Create Customer Group for achId = " + achId, exp);
			throw new NaasException(
					"Error happened in Create Customer Group for achId = " + achId + " , Please contact support.");
		}
	}
	
	@RequestMapping(value="/update", method=RequestMethod.POST,consumes = MediaType.APPLICATION_JSON_VALUE,produces= MediaType.APPLICATION_JSON_VALUE)
	public CustomerGroupTO updateCustomerGroup(@RequestHeader("achId") Long achId,
			@RequestBody CustomerGroupTO customerGroupRequest, HttpSession session) throws NaasException {

		if (null == achId || null == customerGroupRequest || StringUtils.isBlank(customerGroupRequest.getName())
				|| null == customerGroupRequest.getConditionLines()
				|| customerGroupRequest.getConditionLines().isEmpty()) {
			logger.error("updateCustomerGroup - Invalid Data Passed.");
			throw new NaasException("Invalid Data for Update Customer Group. Please contact support.");
		}
		logger.debug(
				"updateCustomerGroup request with achId = " + achId + " , groupName = " + customerGroupRequest.getName()
						+ " ,size of conditionlines " + customerGroupRequest.getConditionLines().size());
		AccountHolder accountHolder = accountHolderDao.findById(achId);
		if (null == accountHolder) {
			logger.error("updateCustomerGroup-Could not find account holder for achId = " + achId);
			throw new NaasException(
					"Could not find account holder information for achId = " + achId + " , Please contact support.");
		}

		try {
			CustomerGroup customerGroup = customerGroupService.getCustomerGroup(customerGroupRequest.getId());
			if (customerGroup == null) {
				logger.error("Invalid group id passed in update customer group = " + customerGroupRequest.getId());
				throw new NaasException("Could not find customer group for groupId = " + customerGroupRequest.getId()
						+ " , Please contact support.");
			}
			customerGroup.setAccountHolder(accountHolder);
			customerGroup.setModifiedDate(new Date());
			customerGroup.setName(customerGroupRequest.getName());
			populateConditionLines(customerGroupRequest.getConditionLines(), session, customerGroup);

			customerGroupService.updateCustomerGroup(customerGroup);
			logger.debug("Updated Customer Group " + customerGroup.getName());
			return customerGroupRequest;

		} catch (Exception exp) {
			logger.error("Error happened in Create Customer Group for achId = " + achId, exp);
			throw new NaasException(
					"Error happened in Create Customer Group for achId = " + achId + " , Please contact support.");
		}
	}
	
	@RequestMapping(value="/delete",method=RequestMethod.DELETE,produces = {MediaType.APPLICATION_JSON_VALUE})
	public Boolean deleteCustomerGroup(@RequestHeader("groupId") Long groupId, @RequestHeader("achId") Long achId){

		if(null == groupId && null == achId) {
			logger.error("deleteCustomerGroup method with no account holder id or customer groupId in the request");
			return false;
		}
		return customerGroupService.deleteCustomerGroup(groupId);

	}
	private void populateConditionLines(List<ConditionLineTO> conditionLineInput, HttpSession session, CustomerGroup customerGroup) throws NaasException
	{
		Map<Long, Field> fieldMap = getFieldMap(session);
		Map<Long, Operator> operatorMap = getOperatorMap(session);
		List<ConditionLine> conditionLines = new ArrayList<ConditionLine>();
		customerGroup.setConditionLines(conditionLines);
		ConditionLine conditionLine = null;
		for(ConditionLineTO conditionIn: conditionLineInput) {
			conditionLine = new ConditionLine();
			conditionLines.add(conditionLine);
			conditionLine.setCustomerGroup(customerGroup);
			
			Field field = fieldMap.get(conditionIn.getFieldId());			
			Operator operator = operatorMap.get(conditionIn.getOperatorId());
			if(null == field || null == operator || StringUtils.isBlank(conditionIn.getValueText()))
			{
				logger.debug("createCustomerGroup-Invalid data for condition lines for customer group "+customerGroup.getName()+" ,fieldId="+conditionIn.getFieldId()+" ,op="+conditionIn.getOperatorId()+" ,value="+conditionIn.getValueText());
				throw new NaasException("createCustomerGroup-Invalid data for condition lines for customer group "+customerGroup.getName());
			}
			conditionLine.setField(field);
			conditionLine.setOperator(operator);
			conditionLine.setValueText(conditionIn.getValueText());
		
		}
	}
	
	
	private void populateConditionLines(String conditions, HttpSession session, CustomerGroup customerGroup) {
		Map<Long, Field> fieldMap = getFieldMap(session);
		Map<Long, Operator> operatorMap = getOperatorMap(session);
		List<ConditionLine> conditionsLines = new ArrayList<ConditionLine>();
		customerGroup.setConditionLines(conditionsLines);
		String[] rowArray = conditions.split("\\|");
		String[] conditionLineArray = null;
		ConditionLine conditionLine = null;
		for(String conditionStr: rowArray) {
			conditionLineArray = conditionStr.split("\\^");
			conditionLine = new ConditionLine();
			conditionsLines.add(conditionLine);
			conditionLine.setCustomerGroup(customerGroup);
			
			Field field = fieldMap.get(Long.parseLong(conditionLineArray[0]));			
			Operator operator = operatorMap.get(Long.parseLong(conditionLineArray[1]));			
			conditionLine.setField(field);
			conditionLine.setOperator(operator);
			conditionLine.setValueText(conditionLineArray[2]);
			
		}
	}

	private Map<Long, Field> getFieldMap(HttpSession session) {
		
		Map<Long, Field> fieldMap = (Map<Long, Field>) session.getServletContext().getAttribute("fieldMap");
		if(fieldMap == null){
			List<Field> allFields = customerGroupService.getAllFields();			
			fieldMap = new HashMap<Long, Field>();
			for(Field field: allFields) {
				fieldMap.put(field.getId(), field);
			}

			session.getServletContext().setAttribute("fieldMap", fieldMap);
		}
		
		return fieldMap;
	}
	
	private Map<Long, Operator> getOperatorMap(HttpSession session) {
		
		Map<Long, Operator> operatorMap = (Map<Long, Operator>) session.getServletContext().getAttribute("operatorMap");
		if(operatorMap == null){
			List<Operator> allOperators = customerGroupService.getAllOperators();		
			operatorMap = new HashMap<Long, Operator>();
			for(Operator operator: allOperators) {
				operatorMap.put(operator.getId(), operator);
			}

			session.getServletContext().setAttribute("operatorMap", operatorMap);
		}
		
		return operatorMap;
	}
	
	private Map<Long, DataType> getDataTypeMap(HttpSession session) {
		
		Map<Long, DataType> dataTypeMap = (Map<Long, DataType>) session.getServletContext().getAttribute("dataTypeMap");
		if(dataTypeMap == null){
			List<DataType> allDataTypes = customerGroupService.getAllDataTypes();
			
			dataTypeMap = new HashMap<Long, DataType>();
			for(DataType dataType: allDataTypes) {
				dataTypeMap.put(dataType.getId(), dataType);
			}

			session.getServletContext().setAttribute("dataTypeMap", dataTypeMap);
		}
		
		return dataTypeMap;
	}
	
	private void sortFieldListByName(List<Field> fieldList) {
		
		// Sort the field list by Entity name and Field Display Text
		Collections.sort(fieldList, new Comparator<Field>() {

			@Override
			public int compare(Field f1, Field f2) {
				
				return (f1.getEntityObj().getName() + " " + f1.getDisplayText()).
						compareTo((f2.getEntityObj().getName() + " " + f2.getDisplayText()));
			}
			
		});
	}
	
	@Autowired
	@Qualifier("accountHolderDao")
	public void setAccountHolderDao(AccountHolderDAO naasAccountHolderRepository){
		this.accountHolderDao = naasAccountHolderRepository;
		this.accountHolderDao.setType(AccountHolder.class);
	}
}
