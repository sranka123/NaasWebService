package com.safelogic.naas.ach.manager.web.model;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="account_holder_master")
@AttributeOverrides({
	@AttributeOverride(name = "id", column = @Column(name = "ach_id")),
	@AttributeOverride(name = "name", column = @Column(name = "ach_name"))
})

public class AccountHolder extends NaasEntity{
	
	@Column(name="address1")
	private String address1;
	
	@Column(name="address2")
	private String address2;
	
	@Column(name="city")
	private String city;
	
	@Column(name="state")
	private String state;
	
	@Column(name="zip")
	private String zip;
	
	@Column(name="contact_number")
	private String contactNumber;
	
	@Column(name="email_content_folder_name")
	private String emailContentFolderName;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="industry_mapping_id")
	private Category category;
	

	public AccountHolder() {
		// TODO Auto-generated constructor stub
	}

	public Category getCategory() {
		return category;
	}



	public void setCategory(Category category) {
		this.category = category;
	}



	public String getAddress1() {
		return address1;
	}



	public void setAddress1(String address1) {
		this.address1 = address1;
	}



	public String getAddress2() {
		return address2;
	}



	public void setAddress2(String address2) {
		this.address2 = address2;
	}



	public String getCity() {
		return city;
	}



	public void setCity(String city) {
		this.city = city;
	}



	public String getState() {
		return state;
	}



	public void setState(String state) {
		this.state = state;
	}



	public String getZipCode() {
		return zip;
	}



	public void setZipCode(String zip) {
		this.zip = zip;
	}



	public String getContactNumber() {
		return contactNumber;
	}



	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}

	public String getEmailContentFolderName() {
		return emailContentFolderName;
	}

	public void setEmailContentFolderName(String emailContentFolderName) {
		this.emailContentFolderName = emailContentFolderName;
	}
	
	
}
