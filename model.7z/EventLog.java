package com.safelogic.naas.ach.manager.web.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Immutable;
import org.hibernate.annotations.Type;
import org.joda.time.DateTime;

@Entity
@Table(name="application_log")
@Immutable
public class EventLog {
	
	@Id
	@GeneratedValue
	private long id;
	
	@Column(name="achName")
	private String accountHolderName;
	
	@Column(name="userName")
	private String userName;
	
	@Column(name="eventDate")
	@Type(type="org.jadira.usertype.dateandtime.joda.PersistentDateTime")
	private DateTime eventDateTime;
	
	@Column(name="message")
	private String description;
	
	@Column(name="eventType")
	private String eventType;
	
	@Column(name="entityName")
	private String entityName;
	
	@Column(name="entityId")
	private long entityId;

	
	public EventLog() {
		
	}
	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getAccountHolderName() {
		return accountHolderName;
	}

	public void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public DateTime getEventDateTime() {
		return eventDateTime;
	}

	public void setEventDateTime(DateTime eventDateTime) {
		this.eventDateTime = eventDateTime;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getEventType() {
		return eventType;
	}

	public void setEventType(String eventType) {
		this.eventType = eventType;
	}

	public String getEntityName() {
		return entityName;
	}

	public void setEntityName(String entityName) {
		this.entityName = entityName;
	}

	public long getEntityId() {
		return entityId;
	}

	public void setEntityId(long entityId) {
		this.entityId = entityId;
	}
	
	
	

}
