package com.safelogic.naas.ach.manager.web.service;

import java.util.Collections;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.security.access.annotation.Secured;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.safelogic.naas.ach.manager.web.dao.AccountHolderUserDAO;
import com.safelogic.naas.ach.manager.web.dao.NaasRepository;
import com.safelogic.naas.ach.manager.web.model.AccountHolder;
import com.safelogic.naas.ach.manager.web.model.AccountHolderUser;
import com.safelogic.naas.ach.manager.web.model.AccountHolderUserSetup;
import com.safelogic.naas.ach.manager.web.model.Role;
import com.safelogic.naas.ach.manager.web.model.SecurityQuestion;
import com.safelogic.naas.ach.manager.web.security.NaasAccountHolderUser;
import com.safelogic.naas.ach.manager.web.util.Context;

@Service
@Qualifier("accountHolderUserService")
@Transactional
public class AccountHolderUserServiceImpl implements AccountHolderUserService {
	
	private static final Logger logger = LoggerFactory.getLogger(AccountHolderUserServiceImpl.class);
	

	private AccountHolderUserDAO accountHolderUserDao;
	

	private NaasRepository<SecurityQuestion> naasSecurityQuestionRepo;
	
	private NaasRepository<Role> naasRoleRepo;	
	
	private NaasRepository<AccountHolderUserSetup> naasAccountHolderUserSetupRepo;
	
	@Autowired
	@Qualifier("emailService")
	private EmailService emailService;
	
	public AccountHolderUserServiceImpl() {
		
	}
	
	@Override
	@Secured("ROLE_ADMIN")
	public AccountHolderUser createAccountHolderUser(AccountHolderUser accountHolderUser) {

		return accountHolderUserDao.create(accountHolderUser);
	}

	@Override
	public boolean isUserNameUnique(String emailId, AccountHolder accountHolder) {
		AccountHolderUser accountHolderUser = null;
		try{
			accountHolderUser = accountHolderUserDao.getAccountHolderUser(emailId,accountHolder);
		}catch(EmptyResultDataAccessException exp){
			logger.info("userName:{} doest not exist",emailId);
		}
		return accountHolderUser==null?true:false;
	}

	@Override
	public List<String> getSecurityQuestion() {
		return naasSecurityQuestionRepo.findAll().stream().map(securityQuestion -> securityQuestion.getQuestion()).collect(Collectors.toList());
	}

	@Override
	public AccountHolderUser getActiveAccoutHolderUser(String emailId,AccountHolder accountHolder) {
		AccountHolderUser profile = null;
		profile = accountHolderUserDao.getActiveAccoutHolderUser(emailId,accountHolder);
		return profile;
	}

	@Override
	public Role getUserRole(String userName,AccountHolder accountHolder) {
		//TODO: implement this
		throw new RuntimeException("Not yet implemented");

	}

	@Override
	public List<Role> getAllRoles() {
		return naasRoleRepo.findAll();
	}

	@Override
	public AccountHolderUser getAccountHolderUser(String emailId, AccountHolder accountHolder) {
		return accountHolderUserDao.getAccountHolderUser(emailId, accountHolder);
	}

	@Override
	public Role getRole(String roleName) {
		return naasRoleRepo.findByAttribute("name", roleName).get(0);
	}

	@Override
	@Secured("ROLE_ADMIN")
	public void setUpAccountHolderUser(AccountHolderUser accountHolderUser) {
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		if(auth.getPrincipal()instanceof NaasAccountHolderUser){
			NaasAccountHolderUser currentUser = (NaasAccountHolderUser)auth.getPrincipal();
			String adminUserEmailid = currentUser.getUsername();
			String randomPasswordGenerated = accountHolderUser.getPassword();
			
			accountHolderUserDao.create(accountHolderUser);
			
			UUID token = UUID.randomUUID();//UUID.fromString(accountHolderUser.getEmailId());	   
			AccountHolderUserSetup accountHolderUserSetup = new AccountHolderUserSetup();
			accountHolderUserSetup.setAccountHolderUser(accountHolderUser);
			accountHolderUserSetup.setToken(token.toString());
			accountHolderUserSetup.setValidToken(true);
			accountHolderUserSetup.setOneTimePassword(accountHolderUser.getPassword());
			naasAccountHolderUserSetupRepo.create(accountHolderUserSetup);
			
			
			
			String passwordResetLink = Context.getVal().getTokenUrl()+token.toString();
			
			Context.getVal().setAdminEmail(getAdminEmail(accountHolderUser,currentUser,randomPasswordGenerated));
			Context.getVal().setUserEmail(getUserEmail(accountHolderUser,currentUser,passwordResetLink));
			
			logger.debug("reset link: "+passwordResetLink);
			
			//send password to admin user
			List<String> adminToList = Collections.singletonList(adminUserEmailid);
			emailService.sendEmail(adminToList,"", "password for user "+accountHolderUser.getEmailId(), "password: "+randomPasswordGenerated);

			//send password reset link to user
			List<String> userToList = Collections.singletonList(accountHolderUser.getEmailId());
			emailService.sendEmail(userToList,"", "password reset link", passwordResetLink);

		}else{
			logger.error("unauthorized access !!");
		}
	}

	private String getUserEmail(AccountHolderUser accountHolderUser, NaasAccountHolderUser currentUser,
			String passwordResetLink) {
		String email = "To: "+accountHolderUser.getEmailId()+"<br>"+
			"Subject: Set password link<br>"+
			"Your account has been setup successfully. To login please collect your OTP from "+currentUser.getUsername()+"<br>"+
			"<a href='"+passwordResetLink+"'>Click to set your new password</a>";
		return email;
	}

	@Override
	public AccountHolderUser updateAccountHolderUser(AccountHolderUser accountHolderUser) {		
		return accountHolderUserDao.update(accountHolderUser);
	}

	@Override
	public AccountHolderUserSetup getAccountHolderUserSetup(String token) {
		return accountHolderUserDao.getAccountHolderUserSetup(token);
	}

	@Override
	public AccountHolderUserSetup updateAccountHolderUserSetup(AccountHolderUserSetup accountHolderUserSetup) {
		return naasAccountHolderUserSetupRepo.update(accountHolderUserSetup);
	}
	private String getAdminEmail(AccountHolderUser accountHolderUser,NaasAccountHolderUser currentUser, String randomPassword) {
		String email = "To: "+currentUser.getUsername()+"<br>"+
						"Subject: One time password for user "+accountHolderUser.getFirstName()+" "+accountHolderUser.getLastName()+"<br>"+
						"Body: The OTP generated for user id "+accountHolderUser.getEmailId() +
						" is <b>"+randomPassword+"</b>";
		
		
		return email;
	}

	@Override
	public List<AccountHolderUser> getAccountHolderUserByRole(String roleName, AccountHolder accountHolder) {
		return accountHolderUserDao.getAccountHolderUserByRole(roleName, accountHolder);
	}

	@Autowired
	@Qualifier("accountHolderUserDao")
	public void setAccountHolderUserDao(AccountHolderUserDAO naasAccountHolderUserRepository){
		this.accountHolderUserDao = naasAccountHolderUserRepository;
		this.accountHolderUserDao.setType(AccountHolderUser.class);
	}

	@Autowired
	@Qualifier("naasRepository")
	public void setSecurityQuestionRepo(NaasRepository<SecurityQuestion> naasSecurityQuestionRepo){
		this.naasSecurityQuestionRepo = naasSecurityQuestionRepo;
		this.naasSecurityQuestionRepo.setType(SecurityQuestion.class);
	}
	
	@Autowired
	@Qualifier("naasRepository")
	public void setRoleRepo(NaasRepository<Role> naasRoleRepo){
		this.naasRoleRepo = naasRoleRepo;
		this.naasRoleRepo.setType(Role.class);
	}	
	
	@Autowired
	@Qualifier("naasRepository")
	public void setAccountHolderUserSetupRepo(NaasRepository<AccountHolderUserSetup> naasAccountHolderUserSetupRepo){
		this.naasAccountHolderUserSetupRepo = naasAccountHolderUserSetupRepo;
		this.naasAccountHolderUserSetupRepo.setType(AccountHolderUserSetup.class);
	}
}
