package com.safelogic.naas.ach.manager.web.service;

import com.safelogic.naas.ach.manager.web.model.AccountHolder;
import com.safelogic.naas.ach.manager.web.model.AccountHolderUser;

public interface AccountHolderService {
	public void setUpAccountHolder(AccountHolder accountHolder,AccountHolderUser firstAdminUser);
	public AccountHolder getAccountHolder(String name);
}
