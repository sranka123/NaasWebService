package com.safelogic.naas.ach.manager.web.dao;

import java.util.List;

import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.joda.time.DateTime;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.safelogic.naas.ach.manager.web.model.AccountHolder;
import com.safelogic.naas.ach.manager.web.model.Customer;
import com.safelogic.naas.ach.manager.web.model.DeliveredNotification;
import com.safelogic.naas.ach.manager.web.model.Notification;

@Repository("deliveredNotificationDao")
@Transactional(readOnly = true)
public class DeliveredNotifiationDAOImpl extends NaasRepositoryImpl<DeliveredNotification> implements DeliveredNotificationDAO {


	@Override
	public int countOfDeliveredEmails(AccountHolder ach) {
		Query query = em.createQuery("select count(dn.id) from DeliveredNotification dn where dn.accountHolder.id = :ach_id and dn.contentEmail is not null");
		query.setParameter("ach_id", ach.getId());
		return Math.toIntExact((long)query.getSingleResult());
	}

	@Override
	public int countOfDeliveredSmss(AccountHolder ach) {
		Query query = em.createQuery("select count(dn.id) from DeliveredNotification dn where dn.accountHolder.id = :ach_id and dn.contentSms is not null");
		query.setParameter("ach_id", ach.getId());
		return Math.toIntExact((long)query.getSingleResult());
	}

	@Override
	public int countOfDeliveredEmails(AccountHolder ach, DateTime from, DateTime to) {
		Query query = em.createQuery("select count(dn.id) from DeliveredNotification dn"
				+ " where dn.accountHolder.id = :ach_id and dn.contentEmail is not null and dn.createDate>=:fromDate and dn.createDate<=:toDate");
		query.setParameter("ach_id", ach.getId());
		
		query.setParameter("fromDate", from);
		query.setParameter("toDate",to);
		
		return Math.toIntExact((long)query.getSingleResult());
	}

	@Override
	public int countOfDeliveredSmss(AccountHolder ach, DateTime from, DateTime to) {
		Query query = em.createQuery("select count(dn.id) from DeliveredNotification dn"
				+ " where dn.accountHolder.id = :ach_id and dn.contentSms is not null and dn.createDate>=:fromDate and dn.createDate<=:toDate");
		query.setParameter("ach_id", ach.getId());
		
		query.setParameter("fromDate", from);
		query.setParameter("toDate",to);
		
		return Math.toIntExact((long)query.getSingleResult());
	}

	@Override
	public List<Customer> listOfCustomersForDeliveredNotification(Notification notification) {
		throw new RuntimeException("Not implemented");
	}

	@Override
	public List<DeliveredNotification> listOfNotificationDeliveredToCustomer(Customer customer) {
		TypedQuery<DeliveredNotification> query = em.createQuery("select dn from DeliveredNotification dn where dn.customer.id=:customer_id", DeliveredNotification.class);
		query.setParameter("customer_id", customer.getId());
		return query.getResultList();
	}

	@Override
	public int countOfDeliveredEmailsForNotification(Notification notification) {
		throw new RuntimeException("Not implemented");
	}

	@Override
	public int countOfDeliveredSmssForNotification(Notification notification) {
		// TODO Auto-generated method stub
		//return 0;
		throw new RuntimeException("Not implemented yet!!");
	}


}
