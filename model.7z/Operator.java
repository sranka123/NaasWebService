package com.safelogic.naas.ach.manager.web.customer.group;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import com.safelogic.naas.ach.manager.web.model.NaasEntity;

@Entity
@Table(name="operator")
public class Operator extends NaasEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8846628799110318360L;

	@Column(name="display_text")
	private String displayText;
	
	private String symbol;
	
	public Operator() {
		super();
	}

	public String getDisplayText() {
		return displayText;
	}

	public void setDisplayText(String displayText) {
		this.displayText = displayText;
	}

	public String getSymbol() {
		return symbol;
	}

	public void setSymbol(String symbol) {
		this.symbol = symbol;
	}
	

	
}
