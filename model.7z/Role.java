package com.safelogic.naas.ach.manager.web.model;

import static org.hamcrest.CoreMatchers.instanceOf;

import java.util.List;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

import org.hibernate.annotations.LazyCollection;
import org.hibernate.annotations.LazyCollectionOption;

@Entity
@Table(name="role_master")
@AttributeOverrides({
	@AttributeOverride(name = "id", column = @Column(name = "role_id")),
	@AttributeOverride(name = "name", column = @Column(name = "role_name"))
})
public class Role  extends NaasEntity{

	@LazyCollection(LazyCollectionOption.FALSE)
	@ManyToMany
	@JoinTable(name="role_permission_mapping_table", 
				joinColumns= { @JoinColumn(name="role_id")},
				inverseJoinColumns={@JoinColumn(name="permission_id")})
	private List<Permission> permissions;
	
	public Role(){
		
	}

	public List<Permission> getPermissions() {
		return permissions;
	}

	public void setPermissions(List<Permission> permissions) {
		this.permissions = permissions;
	}
	
	@Override
	public boolean equals(Object obj) {
		if(obj instanceof Role){
			Role toCompare = (Role) obj;
			return toCompare.getId() == this.getId() && toCompare.getName().equals(this.getName());
		}
		return false;
	}
	
}
