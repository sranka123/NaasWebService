package com.safelogic.naas.ach.manager.web.model;

import javax.persistence.Entity;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

@Entity
@Table(name="customer")
public class CustomerBasicInfo extends NaasEntity{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -890093634712273663L;
	
	private String firstName;
	
	private String middleName;
	
	private String lastName;
	
	private String emailId;
	
	private String phoneNumber;
	
	private boolean useEmail;
	
	private boolean usePhone;
	
	public CustomerBasicInfo() {
		
	}
	
	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getDisplayName(){
		return firstName + "  " + lastName;
	}
	
	@Override
	public boolean equals(Object obj) {
		   if (obj == null) { return false; }
		   if (obj == this) { return true; }
		   if (obj.getClass() != getClass()) {
		     return false;
		   }
		   NaasEntity rhs = (NaasEntity) obj;
		   return new EqualsBuilder()
		                 .appendSuper(super.equals(obj))
		                 .append(id, rhs.id)
		                 .isEquals();
		  }
	
	@Override
	public int hashCode() {
	     return new HashCodeBuilder(17, 37).
	       append(name).
	       toHashCode();
	   }

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public boolean isUseEmail() {
		return useEmail;
	}

	public void setUseEmail(boolean useEmail) {
		this.useEmail = useEmail;
	}

	public boolean isUsePhone() {
		return usePhone;
	}

	public void setUsePhone(boolean usePhone) {
		this.usePhone = usePhone;
	}}
