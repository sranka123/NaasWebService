package com.safelogic.naas.ach.manager.web.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.joda.time.DateTime;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.safelogic.naas.ach.manager.web.model.AccountHolder;
import com.safelogic.naas.ach.manager.web.model.EventLog;

@Repository("eventLogDao")
@Transactional(readOnly = true)
public class EventLogDAOImpl implements EventLogDao {

    @PersistenceContext
    private EntityManager em;
	
	@Override
	public List<EventLog> getEventLogs(AccountHolder accountHolder) {
		TypedQuery<EventLog> query = em.createQuery("SELECT eventLog from EventLog eventLog where eventLog.accountHolderName = :achName order by eventLog.eventDateTime desc",EventLog.class);
		query.setParameter("achName", accountHolder.getName());
		return query.getResultList();
		
	}

	@Override
	public List<EventLog> getEventLog(AccountHolder accountHolder, DateTime from, DateTime to) {
		throw new RuntimeException("Not implemented yet!!");
	}

}
