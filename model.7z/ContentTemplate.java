/**
 * 
 */
package com.safelogic.naas.ach.manager.web.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Lob;
import javax.persistence.Table;

@Entity
@Table(name="content_template")
public class ContentTemplate extends NaasEntity {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -840507869672893769L;

	@Lob
	@Column(name="text_content")
	private String textContent;

	/**
	 * @return the textContent
	 */
	public String getTextContent() {
		return textContent;
	}

	/**
	 * @param textContent the textContent to set
	 */
	public void setTextContent(String textContent) {
		this.textContent = textContent;
	}
}
