package com.safelogic.naas.ach.manager.web.dao;

import java.util.List;

import com.safelogic.naas.ach.manager.web.NaasException;
import com.safelogic.naas.ach.manager.web.customer.group.CustomerGroup;
import com.safelogic.naas.ach.manager.web.model.Customer;
import com.safelogic.naas.ach.manager.web.model.CustomerGroupBasicInfo;

public interface CustomerGroupDAO extends NaasRepository<Customer> {
	
	public CustomerGroup updateSearchQuery(CustomerGroup customerGroup);
	
	public List<CustomerGroupBasicInfo> getCustomerGroupsForAccountHolder(long achId);
	
	public Boolean deleteCustomerGroup(long groupId) throws NaasException;
	
	public CustomerGroup updateCustomerGroup(CustomerGroup customerGroup);

}
