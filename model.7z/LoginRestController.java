package com.safelogic.naas.ach.manager.web.controller;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.safelogic.naas.ach.manager.web.NaasURIConstants;
import com.safelogic.naas.ach.manager.web.model.Login;

@RestController
@RequestMapping(value=NaasURIConstants.login)
public class LoginRestController {

	@RequestMapping(method = RequestMethod.POST, consumes = {MediaType.APPLICATION_JSON_VALUE})
	public Boolean  loginUser(@RequestBody Login login) {
		
		if(login == null || login.getEmailId() == null || login.getPassword() == null || login.getAchName() == null) {
			return false;
		}
		
		if(login.getEmailId().equalsIgnoreCase("user1") && login.getPassword().equals("naas#user") && login.getAchName().equals("Austin Infiniti")) {
			return true;
		} else {
			return false;
		}
	}
	
}
