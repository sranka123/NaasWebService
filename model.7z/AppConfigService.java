/**
 * 
 */
package com.safelogic.naas.ach.manager.web.service;

import java.util.List;

import com.safelogic.naas.ach.manager.web.model.AppConfig;

public interface AppConfigService {

	public List<AppConfig> getAllAppConfig();
}
