package com.safelogic.naas.ach.manager.web.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.safelogic.naas.ach.manager.web.security.NaasAccountHolderUser;
import com.safelogic.naas.ach.manager.web.service.AccountHolderUserService;

@Controller
@RequestMapping(value="/app")
public class AppController {

	@Autowired
	AccountHolderUserService accountHolderUserService;
	
	@RequestMapping(method = RequestMethod.GET)
	public String getAppView(Model model, @AuthenticationPrincipal NaasAccountHolderUser currentUser){

		return "naas_app";
	}
}
