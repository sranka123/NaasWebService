package com.safelogic.naas.ach.manager.web.customer.group;

import java.io.Serializable;
import java.util.List;

public class CustomerGroupTO implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private long id;
	
	private String name;
	
	//private String topLevelOperator;
	
	private List<ConditionLineTO> conditionLines;
	
	public CustomerGroupTO()
	{
		
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	
	/*public String getTopLevelOperator() {
		return topLevelOperator;
	}

	public void setTopLevelOperator(String topLevelOperator) {
		this.topLevelOperator = topLevelOperator;
	}*/

	public List<ConditionLineTO> getConditionLines() {
		return conditionLines;
	}

	public void setConditionLines(List<ConditionLineTO> conditionLines) {
		this.conditionLines = conditionLines;
	}
	
	

}
