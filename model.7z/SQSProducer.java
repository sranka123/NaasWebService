package com.safelogic.naas.ach.manager.web.util;

import javax.jms.Connection;
import javax.jms.MessageProducer;
import javax.jms.Queue;
import javax.jms.Session;
import javax.jms.TextMessage;

import com.amazon.sqs.javamessaging.SQSConnection;
import com.amazon.sqs.javamessaging.SQSConnectionFactory;
import com.amazonaws.auth.EnvironmentVariableCredentialsProvider;
import com.amazonaws.regions.Region;
import com.amazonaws.regions.Regions;

/**
 * @author Sashi
 *
 */
public class SQSProducer {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		try {
			Connection jmsConnnection = createConnnection();
			// Create the non-transacted session with AUTO_ACKNOWLEDGE mode
			Session session = jmsConnnection.createSession(false, Session.AUTO_ACKNOWLEDGE);
			// Create a queue identity with name 'TestQueue' in the session
			Queue queue = session.createQueue("naas_notification_dev");

			// Create a producer for the 'TestQueue'.
			MessageProducer producer = session.createProducer(queue);
			// Create the text message.
			TextMessage message = session.createTextMessage("Worked Sashi...awesome!!");

			// Send the message.
			producer.send(message);
			System.out.println("JMS Message " + message.getJMSMessageID());
			producer.close();
			jmsConnnection.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	private static Connection createConnnection() throws Exception {
		// Create the connection factory using the environment variable
		// credential provider.
		// Connections this factory creates can talk to the queues in us-east-1
		// region.
		SQSConnectionFactory connectionFactory = SQSConnectionFactory.builder()
				.withRegion(Region.getRegion(Regions.US_EAST_1))
				.withAWSCredentialsProvider(new EnvironmentVariableCredentialsProvider()).build();

		// Create the connection.
		SQSConnection connection = connectionFactory.createConnection();
		return connection;
	}

}
