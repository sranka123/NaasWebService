package com.safelogic.naas.ach.manager.web.util;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.UUID;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.safelogic.naas.ach.manager.web.customer.group.CustomerGroup;
import com.safelogic.naas.ach.manager.web.model.AccountHolder;
import com.safelogic.naas.ach.manager.web.model.AccountHolderUser;
import com.safelogic.naas.ach.manager.web.model.AccountHolderUserSetup;
import com.safelogic.naas.ach.manager.web.model.Category;
import com.safelogic.naas.ach.manager.web.model.Customer;
import com.safelogic.naas.ach.manager.web.model.Industry;
import com.safelogic.naas.ach.manager.web.model.Notification;
import com.safelogic.naas.ach.manager.web.model.Permission;
import com.safelogic.naas.ach.manager.web.model.Role;
import com.safelogic.naas.ach.manager.web.model.SubIndustry;

public class TestEntityMapping {
	public static void main(String[] args) {
		EntityManagerFactory emFactory = Persistence.createEntityManagerFactory("testing");
	    EntityManager em = emFactory.createEntityManager();
	    //testUserRoleMapping(em);
	    //testSubIndustryMapping(em);
	    //testAccountUserMapping(em);
	    testCustomerMapping(em);
	    //testUserSetupMapping(em);
	    emFactory.close();
	}
	
	private static void testCustomerMapping(EntityManager em) {
		em.getTransaction().begin();
		AccountHolder accountHolder = new AccountHolder();
		accountHolder.setName("Kanbay");
		em.persist(accountHolder);
		
		CustomerGroup group = new CustomerGroup();
		group.setName("30KMiles");
		CustomerGroup group1 = new CustomerGroup();
		group1.setName("NewCarPromotion");		
		em.persist(group);
		em.persist(group1);
		
		Customer customer1 = new Customer();
		
		customer1.setEmailId("replyramdas@gmail.com");
		customer1.setFirstName("Ramdas");	
		//customer1.setCustomerGroups(Arrays.asList(group1,group));
		
		em.persist(customer1);
		Customer customer2 = new Customer();
		customer2.setEmailId("amita.gunjal@gmail.com");
		customer2.setFirstName("Amita");
		//customer2.setCustomerGroups(Collections.singletonList(group));
		em.persist(customer2);
		
		Notification notification = new Notification();
		notification.setAccountHolder(accountHolder);
		notification.setCustomerGroup(group);
		//notification.setNotificationTemplate("test_template");
		
		em.persist(notification);
		
		
		 em.getTransaction().commit();
		 em.close();
		
	}

	private static void testUserSetupMapping(EntityManager em) {
		em.getTransaction().begin();
		AccountHolder accountHolder = new AccountHolder();
		accountHolder.setName("Avaya");
		em.persist(accountHolder);
		
		AccountHolderUser user = new AccountHolderUser();
		user.setAccountHolder(accountHolder);
		user.setEmailId("rsawant@avaya.com");
		em.persist(user);
		
		AccountHolderUserSetup setup = new AccountHolderUserSetup();
		UUID token = UUID.randomUUID();
		System.out.println(token.toString());
		setup.setToken(token.toString());
		setup.setAccountHolderUser(user);
		
		em.persist(setup);
		
	    em.getTransaction().commit();
	    em.close();
	}

	private static void testAccountUserMapping(EntityManager em) {
		em.getTransaction().begin();
		AccountHolder accountHolder = new AccountHolder();
		accountHolder.setName("Barclays");
		em.persist(accountHolder);

		Permission createPermission = new Permission();
		createPermission.setName("create");
		
		Permission updatePermission = new Permission();
		updatePermission.setName("update");

		Permission readPermission = new Permission();
		readPermission.setName("read");

		em.persist(createPermission);
		em.persist(updatePermission);
		em.persist(readPermission);

		Role role = new Role();
		role.setName("Admin");
		List<Permission> adminPermissions = new ArrayList<>();
		adminPermissions.add(createPermission);
		adminPermissions.add(updatePermission);
		role.setPermissions(adminPermissions);
		em.persist(role);
		
		Role userRole = new Role();
		userRole.setName("User");
		userRole.setPermissions(Collections.singletonList(readPermission));
		em.persist(userRole);
		
		AccountHolderUser user = new AccountHolderUser();
		user.setFirstName("Ramdas");
		user.setLastName("Sawant");
		user.setAccountHolder(accountHolder);
		user.setRoles(Arrays.asList(userRole));
		em.persist(user);
		
	    em.getTransaction().commit();
	    em.close();
	}

	private static void testSubIndustryMapping(EntityManager em) {
		 em.getTransaction().begin();
		Industry industry = new Industry();
		industry.setName("Agriculture and Mining");
		em.persist(industry);
		
		SubIndustry sub1 = new SubIndustry();
		sub1.setName("Farming and Ranching");
		
		SubIndustry sub2 = new SubIndustry();
		sub2.setName("Mining and Quarrying");
		em.persist(sub1);
		em.persist(sub2);
		
		Category category1 = new Category();
		category1.setIndustry(industry);
		category1.setSubIndustry(sub1);
		
		Category category2 = new Category();
		category2.setIndustry(industry);
		category2.setSubIndustry(sub2);

		em.persist(category1);
		em.persist(category2);

		AccountHolder accountHolder = new AccountHolder();
		accountHolder.setName("Avaya");
		accountHolder.setCategory(category2);
		em.persist(accountHolder);
		
		
	    em.getTransaction().commit();
	    em.close();
	}

	
}
