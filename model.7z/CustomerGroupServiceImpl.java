package com.safelogic.naas.ach.manager.web.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.safelogic.naas.ach.manager.web.customer.group.DataType;
import com.safelogic.naas.ach.manager.web.customer.group.Field;
import com.safelogic.naas.ach.manager.web.customer.group.Operator;
import com.safelogic.naas.ach.manager.web.NaasException;
import com.safelogic.naas.ach.manager.web.customer.group.CustomerGroup;
import com.safelogic.naas.ach.manager.web.dao.CustomerDAO;
import com.safelogic.naas.ach.manager.web.dao.CustomerGroupDAO;
import com.safelogic.naas.ach.manager.web.dao.NaasRepository;
import com.safelogic.naas.ach.manager.web.model.Customer;
import com.safelogic.naas.ach.manager.web.model.CustomerBasicInfo;
import com.safelogic.naas.ach.manager.web.model.CustomerGroupBasicInfo;

@Service
@Qualifier("customerGroupService")
@Transactional
public class CustomerGroupServiceImpl implements CustomerGroupService {
	
	private NaasRepository<Field> fieldRepo;
	private NaasRepository<DataType> dataTypeRepo;
	private NaasRepository<Operator> operatorRepo;
	private NaasRepository<CustomerGroup> customerGroupRepo;
	private NaasRepository<Customer> customerRepo;
	private NaasRepository<CustomerBasicInfo> customerBasicInfoRepo;
	
	private CustomerGroupDAO customerGroupDao;
	private CustomerDAO customerDao;

	@Override
	public List<Field> getAllFields() {
		
		return fieldRepo.findAll();
	}

	@Override
	public List<DataType> getAllDataTypes() {
		return dataTypeRepo.findAll();
	}
	
	@Override
	public List<Operator> getAllOperators() {
		return operatorRepo.findAll();
	}
	
	/* Duplicate method
	 * @Override
	public List<CustomerGroup> getAllCustomerGroups() {
		List<CustomerGroup> customerGroups = customerGroupRepo.findAll();
		
		return customerGroups;
	}*/
	
	@Override
	public Customer getCustomer(long customerId) {
		return customerRepo.findById(customerId);
	}
	
	@Override
	public List<CustomerBasicInfo> getAllCustomers() {
		return customerBasicInfoRepo.findAll();
	}
	
	@Override
	public List<Customer> getCustomers(String sqlWhereCaluse) {
		return customerDao.getCustomers(sqlWhereCaluse);
	}
	
	@Override
	public long getCustomerCount(String sqlWhereCaluse) {
		return customerDao.getCustomerCount(sqlWhereCaluse);
	}
	
	@Override
	public CustomerGroup getCustomerGroup(long id) {
		return customerGroupRepo.findById(id);
	}
	
	@Override
	public List<CustomerGroupBasicInfo> getAllCustomerGroups(long achId) {
		return customerGroupDao.getCustomerGroupsForAccountHolder(achId);
	}
	
	public CustomerGroup createCustomerGroup(CustomerGroup customerGroup){
		return customerGroupRepo.create(customerGroup);
	}
	
	public CustomerGroup updateCustomerGroup(CustomerGroup customerGroup){
		return customerGroupDao.updateCustomerGroup(customerGroup);
	}
	
	@Autowired
	@Qualifier("customerDao")
	public void setCustomerDao(CustomerDAO naasCustomerRepository){
		this.customerDao = naasCustomerRepository;
	}
	
	@Autowired
	@Qualifier("customerGroupDao")
	public void setCustomerGroupDao(CustomerGroupDAO naasCustomerGroupRepository){
		this.customerGroupDao = naasCustomerGroupRepository;
	}
	
	@Autowired
	@Qualifier("naasRepository")
	public void setCustomerGroupRepo(NaasRepository<Field> fieldRepo) {
		this.fieldRepo = fieldRepo;
		this.fieldRepo.setType(Field.class);
	}

	@Autowired
	@Qualifier("naasRepository")
	public void setDataTypeRepo(NaasRepository<DataType> dataTypeRepo) {
		this.dataTypeRepo = dataTypeRepo;
		this.dataTypeRepo.setType(DataType.class);
	}
	
	@Autowired
	@Qualifier("naasRepository")
	public void setOperatorRepo(NaasRepository<Operator> operatorRepo) {
		this.operatorRepo = operatorRepo;
		this.operatorRepo.setType(Operator.class);
	}

	@Autowired
	@Qualifier("naasRepository")
	public void setSearchQueryRepo(NaasRepository<CustomerGroup> searchQueryRepo) {
		this.customerGroupRepo = searchQueryRepo;
		this.customerGroupRepo.setType(CustomerGroup.class);
	}
	
	@Autowired
	@Qualifier("naasRepository")
	public void setCustomerRepo(NaasRepository<Customer> customerRepo) {
		this.customerRepo = customerRepo;
		this.customerRepo.setType(Customer.class);
	}
	
	@Autowired
	@Qualifier("naasRepository")
	public void setCustomerBasicInfoRepo(NaasRepository<CustomerBasicInfo> customerBasicInfoRepo) {
		this.customerBasicInfoRepo = customerBasicInfoRepo;
		this.customerBasicInfoRepo.setType(CustomerBasicInfo.class);
	}

	@Override
	public Boolean deleteCustomerGroup(long groupId) throws NaasException {
		return customerGroupDao.deleteCustomerGroup(groupId);
	}

	
}
