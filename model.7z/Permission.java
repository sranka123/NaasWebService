package com.safelogic.naas.ach.manager.web.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="permission_master")
public class Permission {

	@Id
	@GeneratedValue
	@Column(name="permission_id")
	private long id;
	
	@Column(name="permission_name")
	private String name;

	public Permission() {
		// TODO Auto-generated constructor stub
	}
	
	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	
	
}
