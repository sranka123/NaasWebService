package com.safelogic.naas.ach.manager.web.dao;

import java.util.List;

import org.joda.time.DateTime;

import com.safelogic.naas.ach.manager.web.model.AccountHolder;
import com.safelogic.naas.ach.manager.web.model.EventLog;

public interface EventLogDao {
	
	List<EventLog> getEventLogs(AccountHolder accountHolder);
	
	List<EventLog> getEventLog(AccountHolder accountHolder, DateTime from, DateTime to);
	
	
}
