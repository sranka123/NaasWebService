package com.safelogic.naas.ach.manager.web.util;

import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;

import com.safelogic.naas.ach.manager.web.customer.group.CustomerGroup;
import com.safelogic.naas.ach.manager.web.dao.DeliveredNotifiationDAOImpl;
import com.safelogic.naas.ach.manager.web.model.AccountHolder;
import com.safelogic.naas.ach.manager.web.model.AccountHolderUser;
import com.safelogic.naas.ach.manager.web.model.ContentEmail;
import com.safelogic.naas.ach.manager.web.model.ContentSms;
import com.safelogic.naas.ach.manager.web.model.Customer;
import com.safelogic.naas.ach.manager.web.model.DeliveredNotification;
import com.safelogic.naas.ach.manager.web.model.Notification;
import com.safelogic.naas.ach.manager.web.model.Permission;
import com.safelogic.naas.ach.manager.web.model.Role;
import com.safelogic.naas.ach.manager.web.security.NaasAccountHolderUser;

public class TestDeliveredNotification {
	
	public static void main(String[] args) throws Exception{
		SecurityContext context = SecurityContextHolder.getContext();
		context.setAuthentication(new Authentication() {
			
			@Override
			public String getName() {
				return "DUMMY_AUTH";
			}
			
			@Override
			public void setAuthenticated(boolean isAuthenticated) throws IllegalArgumentException {

			}
			
			@Override
			public boolean isAuthenticated() {
				return true;
			}
			
			@Override
			public Object getPrincipal() {
				return new NaasAccountHolderUser("DYMMY", "DYMMY", Arrays.asList(new SimpleGrantedAuthority("ADMIN")));
			}
			
			@Override
			public Object getDetails() {
				return "DETAILS";
			}
			
			@Override
			public Object getCredentials() {
				return "CREDENTIALS";
			}
			
			@Override
			public Collection<? extends GrantedAuthority> getAuthorities() {
				return Arrays.asList(new SimpleGrantedAuthority("ADMIN"));
			}
		});
		EntityManagerFactory emFactory = Persistence.createEntityManagerFactory("testing");
	    EntityManager em = emFactory.createEntityManager();
	    em.getTransaction().begin();
	    
	    AccountHolder accountHolder = new AccountHolder();
	    //accountHolder.setId(1L);
	    accountHolder.setName("Avaya");	    
	    em.persist(accountHolder);
	    
	    Permission createPermission = new Permission();
	    //createPermission.setId(1L);
	    createPermission.setName("CREATE_USER");
	    em.persist(createPermission);
	    
	    Role adminRole = new Role();
	    //adminRole.setId(1L);
	    adminRole.setName("ADMIN");
	    adminRole.setPermissions(Collections.singletonList(createPermission));
	    em.persist(adminRole);
	    
	    AccountHolderUser adminUser = new AccountHolderUser();
	   // adminUser.setId(1L);
	    adminUser.setEmailId("admin@avaya.com");
	    adminUser.setRoles(Collections.singletonList(adminRole));
	    em.persist(adminUser);
	    
	    Customer feroz = new Customer();
	   // feroz.setId(1L);
	    feroz.setFirstName("Feroz");
	    feroz.setEmailId("feroz@cognizant.com");
	    feroz.setAccountHolder(accountHolder);
	    em.persist(feroz);
	    
	    Customer sashi = new Customer();
	    //sashi.setId(2L);
	    sashi.setFirstName("Sashi");
	    sashi.setEmailId("sashi@mastercard.com");
	    sashi.setAccountHolder(accountHolder);
	    em.persist(sashi);
	    
	    CustomerGroup friendsGroup = new CustomerGroup();
	   // friendsGroup.setId(1L);
	    friendsGroup.setName("FRIENDS");
	    friendsGroup.setCustomers(Arrays.asList(sashi,feroz));
	    em.persist(friendsGroup);
	    
	    ContentEmail email = new ContentEmail();
	    email.setName("Test Email");
	    em.persist(email);
	    
	    ContentSms sms = new ContentSms();
	    sms.setName("Test SMS");
	    em.persist(sms);
	    
	    ContentEmail newEmail = new ContentEmail();
	    newEmail.setName("new email");
	    em.persist(newEmail);
	    
	    Notification notification = new Notification();
	    notification.setName("Test Notification: Email only");
	    notification.setContentEmail(email);
	    notification.setContentSms(sms);
	    notification.setCustomerGroup(friendsGroup);
	    notification.setAccountHolder(accountHolder);	    
	    em.persist(notification);
	    
	    Notification notification1 = new Notification();
	    notification1.setName("New Notification: Email only");
	    notification1.setContentEmail(newEmail);
	    notification1.setCustomerGroup(friendsGroup);
	    notification1.setAccountHolder(accountHolder);	    
	    em.persist(notification1);
	    
	    
	    DeliveredNotification deliveredNotification = new DeliveredNotification();
	    deliveredNotification.setAccountHolder(accountHolder);
	    deliveredNotification.setCustomer(sashi);
	    deliveredNotification.setContentEmail(email);
	    deliveredNotification.setCreateDate(new Date());
	    deliveredNotification.setContentSms(sms);
	    deliveredNotification.setNotification(notification);
	    em.persist(deliveredNotification);
	    
	    DeliveredNotification deliveredNotification1 = new DeliveredNotification();
	    deliveredNotification1.setAccountHolder(accountHolder);
	    deliveredNotification1.setCustomer(feroz);
	    deliveredNotification1.setContentEmail(newEmail);
	    deliveredNotification1.setContentSms(null);
	    deliveredNotification1.setNotification(notification1);
	    em.persist(deliveredNotification1);

	    
	    DeliveredNotification deliveredNotification2 = new DeliveredNotification();
	    deliveredNotification2.setAccountHolder(accountHolder);
	    deliveredNotification2.setCustomer(sashi);
	    deliveredNotification2.setContentEmail(newEmail);
	    deliveredNotification2.setContentSms(null);
	    deliveredNotification2.setNotification(notification1);
	    em.persist(deliveredNotification2);
	    em.getTransaction().commit();
	    em.close();
	    
	    em = emFactory.createEntityManager();
	    em.getTransaction().begin();
	    DeliveredNotifiationDAOImpl dao = new DeliveredNotifiationDAOImpl();
	    dao.setEm(em);
	    System.out.println(dao.listOfNotificationDeliveredToCustomer(feroz).get(0).getNotification().getName());
	    em.getTransaction().commit();
	    em.close();
//	    CustomerDAOImpl customerDAO = new CustomerDAOImpl();
//	    customerDAO.setEm(em);
//	    List<Object[]> list = customerDAO.getCustomersWithNotificationCount(accountHolder);
//	    for(Object ob[] : list){
//	    	System.out.println("------");
//	    	Customer customer = (Customer)ob[0];
//	    	long count = (long)ob[1];
//	    	System.out.println(customer+" :: "+count);
//	    	System.out.println("%%%");
//	    }
	    //System.out.println("## "+dao.countOfDeliveredEmails(accountHolder));
	    //System.out.println("@@ "+dao.countOfDeliveredEmails(accountHolder, DateTime.parse("2016-07-19"), DateTime.parse("2016-07-21")));
	    
	    emFactory.close();
	}
}
