package com.safelogic.naas.ach.manager.web.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.safelogic.naas.ach.manager.web.NaasException;
import com.safelogic.naas.ach.manager.web.customer.group.CustomerGroup;
import com.safelogic.naas.ach.manager.web.model.Customer;
import com.safelogic.naas.ach.manager.web.model.CustomerGroupBasicInfo;

@Repository("customerGroupDao")
public class CustomerGroupDAOImpl extends NaasRepositoryImpl<Customer>  implements CustomerGroupDAO {
	
	@PersistenceContext
    private EntityManager em;	

	@Override
	public CustomerGroup updateSearchQuery(CustomerGroup customerGroup) {
	
		Query query = em.createQuery("delete from ConditionLine where group_id = :groupId");
		int count = query.setParameter("group_id", customerGroup.getId()).executeUpdate();
		
		System.out.println("Number of condition lines deleted: " + count);
		
		return em.merge(customerGroup);
	}
	
	@Override
	public List<CustomerGroupBasicInfo> getCustomerGroupsForAccountHolder(long achId) {
		TypedQuery<CustomerGroupBasicInfo> queryMemberOf = em.createQuery(
			    "select customerGroup FROM CustomerGroupBasicInfo customerGroup where customerGroup.accountHolder.id = :ach_id" , CustomerGroupBasicInfo.class);
		queryMemberOf.setParameter("ach_id", achId);
		return queryMemberOf.getResultList();
	}

	@Override
	public Boolean deleteCustomerGroup(long groupId) throws NaasException{
		boolean isDeleted = false;
		CustomerGroup cg = em.find(CustomerGroup.class, groupId);
		if (cg == null || (cg != null && cg.getCustomers() != null)) {
			//TODO need to throw this exception with proper http error code.
			throw new NaasException("invalid data passed in delete customer gorup service.");
		}
        em.remove(cg);
        isDeleted = true;
		return isDeleted;
	}

	@Override
	public CustomerGroup updateCustomerGroup(CustomerGroup customerGroup) {
        em.merge(customerGroup);
		return customerGroup;
	}
}
