package com.safelogic.naas.ach.manager.web.dao;

import java.util.List;

import com.safelogic.naas.ach.manager.web.model.AccountHolder;
import com.safelogic.naas.ach.manager.web.model.AccountHolderUser;
import com.safelogic.naas.ach.manager.web.model.AccountHolderUserSetup;
import com.safelogic.naas.ach.manager.web.model.Role;

public interface AccountHolderUserDAO extends NaasRepository<AccountHolderUser>{
	public AccountHolderUserSetup getAccountHolderUserSetup(String token);
	public AccountHolderUser getAccountHolderUser(String email, AccountHolder accountHolder);
	public List<AccountHolderUser> getAccountHolderUserByRole(String roleName, AccountHolder accountHolder);
	public AccountHolderUser getActiveAccoutHolderUser(String userName, AccountHolder accountHolder);
	public Role getRoleOfUser(String userName, AccountHolder accountHolder);
}
