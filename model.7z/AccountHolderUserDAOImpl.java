package com.safelogic.naas.ach.manager.web.dao;

import java.util.List;

import javax.persistence.TypedQuery;

import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Repository;

import com.safelogic.naas.ach.manager.web.model.AccountHolder;
import com.safelogic.naas.ach.manager.web.model.AccountHolderUser;
import com.safelogic.naas.ach.manager.web.model.AccountHolderUserSetup;
import com.safelogic.naas.ach.manager.web.model.Role;

@Repository("accountHolderUserDao")
public class AccountHolderUserDAOImpl extends NaasRepositoryImpl<AccountHolderUser> implements AccountHolderUserDAO {
	
	@Override
	public AccountHolderUser getActiveAccoutHolderUser(String userName,AccountHolder accountHolder) throws EmptyResultDataAccessException{
		TypedQuery<AccountHolderUser> query = 
				em.createQuery("Select accountHolderUser from AccountHolderUser accountHolderUser "
						+ "where accountHolderUser.enabled = true and "
						+ "accountHolderUser.emailId = :userName and "
						+ "accountHolderUser.accountHolder.id = :ach_id", AccountHolderUser.class);
		query.setParameter("userName", userName);
		query.setParameter("ach_id", accountHolder.getId());
		return query.getSingleResult();
	}
	
	@Override
	public Role getRoleOfUser(String userName,AccountHolder accountHolder) {
		throw new RuntimeException("Not yet implemented");
	}

	@Override
	public AccountHolderUser getAccountHolderUser(String userName, AccountHolder accountHolder) {
		TypedQuery<AccountHolderUser> query = em.createQuery("Select accountHolderUser from AccountHolderUser accountHolderUser where accountHolderUser.emailId = :userName and accountHolderUser.accountHolder.name = :accountHolderName", AccountHolderUser.class);
		query.setParameter("userName", userName);
		query.setParameter("accountHolderName", accountHolder.getName());
		return query.getSingleResult();
	}


	@Override
	public AccountHolderUserSetup getAccountHolderUserSetup(String token) {
		TypedQuery<AccountHolderUserSetup> query = 
				em.createQuery("Select accountHolderUserSetup from AccountHolderUserSetup accountHolderUserSetup where accountHolderUserSetup.token = :token and accountHolderUserSetup.validToken = true",AccountHolderUserSetup.class);
		query.setParameter("token", token);
		return query.getSingleResult();
	}
	@Override
	public List<AccountHolderUser> getAccountHolderUserByRole(String roleName, AccountHolder accountHolder) {
		TypedQuery<AccountHolderUser> query = em.createQuery("Select accountHolderUser from AccountHolderUser accountHolderUser where accountHolderUser.role.name = :roleName and accountHolderUser.accountHolder.name = :accountHolderName", AccountHolderUser.class);
		query.setParameter("roleName", roleName);
		query.setParameter("accountHolderName", accountHolder.getName());
		return query.getResultList();
	}

}
