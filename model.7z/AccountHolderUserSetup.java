package com.safelogic.naas.ach.manager.web.model;

import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;


@Entity
@Table(name="accountholder_user_setup")
public class AccountHolderUserSetup extends NaasEntity /*implements Serializable*/{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -8172637477359099413L;


	/*user name of account holder user*/
	
	@ManyToOne
	@JoinColumn(name="ach_userid")
	private AccountHolderUser accountHolderUser;
	
	private String token;
	
	private boolean validToken;
	
	
	//this is the one sent to admin user who create this user.
	private String oneTimePassword;
	

	public AccountHolderUserSetup() {
		
	}

	public AccountHolderUser getAccountHolderUser() {
		return accountHolderUser;
	}


	public void setAccountHolderUser(AccountHolderUser accountHolderUser) {
		this.accountHolderUser = accountHolderUser;
	}


	public String getToken() {
		return token;
	}


	public void setToken(String token) {
		this.token = token;
	}


	public boolean isValidToken() {
		return validToken;
	}


	public void setValidToken(boolean validToken) {
		this.validToken = validToken;
	}


	public String getOneTimePassword() {
		return oneTimePassword;
	}


	public void setOneTimePassword(String oneTimePassword) {
		this.oneTimePassword = oneTimePassword;
	}

	
	
	
}
