package com.safelogic.naas.ach.manager.web.dao;

import java.util.List;

import org.joda.time.DateTime;

import com.safelogic.naas.ach.manager.web.model.AccountHolder;
import com.safelogic.naas.ach.manager.web.model.Customer;
import com.safelogic.naas.ach.manager.web.model.DeliveredNotification;
import com.safelogic.naas.ach.manager.web.model.Notification;

public interface DeliveredNotificationDAO extends NaasRepository<DeliveredNotification> {
	
	public int countOfDeliveredEmails(AccountHolder ach);
	
	public int countOfDeliveredSmss(AccountHolder ach);
	
	public int countOfDeliveredEmails(AccountHolder ach, DateTime from, DateTime to);
	
	public int countOfDeliveredSmss(AccountHolder ach, DateTime from, DateTime to);
	
	public List<Customer> listOfCustomersForDeliveredNotification(Notification notification);
	
	public List<DeliveredNotification> listOfNotificationDeliveredToCustomer(Customer customer);
	
	public int countOfDeliveredEmailsForNotification(Notification notification);
	
	public int countOfDeliveredSmssForNotification(Notification notification);
	
	
}
