package com.safelogic.naas.ach.manager.web.service;

import java.util.List;

import com.safelogic.naas.ach.manager.web.customer.group.DataType;
import com.safelogic.naas.ach.manager.web.customer.group.Field;
import com.safelogic.naas.ach.manager.web.customer.group.Operator;
import com.safelogic.naas.ach.manager.web.NaasException;
import com.safelogic.naas.ach.manager.web.customer.group.CustomerGroup;
import com.safelogic.naas.ach.manager.web.model.Customer;
import com.safelogic.naas.ach.manager.web.model.CustomerBasicInfo;
import com.safelogic.naas.ach.manager.web.model.CustomerGroupBasicInfo;

public interface CustomerGroupService {

	public List<Field> getAllFields();
	
	public List<DataType> getAllDataTypes();
	
	public List<Operator> getAllOperators();
	
	//public List<CustomerGroup> getAllCustomerGroups();
	
	public CustomerGroup getCustomerGroup(long id);
	
	public CustomerGroup createCustomerGroup(CustomerGroup customerGroup);
	
	public CustomerGroup updateCustomerGroup(CustomerGroup customerGroup);
	
	public List<Customer> getCustomers(String sqlWhereCaluse);
	
	public long getCustomerCount(String sqlWhereCaluse);
	
	public Customer getCustomer(long customerId);
	
	public List<CustomerBasicInfo> getAllCustomers();
	
	public List<CustomerGroupBasicInfo> getAllCustomerGroups(long achId);
	
	public Boolean deleteCustomerGroup(long groupId) throws NaasException;

}
