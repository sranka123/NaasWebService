package com.safelogic.naas.ach.manager.web.controller;

import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.safelogic.naas.ach.manager.web.NaasURIConstants;
import com.safelogic.naas.ach.manager.web.customer.group.CustomerGroup;
import com.safelogic.naas.ach.manager.web.customer.group.Field;
import com.safelogic.naas.ach.manager.web.dao.AccountHolderDAO;
import com.safelogic.naas.ach.manager.web.model.AccountHolder;
import com.safelogic.naas.ach.manager.web.model.Customer;
import com.safelogic.naas.ach.manager.web.model.CustomerBasicInfo;
import com.safelogic.naas.ach.manager.web.service.CustomerGroupService;
import com.safelogic.naas.ach.manager.web.service.CustomerNotificationService;

@RestController
@RequestMapping(value=NaasURIConstants.customerBase)
public class CustomerRestController {
	@Autowired
	private CustomerNotificationService customerNotificationService;
	
	@Autowired
	private CustomerGroupService customerGroupService;
	
	private AccountHolderDAO accountHolderDao;
	
	@RequestMapping(value="/{customerId}", method=RequestMethod.GET ,produces = {MediaType.APPLICATION_JSON_VALUE})
	public Customer getCustomerForId(@RequestHeader("achName") String achName, @PathVariable(value="customerId") long customerId){
		

		if(achName == null || !achName.trim().equals("Austin Infiniti")) {
			return null;
		}
		
		Customer customer = customerGroupService.getCustomer(customerId);
		
		Map<Integer, String> metadataMap = new Hashtable<Integer, String>();
		metadataMap.put(19, "12283");
		metadataMap.put(15, "2017");
		metadataMap.put(13, "T84JFJ4FH49JJD8333");
		metadataMap.put(20, "01/01/14");
		customer.setMetadataMap(metadataMap);
		
		customer.setMetadata(null);
		
		return customer;
	}
	
	@RequestMapping(value="/list",method=RequestMethod.GET ,produces = {MediaType.APPLICATION_JSON_VALUE})
	public List<CustomerBasicInfo> getAllCustomers(@RequestHeader("achName") String achName){

		if(achName == null || !achName.trim().equals("Austin Infiniti")) {
			return null;
		}
		
		return customerGroupService.getAllCustomers();
	}
	
	@RequestMapping(value="/metadataFields/list",method=RequestMethod.GET ,produces = {MediaType.APPLICATION_JSON_VALUE})
	public Map<Long, Field> getAllMetadataFields(@RequestHeader("achName") String achName){
		
		if(achName == null || !achName.trim().equals("Austin Infiniti")) {
			return null;
		}
		
		return getFieldMap();
	}
	
	@RequestMapping(method=RequestMethod.POST, consumes = {MediaType.APPLICATION_JSON_VALUE})
	public Long createCustomer(@RequestHeader("achName") String achName, @RequestBody Customer customer){
		
		if(achName == null || customer == null || customer.getFirstName() == null || customer.getFirstName().trim().length() == 0) {
			System.out.println("Invalid request. returning 0L.");
			return 0L;
		}
		
		List<AccountHolder> accountHolders = accountHolderDao.findByAttribute("name", achName);
		if(accountHolders.size() == 0) {
			System.out.println("Could not find account holder. returning 0L.");
			return 0L;
		}
			
		AccountHolder accountHolder = (AccountHolder) accountHolderDao.findByAttribute("name", achName).get(0);
		customer.setAccountHolder(accountHolder);
		
		return customerNotificationService.saveCustomer(customer).getId();
	}
	
	@RequestMapping(method=RequestMethod.PUT, consumes = {MediaType.APPLICATION_JSON_VALUE})
	public Boolean updateCustomer(@RequestHeader("achName") String achName, @RequestBody Customer customer){
		
		if(achName == null || customer == null || customer.getFirstName() == null || customer.getFirstName().trim().length() == 0) {
			System.out.println("Invalid request. returning 0L.");
			return false;
		}
		
		List<AccountHolder> accountHolders = accountHolderDao.findByAttribute("name", achName);
		if(accountHolders.size() == 0) {
			System.out.println("Could not find account holder. returning 0L.");
			return false;
		}
			
		AccountHolder accountHolder = (AccountHolder) accountHolderDao.findByAttribute("name", achName).get(0);
		customer.setAccountHolder(accountHolder);
		
		customerNotificationService.updateCustomer(customer);
		
		return true;
	}
	
	@RequestMapping(value="/{customerId}", method=RequestMethod.DELETE)
	public Boolean deleteCustomer(@RequestHeader("achName") String achName, @PathVariable(value="customerId") long customerId){
		
		Customer customer = customerNotificationService.getCustomer(customerId);
		if(customer == null) {
			return false;
		}
		
		if(achName == null) {
			System.out.println("Invalid request. returning 0L.");
			return false;
		}
		
		List<AccountHolder> accountHolders = accountHolderDao.findByAttribute("name", achName);
		if(accountHolders.size() == 0) {
			System.out.println("Could not find account holder. returning 0L.");
			return false;
		}
			
		AccountHolder accountHolder = (AccountHolder) accountHolderDao.findByAttribute("name", achName).get(0);
		customer.setAccountHolder(accountHolder);
		
		return customerNotificationService.deleteCustomer(customer);
	}
	
	@RequestMapping(value="/g/{groupId}",method=RequestMethod.GET ,produces = {MediaType.APPLICATION_JSON_VALUE})
	public long getCustomerCountForGroup(@PathVariable(value="groupId") long groupId){
		
		//return customerNotificationService.getCustomerCount(groupId);
		
		try {
			CustomerGroup customerGroup = customerGroupService.getCustomerGroup(groupId);
			if(customerGroup == null || customerGroup.getConditionLines() == null || customerGroup.getConditionLines().size() == 0) {
				return 0L;
			} else {
				return customerGroupService.getCustomerCount(customerGroup.getSQLWhereClause());
			}
		} catch (Exception e) {
			return 0L;
		}
	}
	
	@RequestMapping(value="/g/{groupId}/customers",method=RequestMethod.GET ,produces = {MediaType.APPLICATION_JSON_VALUE})
	public List<Customer> getCustomersForGroup(@PathVariable(value="groupId") long groupId ){
		
		//return customerNotificationService.getCustomersForGroup(groupId);
		
		CustomerGroup customerGroup = customerGroupService.getCustomerGroup(groupId);
		return customerGroupService.getCustomers(customerGroup.getSQLWhereClause());
	}
	
	@RequestMapping(value="/g/{groupId}/customers1",method=RequestMethod.GET ,produces = {MediaType.TEXT_HTML_VALUE})
	public String getCustomersForGroup1(@PathVariable(value="groupId") long groupId ){
		List<Customer> customers = customerNotificationService.getCustomersForGroup(groupId);
		StringBuffer table = new StringBuffer();
		table.append("<table style='width:100%;border: 1px solid black;border-collapse: collapse' border=1>");
		table.append("<tr>")
		.append("<th>#</th>")
		.append("<th>Name</th>").append("<th>Use Email</th>").append("<th>Email</th>")
		.append("<th>Use Phone</th>").append("<th>Phone Number</th>")
		.append("</tr>");
			
		for(int i=0;i<customers.size();i++){
			Customer cust = customers.get(i);
			
			table
			.append("<tr>")
				.append("<td>").append(i+1).append("</td>")
				.append("<td>").append(cust.getDisplayName()).append("</td>")
				.append("<td align='center'>").append(imageTag(cust.isUseEmail())).append("</td>")
				.append("<td>").append(cust.getEmailId()).append("</td>")
				.append("<td align='center'>").append(imageTag(cust.isUsePhone())).append("</td>")
				.append("<td>").append(cust.getPhoneNumber()).append("</td>")
			.append("</tr>");
		}
		table.append("</table>");
		return table.toString(); 
	}
	
	private String imageTag(boolean useWhichImage){
		String imageName = useWhichImage?"yes.png":"no.png";
		String imgTag = "<img height='20px' width='20px' src='/naas/resources/img/"+imageName+"'>";
		System.out.println("imgTag : "+imgTag);
		return imgTag;
	}

	private Map<Long, Field> getFieldMap() {
		
		List<Field> allFields = customerGroupService.getAllFields();			
		Map<Long, Field> fieldMap = new HashMap<Long, Field>();
		for(Field field: allFields) {
			if(field.isMetadata()) {
				field.setEntityObj(null);
				field.setCreateDate(null);
				field.setCreatedByUser(null);
				field.setModifiedByUser(null);
				field.setModifiedDate(null);
				
				fieldMap.put(field.getId(), field);
			}
		}
		
		return fieldMap;
	}
	
	@Autowired
	@Qualifier("accountHolderDao")
	public void setAccountHolderDao(AccountHolderDAO naasAccountHolderRepository){
		this.accountHolderDao = naasAccountHolderRepository;
		this.accountHolderDao.setType(AccountHolder.class);
	}
}
