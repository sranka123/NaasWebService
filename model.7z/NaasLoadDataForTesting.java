package com.safelogic.naas.ach.manager.web.configuration;

import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
/**
 * 
 * @author Ramdas Sawant
 * Description :- Temperory component to load data for testing purpose
 *
 */
@Component
@Transactional
public class NaasLoadDataForTesting implements ApplicationListener<ContextRefreshedEvent>{
    
//	@Autowired
//	NaasEmailDao naasEmailDao;
//	
//	@Autowired
//	private CustomerNotificationService customerNotificationService;
	
	@Override
	public void onApplicationEvent(ContextRefreshedEvent event) {

//		NaasTemplate template = new NaasTemplate();
//		template.setEmailContentLocation("diwali.html");
//		template.setName("diwali_promotion");
//		template.setEmailSubject("diwali promotion");
//		template.setSmsContent("Happy Diwali. http://demo.safelogicsolutions.com");
//		
//		NaasTemplate template1 = new NaasTemplate();
//		template1.setEmailContentLocation("newyear.html");
//		template1.setName("newyear_promotion");
//		template1.setEmailSubject("new year promotion");
//		template1.setSmsContent("Happy New Year. http://demo.safelogicsolutions.com");
//
//		customerNotificationService.saveTemplate(template1);
//		customerNotificationService.saveTemplate(template);
//		
//		
//		CustomerGroup group = new CustomerGroup();
//		group.setName("first_group");
//		customerNotificationService.saveCustomerGroup(group);
//		
//		CustomerGroup group2 = new CustomerGroup();
//		group2.setName("second_group");
//		customerNotificationService.saveCustomerGroup(group2);

	}

	private void loadStaticData() {

   
	    
		
	}
}
