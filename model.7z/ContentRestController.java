 package com.safelogic.naas.ach.manager.web.controller;

import java.util.Date;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessageCreator;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.safelogic.naas.ach.manager.web.NaasURIConstants;
import com.safelogic.naas.ach.manager.web.model.ContentEmail;
import com.safelogic.naas.ach.manager.web.model.ContentSms;
import com.safelogic.naas.ach.manager.web.model.ContentStatus;
import com.safelogic.naas.ach.manager.web.model.ContentTemplate;
import com.safelogic.naas.ach.manager.web.security.NaasAccountHolderUser;
import com.safelogic.naas.ach.manager.web.service.ContentService;

@RestController
@RequestMapping(value=NaasURIConstants.contentRest)
public class ContentRestController {

	private Logger logger = LoggerFactory.getLogger(ContentRestController.class);
	
	@Autowired
	private JmsTemplate jmsQueueTemplate;
	
	@Autowired
	private ContentService contentService;
	
	@RequestMapping(value="/saveNewTemplate", method=RequestMethod.POST)
	public @ResponseBody String saveNewTemplate(@RequestParam String templateString, @RequestParam String templateName){
		System.out.println("In saveNewTemplate... ");
		
		ContentTemplate content = new ContentTemplate();
		content.setName(templateName);
		content.setTextContent(templateString);
		
		content = contentService.saveNewTemplateContent(content);
		
		return "Template Saved";
	}
	
	@RequestMapping(value="/getTemplate", method=RequestMethod.GET)
	public @ResponseBody String getTemplate(@RequestParam String id){
		System.out.println("In getTemplate... ");
		
		ContentTemplate content = contentService.getTemplateContent(Long.parseLong(id));
		
		return content.getTextContent();
	}
	
	@RequestMapping(value="/getAllTemplates", method=RequestMethod.GET, produces=MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody List<ContentTemplate> getAllTemplates(){
		System.out.println("In getAllTemplates... ");
		
		List<ContentTemplate> contents = contentService.getAllTemplateContent();		
		return contents;
	}
	
	@RequestMapping(value="/updateTemplate", method=RequestMethod.GET)
	public @ResponseBody String updateTemplate(@RequestParam String templateString, @RequestParam String id){
		System.out.println("In updateTemplate... ");
		
		ContentTemplate content = contentService.getTemplateContent(Long.parseLong(id));
		content.setTextContent(templateString);
		contentService.updateTemplateContent(content);
		
		return "Template updated successfully !!!";
	}
	
	@RequestMapping(value="/saveNewEmailContent", method=RequestMethod.POST)
	public @ResponseBody String saveNewEmailContent(@RequestParam String emailSubject, @RequestParam String sourceString,
									@RequestParam String deliveryString, @RequestParam String emailContentName, HttpSession session){
		System.out.println("In saveNewEmailContent... ");
		
		String loggedInUser = (String) session.getAttribute("loggedInUser");
		
		ContentEmail content = new ContentEmail();
		content.setName(emailContentName);
		content.setSourceContent(sourceString);
		content.setDeliveryContent(deliveryString);
		content.setSubject(emailSubject);
		content.setCreateDate(new Date());
		content.setCreatedByUser(loggedInUser);
		content.setModifiedDate(new Date());
		content.setModifiedByUser(loggedInUser);
		
		content = contentService.saveNewEmailContent(content);
		
		return "Email Content Saved";
	}
	
	@RequestMapping(value="/getEmailSource", method=RequestMethod.GET, produces=MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody ContentEmail getEmailSource(@RequestParam String id){
		System.out.println("In getEmailSource... ");
		
		ContentEmail content = contentService.getEmailContent(Long.parseLong(id));
		
		// remove the html part to reduce the traffic
		content.setDeliveryContent(null);
		
		return content;
	}
	
	@RequestMapping(value="/getEmailDeliveryContent", method=RequestMethod.GET)
	public @ResponseBody String getEmailDeliveryContent(@RequestParam String id){
		System.out.println("In getEmailDeliveryContent... ");
		
		ContentEmail content = contentService.getEmailContent(Long.parseLong(id));
		
		return content.getDeliveryContent();
	}
	
	@RequestMapping(value="/updateEmailContent", method=RequestMethod.POST)
	public @ResponseBody String updateEmailContent(@RequestParam String emailSubject, @RequestParam String sourceString, 
											@RequestParam String deliveryString, @RequestParam String emailConntentId, HttpSession session){
		System.out.println("In saveNewEmailContent... ");
		
		String loggedInUser = (String) session.getAttribute("loggedInUser");
		
		ContentEmail content = contentService.getEmailContent(Long.parseLong(emailConntentId));
		content.setSubject(emailSubject);
		content.setSourceContent(sourceString);
		content.setDeliveryContent(deliveryString);
		content.setModifiedDate(new Date());
		content.setModifiedByUser(loggedInUser);
		
		contentService.updateEmailContent(content);
		
		return "Email Content Saved";
	}
	
	@RequestMapping(value="/sendTestEmail", method=RequestMethod.POST)
	public @ResponseBody String sendTestEmail(@RequestParam String emailSubject, @RequestParam String testEmailAddress,
									@RequestParam String htmlString, @AuthenticationPrincipal NaasAccountHolderUser currentUser){
		System.out.println("In sendTestEmail... ");
		
		String testEmailSubject = "Test Email - " + emailSubject;
		
		final AtomicReference<TextMessage> message = new AtomicReference<TextMessage>();
		jmsQueueTemplate.send(new MessageCreator() {
			
			@Override
			public Message createMessage(Session session) throws JMSException {
				TextMessage textMessage = session.createTextMessage();
				textMessage.setText("TestEmail~~" + testEmailAddress + "~~" + testEmailSubject + "~~" + htmlString);
				message.set(textMessage);
				return message.get();
			}
		});		
		
		System.out.println("toAddres: " + testEmailAddress);
		
		return "Test Email Sent";
	}
	
	@RequestMapping(value="/sendTestSms", method=RequestMethod.POST)
	public @ResponseBody String sendTestSms(@RequestParam String smsContent, @RequestParam String testPhoneNumber, 
												@AuthenticationPrincipal NaasAccountHolderUser currentUser){
		System.out.println("In sendTestSms... ");
		
		String testSmsContent = "Test SMS - " + smsContent;
		
		final AtomicReference<TextMessage> message = new AtomicReference<TextMessage>();
		jmsQueueTemplate.send(new MessageCreator() {
			
			@Override
			public Message createMessage(Session session) throws JMSException {
				TextMessage textMessage = session.createTextMessage();
				textMessage.setText("TestSms~~" + testPhoneNumber + "~~" + testSmsContent);
				message.set(textMessage);
				return message.get();
			}
		});		
		
		System.out.println("testPhoneNumber: " + testPhoneNumber);
		
		return "Test SMS Sent";
	}
	
	@RequestMapping(value="/getSmsSource", method=RequestMethod.GET)
	public @ResponseBody String getSmsSource(@RequestParam String id){
		System.out.println("In getSmsSource... ");
		
		ContentSms content = contentService.getSmsContent(Long.parseLong(id));
		
		return content.getContent();
	}
	
	@RequestMapping(value="/saveNewSmsContent", method=RequestMethod.POST)
	public @ResponseBody String saveNewSmsContent(@RequestParam String smsString, 
			@RequestParam String smsName, 
			@RequestParam(required=false,name="sendForApproval") Boolean sendForApproval,
			@RequestParam(required=false,name="isApproved") Boolean isApproved,
			@RequestParam(required=false,name="lastRejectReason") String lastRejectReason,
			HttpSession session){
		System.out.println("In saveNewSmsContent... ");
		
		String loggedInUser = (String) session.getAttribute("loggedInUser");
		
		ContentSms content = new ContentSms();
		content.setName(smsName);
		content.setContent(smsString);

		content.setCreateDate(new Date());
		content.setCreatedByUser(loggedInUser);
		content.setModifiedDate(new Date());
		content.setModifiedByUser(loggedInUser);
		if(sendForApproval!=null){
			if(sendForApproval.booleanValue()){
				content.setStatus(ContentStatus.PENDING_APPROVAL);
			}else{
				content.setStatus(ContentStatus.DRAFT);
			}
		}
		
		if(isApproved!=null){
			if(isApproved.booleanValue()){
				content.setStatus(ContentStatus.APPROVED);
			}else{
				content.setLastRejectReason(lastRejectReason);
				content.setStatus(ContentStatus.DRAFT);
			}
		}
		
		content = contentService.saveNewSmsContent(content);
		
		session.setAttribute("smsContent", content);
		
		return "Content saved";
	}
	
	@RequestMapping(value="/updateSmsContent", method=RequestMethod.POST)
	public @ResponseBody String updateSmsContent(@RequestParam String smsString, 
			@RequestParam String smsName,
			@RequestParam(required=false,name="sendForApproval") Boolean sendForApproval,
			@RequestParam(required=false,name="isApproved") Boolean isApproved,
			@RequestParam(required=false,name="lastRejectReason") String lastRejectReason,
			HttpSession session){
		System.out.println("In updateSmsContent... "+lastRejectReason);
		
		ContentSms content = (ContentSms) session.getAttribute("smsContent");
		String loggedInUser = (String) session.getAttribute("loggedInUser");
		content.setName(smsName);
		content.setContent(smsString);
		content.setModifiedDate(new Date());
		content.setModifiedByUser(loggedInUser);
		
		if(sendForApproval!=null){
			contentService.sendForApproval(content, sendForApproval);
		}

		if(isApproved!=null){
			content.setLastRejectReason(lastRejectReason);
			contentService.approveOrRejectSmsContent(content, isApproved);
		}
		return "Content saved";
	}
}
