package com.safelogic.naas.ach.manager.web.service;

import java.util.Collections;
import java.util.List;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.safelogic.naas.ach.manager.web.dao.AccountHolderDAO;
import com.safelogic.naas.ach.manager.web.dao.AccountHolderUserDAO;
import com.safelogic.naas.ach.manager.web.model.AccountHolder;
import com.safelogic.naas.ach.manager.web.model.AccountHolderUser;
import com.safelogic.naas.ach.manager.web.model.Category;
import com.safelogic.naas.ach.manager.web.util.Context;

@Service
@Transactional
public class AccountHolderServiceImpl implements AccountHolderService{

	private Logger logger = LoggerFactory.getLogger(AccountHolderServiceImpl.class);
	

	private AccountHolderDAO accountHolderDao;
	
	
	private AccountHolderUserDAO accountHolderUserDao;
	
	@Autowired
	@Qualifier("emailService")
	private EmailService emailService;
	
	@Autowired
	private PasswordEncoder passwordEncoder;
	
	@Override
	public void setUpAccountHolder(AccountHolder accountHolder, AccountHolderUser firstAdminUser) {
		Category category = accountHolderDao.getCategory(accountHolder.getCategory().getIndustry(), accountHolder.getCategory().getSubIndustry());
		accountHolder.setCategory(category);
		accountHolderDao.create(accountHolder); // Create Account

		firstAdminUser.setAccountHolder(accountHolder);
		String randomPassword = generateRandomPassword();
		String encryptedPassword = passwordEncoder.encode(randomPassword);
		firstAdminUser.setPassword(encryptedPassword);
		firstAdminUser.setEnabled(true);
		
		accountHolderUserDao.create(firstAdminUser);//create user
		
		Context.getVal().setAdminEmail(getAdminEmail(firstAdminUser,randomPassword));
		
		List<String> toList = Collections.singletonList(firstAdminUser.getEmailId());

		emailService.sendEmail(toList,"NAAS", "Login credentials", "Body of Email");
		
	}

	private String getAdminEmail(AccountHolderUser firstAdminUser, String randomPassword) {
		String email = "To: "+firstAdminUser.getEmailId()+"<br>"+
					   "Subject: Account setup. Login instructions<br>"+
					   "Body: Welcome "+firstAdminUser.getFirstName()+"<br>"+
					   "Your password to login to NAAS portal is below<br>"+
					   "Password: <b>"+randomPassword+"</b>";
		return email;
	}

	//TODO: implement this
	private String generateRandomPassword() {
		return "admin";
	}

	@Override
	public AccountHolder getAccountHolder(String name) {
		return (AccountHolder)accountHolderDao.findByAttribute("name", name).get(0);
	}
	
	@Autowired
	@Qualifier("accountHolderDao")
	public void setAccountHolderDao(AccountHolderDAO naasAccountHolderRepository){
		this.accountHolderDao = naasAccountHolderRepository;
		this.accountHolderDao.setType(AccountHolder.class);
	}
	
	@Autowired
	@Qualifier("accountHolderUserDao")
	public void setAccountHolderUserDao(AccountHolderUserDAO naasAccountHolderUserRepository){
		this.accountHolderUserDao = naasAccountHolderUserRepository;
		this.accountHolderUserDao.setType(AccountHolderUser.class);
	}
}
