package com.safelogic.naas.ach.manager.web.customer.group;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

import org.hibernate.annotations.LazyCollection;
import org.hibernate.annotations.LazyCollectionOption;

import com.safelogic.naas.ach.manager.web.model.NaasEntity;

@Entity
@Table(name="data_type")
public class DataType extends NaasEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6885098260716354651L;

	@Column(name="display_text")
	private String displayText;
	
	@LazyCollection(LazyCollectionOption.FALSE)
	@ManyToMany
	@JoinTable(name="data_type_operator", 
				joinColumns= { @JoinColumn(name="data_type_id",referencedColumnName="id")},
				inverseJoinColumns={@JoinColumn(name="operator_id",referencedColumnName="id")})
	private List<Operator> operators;
	
	
	public DataType() {
		super();
	}

	public String getDisplayText() {
		return displayText;
	}

	public void setDisplayText(String displayText) {
		this.displayText = displayText;
	}


	public List<Operator> getOperators() {
		return operators;
	}

	public void setOperators(List<Operator> operators) {
		this.operators = operators;
	}
	
}
