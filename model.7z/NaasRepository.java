package com.safelogic.naas.ach.manager.web.dao;

import java.util.List;

public interface NaasRepository<NaasEntity>{
	public NaasEntity create(NaasEntity naasEntity);
    public NaasEntity read(long naasEntityId);
    public NaasEntity update(NaasEntity naasEntity);
    public boolean delete(NaasEntity naasEntity);
    public NaasEntity findById(long id);
    public NaasEntity findByName(String name);// these can return multiple..return type should be list ?
    public List<NaasEntity> findAll();
    public List<NaasEntity> findByAttribute(String attributeName, Object attributeValue);//return type should be list ?
    
  //since generics cant retain type info at runtime, we need to set type explictly
    public void setType(Class<NaasEntity> type);
}