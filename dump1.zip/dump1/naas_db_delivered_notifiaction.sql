-- MySQL dump 10.13  Distrib 5.7.12, for Win64 (x86_64)
--
-- Host: naas-demo.co6qvh4uzonj.us-east-1.rds.amazonaws.com    Database: naas_db
-- ------------------------------------------------------
-- Server version	5.6.27-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `delivered_notifiaction`
--

DROP TABLE IF EXISTS `delivered_notifiaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `delivered_notifiaction` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `create_date` datetime DEFAULT NULL,
  `create_user` varchar(255) DEFAULT NULL,
  `update_user` varchar(255) DEFAULT NULL,
  `update_date` datetime DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `accountHolder_ach_id` bigint(20) DEFAULT NULL,
  `contentEmail_id` bigint(20) DEFAULT NULL,
  `contentSms_id` bigint(20) DEFAULT NULL,
  `customer_id` bigint(20) DEFAULT NULL,
  `notification_id` bigint(20) DEFAULT NULL,
  `tracking_id` bigint(20) DEFAULT NULL,
  `emailOpenedOn` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKagqhd5cseinie1waigx76f4tp` (`accountHolder_ach_id`),
  KEY `FKs3cqejb4ya8afln58tyjfy8xj` (`contentEmail_id`),
  KEY `FKsq73iip627y42aefvsrhyyyg7` (`contentSms_id`),
  KEY `FKr7v220hbsry9urgett69lvrly` (`customer_id`),
  KEY `FK2fs9og1lh5kv2y0lacd36af8b` (`notification_id`),
  CONSTRAINT `FK2fs9og1lh5kv2y0lacd36af8b` FOREIGN KEY (`notification_id`) REFERENCES `notification` (`id`),
  CONSTRAINT `FKagqhd5cseinie1waigx76f4tp` FOREIGN KEY (`accountHolder_ach_id`) REFERENCES `account_holder_master` (`ach_id`),
  CONSTRAINT `FKr7v220hbsry9urgett69lvrly` FOREIGN KEY (`customer_id`) REFERENCES `customer` (`id`),
  CONSTRAINT `FKs3cqejb4ya8afln58tyjfy8xj` FOREIGN KEY (`contentEmail_id`) REFERENCES `email_content` (`id`),
  CONSTRAINT `FKsq73iip627y42aefvsrhyyyg7` FOREIGN KEY (`contentSms_id`) REFERENCES `sms_content` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=71 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `delivered_notifiaction`
--

LOCK TABLES `delivered_notifiaction` WRITE;
/*!40000 ALTER TABLE `delivered_notifiaction` DISABLE KEYS */;
INSERT INTO `delivered_notifiaction` VALUES (2,'2016-09-16 11:50:28','sashi_v@hotmail.com','sashi_v@hotmail.com','2016-09-16 11:50:28',NULL,1,3,1,3093,18,NULL,NULL),(4,'2016-09-16 20:57:00','sashi_v@hotmail.com','sashi_v@hotmail.com','2016-09-16 20:57:00',NULL,1,3,1,3091,10,NULL,NULL),(6,'2016-09-17 00:47:27','sashi_v@hotmail.com','sashi_v@hotmail.com','2016-09-17 00:47:27',NULL,1,6,4,3091,11,NULL,NULL),(8,'2016-09-17 19:36:34','sashi_v@hotmail.com','sashi_v@hotmail.com','2016-09-17 19:36:34',NULL,1,3,1,3091,19,NULL,NULL),(9,'2016-09-26 22:35:57','sashi_v@hotmail.com','sashi_v@hotmail.com','2016-09-26 22:35:57',NULL,1,3,1,3093,20,2978150394899781,'2016-09-26 23:59:43'),(10,'2016-09-27 08:38:17','sashi_v@hotmail.com','sashi_v@hotmail.com','2016-09-27 08:38:17',NULL,1,3,1,3093,21,7968763270754794,'2016-09-27 08:44:58'),(12,'2016-09-27 08:54:35','sashi_v@hotmail.com','sashi_v@hotmail.com','2016-09-27 08:54:35',NULL,1,3,NULL,3093,24,3953323274201459,'2016-09-27 21:24:28'),(13,'2016-09-27 21:49:46','sashi_v@hotmail.com','sashi_v@hotmail.com','2016-09-27 21:49:46',NULL,1,3,NULL,3093,25,6748287109571471,'2016-09-27 21:54:15'),(14,'2016-09-27 22:35:32','sashi_v@hotmail.com','sashi_v@hotmail.com','2016-09-27 22:35:32',NULL,1,3,NULL,3093,26,8526322096181727,'2016-09-27 23:09:48'),(16,'2016-09-28 02:05:15','sashi_v@hotmail.com','sashi_v@hotmail.com','2016-09-28 02:05:15',NULL,1,NULL,NULL,3091,27,9603553147303023,NULL),(18,'2016-09-28 02:11:46','sashi_v@hotmail.com','sashi_v@hotmail.com','2016-09-28 02:11:46',NULL,1,3,1,3091,28,9039684607985695,'2016-09-28 02:17:03'),(20,'2016-09-29 00:56:51','sashi_v@hotmail.com','sashi_v@hotmail.com','2016-09-29 00:56:51',NULL,1,NULL,NULL,3091,29,23596174216643317,NULL),(22,'2016-09-29 00:58:04','sashi_v@hotmail.com','sashi_v@hotmail.com','2016-09-29 00:58:04',NULL,1,NULL,NULL,3091,30,61254029648844,NULL),(24,'2016-09-29 00:59:52','sashi_v@hotmail.com','sashi_v@hotmail.com','2016-09-29 00:59:52',NULL,1,3,1,3091,31,170928469596495,'2016-09-29 01:09:05'),(25,'2016-09-29 01:06:52','sashi_v@hotmail.com','sashi_v@hotmail.com','2016-09-29 01:06:52',NULL,1,3,NULL,3091,32,7961653235646556,'2016-09-29 01:11:50'),(26,'2016-09-29 01:07:53','sashi_v@hotmail.com','sashi_v@hotmail.com','2016-09-29 01:07:53',NULL,1,NULL,1,3091,33,30306627303391853,NULL),(27,'2016-10-01 18:15:47','sashi_v@hotmail.com','sashi_v@hotmail.com','2016-10-01 18:15:47',NULL,1,3,NULL,3093,34,2713707017596704,'2016-10-02 15:15:08'),(28,'2016-10-02 23:19:20','sashi_v@hotmail.com','sashi_v@hotmail.com','2016-10-02 23:19:20',NULL,1,3,1,3093,12,5186957662179714,'2016-10-03 00:45:44'),(29,'2016-10-04 14:38:40','sashi_v@hotmail.com','sashi_v@hotmail.com','2016-10-04 14:38:40',NULL,1,3,1,3093,35,7516831461081435,'2016-10-04 14:44:15'),(30,'2016-10-09 00:59:38','fero90@yahoo.com','fero90@yahoo.com','2016-10-09 00:59:38',NULL,2,5,8,3091,37,1749021636400161,'2016-10-09 01:04:19'),(31,'2016-10-12 23:02:22','sashi_v@hotmail.com','sashi_v@hotmail.com','2016-10-12 23:02:22',NULL,1,NULL,NULL,3093,38,30976898773454453,NULL),(32,'2016-10-12 23:11:07','sashi_v@hotmail.com','sashi_v@hotmail.com','2016-10-12 23:11:07',NULL,1,NULL,NULL,3093,39,8904561711191002,NULL),(33,'2016-10-12 23:24:39','sashi_v@hotmail.com','sashi_v@hotmail.com','2016-10-12 23:24:39',NULL,1,NULL,NULL,3093,40,2963987045735128,NULL),(34,'2016-10-12 23:28:31','sashi_v@hotmail.com','sashi_v@hotmail.com','2016-10-12 23:28:31',NULL,1,3,NULL,3093,41,24034805799575187,'2016-10-12 23:46:17'),(35,'2016-10-12 23:30:04','sashi_v@hotmail.com','sashi_v@hotmail.com','2016-10-12 23:30:04',NULL,1,NULL,NULL,3093,42,967091535958653,NULL),(36,'2016-10-12 23:41:00','sashi_v@hotmail.com','sashi_v@hotmail.com','2016-10-12 23:41:00',NULL,1,NULL,1,3093,43,9467824080424553,NULL),(37,'2016-10-13 00:11:49','sashi_v@hotmail.com','sashi_v@hotmail.com','2016-10-13 00:11:49',NULL,1,3,1,3093,44,4733905726303289,'2016-10-13 00:59:35'),(38,'2016-10-13 01:19:19','sashi_v@hotmail.com','sashi_v@hotmail.com','2016-10-13 01:19:19',NULL,1,3,1,3091,46,7599988350133955,'2016-10-13 02:00:20'),(41,'2016-10-15 23:30:40','sashi_v@hotmail.com','sashi_v@hotmail.com','2016-10-15 23:30:40',NULL,1,6,4,3091,11,9269109946208466,'2016-10-16 05:50:14'),(42,'2016-10-16 00:21:34','sashi_v@hotmail.com','sashi_v@hotmail.com','2016-10-16 00:21:34',NULL,1,3,NULL,3093,53,34860153393968585,'2016-10-16 00:27:45'),(43,'2016-10-16 00:23:19','sashi_v@hotmail.com','sashi_v@hotmail.com','2016-10-16 00:23:19',NULL,1,5,9,3093,54,5133342445179074,'2016-10-16 01:28:44'),(44,'2016-10-16 17:01:44','sashi_v@hotmail.com','sashi_v@hotmail.com','2016-10-16 17:01:44',NULL,1,3,1,3093,12,5264521286007566,NULL),(45,'2016-10-16 17:02:51','sashi_v@hotmail.com','sashi_v@hotmail.com','2016-10-16 17:02:51',NULL,1,3,1,3093,13,53579093770786956,NULL),(46,'2016-10-16 17:26:00','sashi_v@hotmail.com','sashi_v@hotmail.com','2016-10-16 17:26:00',NULL,1,3,NULL,3093,56,3497938075851018,'2016-10-16 17:30:36'),(47,'2016-10-18 01:37:31','sashi_v@hotmail.com','sashi_v@hotmail.com','2016-10-18 01:37:31',NULL,1,3,NULL,3093,59,33091921553979364,NULL),(48,'2016-10-18 01:50:49','sashi_v@hotmail.com','sashi_v@hotmail.com','2016-10-18 01:50:49',NULL,1,3,NULL,3093,60,9307443563572965,NULL),(49,'2016-10-18 01:53:35','sashi_v@hotmail.com','sashi_v@hotmail.com','2016-10-18 01:53:35',NULL,1,3,1,3093,61,520656755416011,NULL),(50,'2016-10-23 17:24:24','sashi_v@hotmail.com','sashi_v@hotmail.com','2016-10-23 17:24:24',NULL,1,7,7,3093,63,7275929962812003,NULL),(51,'2016-10-23 18:46:23','sashi_v@hotmail.com','sashi_v@hotmail.com','2016-10-23 18:46:23',NULL,1,4,NULL,3093,64,7958082771239783,'2016-10-23 18:47:27'),(52,'2016-10-31 23:34:24','sashi_v@hotmail.com','sashi_v@hotmail.com','2016-10-31 23:34:24',NULL,1,3,1,3091,65,4336125110228317,'2016-10-31 23:35:01'),(53,'2016-11-04 20:58:40','sashi_v@hotmail.com','sashi_v@hotmail.com','2016-11-04 20:58:40',NULL,1,3,1,3093,66,4924017028968585,NULL),(54,'2016-11-04 23:30:34','sashi_v@hotmail.com','sashi_v@hotmail.com','2016-11-04 23:30:34',NULL,1,3,NULL,3093,68,22226176639896,'2016-11-04 23:32:57'),(55,'2016-11-04 23:33:20','sashi_v@hotmail.com','sashi_v@hotmail.com','2016-11-04 23:33:20',NULL,1,4,NULL,3093,69,572480325837751,'2016-11-04 23:39:41'),(56,'2016-11-04 23:38:40','sashi_v@hotmail.com','sashi_v@hotmail.com','2016-11-04 23:38:40',NULL,1,5,NULL,3093,70,9867677763434547,'2016-11-04 23:39:43'),(57,'2016-11-04 23:51:16','sashi_v@hotmail.com','sashi_v@hotmail.com','2016-11-04 23:51:16',NULL,1,3,NULL,3093,71,7273337111667022,'2016-11-04 23:53:16'),(58,'2016-11-05 04:42:09','sashi_v@hotmail.com','sashi_v@hotmail.com','2016-11-05 04:42:09',NULL,1,7,NULL,3093,72,6914675308867227,'2016-11-05 04:42:57'),(59,'2016-11-05 16:14:30','sashi_v@hotmail.com','sashi_v@hotmail.com','2016-11-05 16:14:30',NULL,1,3,NULL,3093,73,42114987268918314,'2016-11-05 16:15:30'),(60,'2016-11-05 16:16:05','sashi_v@hotmail.com','sashi_v@hotmail.com','2016-11-05 16:16:05',NULL,1,5,NULL,3093,74,16426534135779325,'2016-11-05 16:16:59'),(61,'2016-11-05 16:31:48','sashi_v@hotmail.com','sashi_v@hotmail.com','2016-11-05 16:31:48',NULL,1,3,NULL,3093,75,8558285365978645,'2016-11-05 16:32:39'),(62,'2016-11-05 16:41:17','sashi_v@hotmail.com','sashi_v@hotmail.com','2016-11-05 16:41:17',NULL,1,6,NULL,3093,76,9544106864594847,'2016-11-05 17:00:28'),(63,'2016-11-06 00:23:15','sashi_v@hotmail.com','sashi_v@hotmail.com','2016-11-06 00:23:15',NULL,1,NULL,NULL,2144,78,6849069209893479,NULL),(64,'2016-11-06 00:24:57','sashi_v@hotmail.com','sashi_v@hotmail.com','2016-11-06 00:24:57',NULL,1,3,NULL,3093,79,6848056663264102,'2016-11-06 09:17:46'),(65,'2016-11-06 09:36:44','sashi_v@hotmail.com','sashi_v@hotmail.com','2016-11-06 09:36:44',NULL,1,7,NULL,3093,80,13733341517765008,'2016-11-06 09:37:36'),(66,'2016-11-07 16:44:57','sashi_v@hotmail.com','sashi_v@hotmail.com','2016-11-07 16:44:57',NULL,1,6,NULL,3093,81,23127371764025006,'2016-12-06 20:47:10'),(67,'2016-11-09 23:55:28','sashi_v@hotmail.com','sashi_v@hotmail.com','2016-11-09 23:55:28',NULL,1,3,NULL,3093,82,46272368359225347,NULL),(68,'2016-11-10 00:08:35','sashi_v@hotmail.com','sashi_v@hotmail.com','2016-11-10 00:08:35',NULL,1,5,NULL,3093,83,8716505913063635,'2016-11-10 00:10:32'),(69,'2016-12-08 03:09:41','sashi_v@hotmail.com','sashi_v@hotmail.com','2016-12-08 03:09:41',NULL,1,3,1,3093,84,6266088394187141,'2016-12-19 00:21:29'),(70,'2017-02-08 19:14:15','sashi_v@hotmail.com','sashi_v@hotmail.com','2017-02-08 19:14:15',NULL,1,NULL,1,3091,85,9465141478485365,NULL);
/*!40000 ALTER TABLE `delivered_notifiaction` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-02-28  7:10:49
