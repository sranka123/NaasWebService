-- MySQL dump 10.13  Distrib 5.7.12, for Win64 (x86_64)
--
-- Host: naas-demo.co6qvh4uzonj.us-east-1.rds.amazonaws.com    Database: naas_db
-- ------------------------------------------------------
-- Server version	5.6.27-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `customer_group_mapping`
--

DROP TABLE IF EXISTS `customer_group_mapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customer_group_mapping` (
  `customer_id` bigint(20) NOT NULL,
  `group_id` bigint(20) NOT NULL,
  KEY `FK_pspj4b07u96bwgfeixhgdf039` (`group_id`),
  KEY `FK_f4vj0wuji8nud0pb2kvbq8ows` (`customer_id`),
  CONSTRAINT `FK_f4vj0wuji8nud0pb2kvbq8ows` FOREIGN KEY (`customer_id`) REFERENCES `customer` (`id`),
  CONSTRAINT `FK_pspj4b07u96bwgfeixhgdf039` FOREIGN KEY (`group_id`) REFERENCES `customer_group` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer_group_mapping`
--

LOCK TABLES `customer_group_mapping` WRITE;
/*!40000 ALTER TABLE `customer_group_mapping` DISABLE KEYS */;
INSERT INTO `customer_group_mapping` VALUES (2216,10),(2285,10),(2295,10),(2316,10),(2342,10),(2390,10),(2435,10),(2438,10),(2441,10),(2454,10),(2502,10),(2567,10),(2576,10),(2601,10),(2667,10),(2730,10),(2732,10),(2733,10),(2739,10),(2742,10),(2744,10),(2797,10),(2800,10),(2821,10),(2832,10),(2859,10),(2864,10),(2975,10),(2996,10),(3005,10),(3052,10),(2216,11),(2285,11),(2295,11),(2316,11),(2342,11),(2390,11),(2435,11),(2438,11),(2441,11),(2454,11),(2502,11),(2567,11),(2576,11),(2601,11),(2667,11),(2730,11),(2732,11),(2733,11),(2739,11),(2742,11),(2744,11),(2797,11),(2800,11),(2821,11),(2832,11),(2859,11),(2864,11),(2975,11),(2996,11),(3005,11),(3052,11),(3093,14),(3093,15),(3093,16),(3093,17),(3093,18),(3093,19),(3093,20),(3093,22),(3093,23),(3093,24),(3093,25),(3093,26),(3093,27),(3093,28),(3091,34),(3091,35),(3093,36),(3093,37),(3093,38),(3091,39),(3093,40),(3093,41),(3093,42),(3093,43),(3093,44),(3093,45),(3093,46),(3091,47),(3091,48),(3093,49),(3093,50),(3093,51),(3093,52),(3093,53),(3093,54),(3093,55),(3093,56),(3093,57),(3093,58),(3093,59),(3093,60),(3093,61),(3093,62),(3093,63),(3093,64),(3093,65),(3093,66),(3093,67),(3091,68),(3093,69),(3093,70),(3093,71),(3093,72),(3093,73),(3093,74),(3093,75),(3093,76),(3093,77),(3093,78),(3093,79),(3093,80),(2144,81),(3093,82),(3093,83),(3093,84),(3093,85),(3093,86),(3093,87),(3091,88);
/*!40000 ALTER TABLE `customer_group_mapping` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-02-28  7:10:41
