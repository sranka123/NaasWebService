-- MySQL dump 10.13  Distrib 5.7.12, for Win64 (x86_64)
--
-- Host: naas-demo.co6qvh4uzonj.us-east-1.rds.amazonaws.com    Database: naas_db
-- ------------------------------------------------------
-- Server version	5.6.27-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `industry_mapping_table`
--

DROP TABLE IF EXISTS `industry_mapping_table`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `industry_mapping_table` (
  `industry_mapping_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `industry_id` bigint(20) NOT NULL,
  `sub_industry_id` bigint(20) NOT NULL,
  PRIMARY KEY (`industry_mapping_id`),
  KEY `industry_id_FK` (`industry_id`),
  KEY `sub_industry_id_FK` (`sub_industry_id`),
  CONSTRAINT `industry_mapping_table_ibfk_1` FOREIGN KEY (`industry_id`) REFERENCES `industry_master` (`industry_id`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `industry_mapping_table_ibfk_2` FOREIGN KEY (`sub_industry_id`) REFERENCES `sub_industry_master` (`sub_industry_id`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=163 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `industry_mapping_table`
--

LOCK TABLES `industry_mapping_table` WRITE;
/*!40000 ALTER TABLE `industry_mapping_table` DISABLE KEYS */;
INSERT INTO `industry_mapping_table` VALUES (1,1,1),(2,1,2),(3,1,3),(4,1,4),(5,2,5),(6,2,6),(7,2,7),(8,2,8),(9,2,9),(10,2,10),(11,2,11),(12,2,12),(13,2,13),(14,2,14),(15,2,15),(16,3,16),(17,3,17),(18,3,18),(19,3,19),(20,3,20),(21,3,21),(22,3,22),(23,3,23),(24,3,24),(25,3,25),(26,3,26),(27,4,27),(28,4,28),(29,4,29),(30,4,30),(31,4,31),(32,4,32),(33,4,33),(34,5,34),(35,5,35),(36,5,36),(37,5,37),(38,5,38),(39,5,39),(40,5,40),(41,6,41),(42,6,42),(43,6,43),(44,6,44),(45,6,45),(46,6,46),(47,6,47),(48,7,48),(49,7,49),(50,7,50),(51,7,51),(52,7,52),(53,7,53),(54,7,54),(55,7,55),(56,7,56),(57,7,57),(58,8,58),(59,8,59),(60,8,60),(61,8,61),(62,8,62),(63,9,63),(64,9,64),(65,9,65),(66,9,66),(67,9,67),(68,9,68),(69,9,69),(70,9,70),(71,9,71),(72,9,72),(73,9,73),(74,9,74),(75,10,75),(76,10,76),(77,10,77),(78,10,78),(79,10,79),(80,10,80),(81,10,81),(82,10,82),(83,10,83),(84,10,84),(85,10,85),(86,10,86),(87,10,87),(88,10,88),(89,11,89),(90,11,90),(91,11,91),(92,11,92),(93,11,93),(94,11,94),(95,12,95),(96,12,96),(97,12,97),(98,12,98),(99,12,99),(100,12,100),(101,12,101),(102,13,102),(103,13,103),(104,13,104),(105,13,105),(106,13,106),(107,13,107),(108,13,108),(109,14,109),(110,14,110),(111,14,111),(112,14,112),(113,14,113),(114,14,114),(115,14,115),(116,14,116),(117,14,117),(118,14,118),(119,14,119),(120,14,120),(121,14,121),(122,14,122),(123,14,123),(124,15,124),(125,15,125),(126,15,126),(127,15,127),(128,15,128),(129,16,129),(130,16,130),(131,16,131),(132,16,132),(133,16,133),(134,16,134),(135,17,135),(136,17,136),(137,17,137),(138,17,138),(139,17,139),(140,17,140),(141,17,141),(142,17,142),(143,18,143),(144,18,144),(145,18,145),(146,18,146),(147,18,147),(148,18,148),(149,18,149),(150,18,150),(151,18,151),(152,18,152),(153,18,153),(154,19,154),(155,19,155),(156,19,156),(157,19,157),(158,19,158),(159,19,159),(160,19,160),(161,19,161),(162,19,162);
/*!40000 ALTER TABLE `industry_mapping_table` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-02-28  7:10:37
