-- MySQL dump 10.13  Distrib 5.7.12, for Win64 (x86_64)
--
-- Host: naas-demo.co6qvh4uzonj.us-east-1.rds.amazonaws.com    Database: naas_db
-- ------------------------------------------------------
-- Server version	5.6.27-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `field`
--

DROP TABLE IF EXISTS `field`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `field` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `entity_id` bigint(20) DEFAULT NULL,
  `display_text` varchar(255) DEFAULT NULL,
  `data_type_id` bigint(20) DEFAULT NULL,
  `isMetadata` bit(1) DEFAULT NULL,
  `xpath` varchar(255) DEFAULT NULL,
  `create_user` varchar(200) DEFAULT NULL,
  `update_user` varchar(200) DEFAULT NULL,
  `create_date` datetime DEFAULT NULL,
  `update_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKdwonfpdusiq6x6ntqi2k6sxgi` (`data_type_id`),
  KEY `FK689t1j2ywr3hpkctt4t1685kk` (`entity_id`),
  CONSTRAINT `FK689t1j2ywr3hpkctt4t1685kk` FOREIGN KEY (`entity_id`) REFERENCES `entity` (`id`),
  CONSTRAINT `FKdwonfpdusiq6x6ntqi2k6sxgi` FOREIGN KEY (`data_type_id`) REFERENCES `data_type` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `field`
--

LOCK TABLES `field` WRITE;
/*!40000 ALTER TABLE `field` DISABLE KEYS */;
INSERT INTO `field` VALUES (1,'firstName',1,'First Name',1,'\0',NULL,'Sashi Rajan','Sashi Rajan','2016-06-03 09:38:39','2016-06-03 09:38:39'),(2,'lastName',1,'Last Name',1,'\0',NULL,'Sashi Rajan','Sashi Rajan','2016-06-03 09:38:39','2016-06-03 09:38:39'),(3,'middleName',1,'Middle Name',1,'\0',NULL,'Sashi Rajan','Sashi Rajan','2016-06-03 09:38:39','2016-06-03 09:38:39'),(4,'emailId',1,'Email Address',1,'\0',NULL,'Sashi Rajan','Sashi Rajan','2016-06-03 09:38:39','2016-06-03 09:38:39'),(5,'phoneNumber',1,'Phone Number',1,'\0',NULL,'Sashi Rajan','Sashi Rajan','2016-06-03 09:38:39','2016-06-03 09:38:39'),(6,'useEmail',1,'Email Opted',4,'\0',NULL,'Sashi Rajan','Sashi Rajan','2016-06-03 09:38:39','2016-06-03 09:38:39'),(7,'usePhone',1,'SMS Opted',4,'\0',NULL,'Sashi Rajan','Sashi Rajan','2016-06-03 09:38:39','2016-06-03 09:38:39'),(8,'address1',1,'Address 1',1,'\0',NULL,'Sashi Rajan','Sashi Rajan','2016-06-03 09:38:39','2016-06-03 09:38:39'),(9,'address2',1,'Address 2',1,'\0',NULL,'Sashi Rajan','Sashi Rajan','2016-06-03 09:38:39','2016-06-03 09:38:39'),(10,'city',1,'City',1,'\0',NULL,'Sashi Rajan','Sashi Rajan','2016-06-03 09:38:39','2016-06-03 09:38:39'),(11,'state',1,'State',1,'\0',NULL,'Sashi Rajan','Sashi Rajan','2016-06-03 09:38:39','2016-06-03 09:38:39'),(12,'zipcode',1,'Zip Code',1,'\0',NULL,'Sashi Rajan','Sashi Rajan','2016-06-03 09:38:39','2016-06-03 09:38:39'),(13,'vin',2,'VIN',1,'','/metaData/vehicle/vin','Sashi Rajan','Sashi Rajan','2016-06-03 09:38:39','2016-06-03 09:38:39'),(14,'model',2,'Model',1,'','/metaData/vehicle/model','Sashi Rajan','Sashi Rajan','2016-06-03 09:38:39','2016-06-03 09:38:39'),(15,'modelYear',2,'Model Year',2,'','/metaData/vehicle/modelYear','Sashi Rajan','Sashi Rajan','2016-06-03 09:38:39','2016-06-03 09:38:39'),(16,'purchaseType',2,'Purchase Type',1,'','/metaData/vehicle/purchaseType','Sashi Rajan','Sashi Rajan','2016-06-03 09:38:39','2016-06-03 09:38:39'),(17,'interiorColor',2,'Interior Color',1,'','/metaData/vehicle/interiorColor','Sashi Rajan','Sashi Rajan','2016-06-03 09:38:39','2016-06-03 09:38:39'),(18,'exteriorColor',2,'Exterior Color',1,'','/metaData/vehicle/exteriorColor','Sashi Rajan','Sashi Rajan','2016-06-03 09:38:39','2016-06-03 09:38:39'),(19,'mileage',2,'Mileage',2,'','/metaData/vehicle/service/mileage','Sashi Rajan','Sashi Rajan','2016-06-03 09:38:39','2016-06-03 09:38:39'),(20,'dateOfPurchase',2,'Purchase Date',3,'','/metaData/vehicle/dateOfPurchase','Sashi Rajan','Sashi Rajan','2016-06-03 09:38:39','2016-06-03 09:38:39'),(21,'lastServiceDate',2,'Last Service Date',3,'','/metaData/vehicle/service/lastServiceDate','Sashi Rajan','Sashi Rajan','2016-06-03 09:38:39','2016-06-03 09:38:39'),(22,'otherPhone',1,'Other Phoner',1,'','/metaData/customer/otherPhone','Sashi Rajan','Sashi Rajan','2016-06-03 09:38:39','2016-06-03 09:38:39');
/*!40000 ALTER TABLE `field` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-02-28  7:10:36
