--Add new column accountHolder_ach_id to customer_group table
ALTER TABLE naas_db.customer_group ADD( `accountHolder_ach_id` bigint(20) DEFAULT NULL);

ALTER TABLE naas_db.customer_group ADD CONSTRAINT fk_ach_id FOREIGN KEY (accountHolder_ach_id) REFERENCES `account_holder_master` (`ach_id`);
