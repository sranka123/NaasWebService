package com.safelogic.naas.ach.manager.web.customer.group;

import java.util.Arrays;

import org.junit.Test;

import com.safelogic.naas.ach.manager.web.model.AccountHolder;

public class CustomerGroupServiceTest {
	
	
	
	@Test
	public void simpleSelect(){
		
		AccountHolder accountHolder = new AccountHolder();
		accountHolder.setId(1);
		accountHolder.setName("Avaya");
		
		SearchQuery query = new SearchQuery();
		query.setId(1);
		query.setName("select_qx60_car");
		
		MetadataDefinition custMetadataDefinition = new MetadataDefinition();
		custMetadataDefinition.setId(1);
		custMetadataDefinition.setAccountHolder(accountHolder);
		custMetadataDefinition.setName("customer");
		
		MetadataDefinition vehicelMetadataDefinition = new MetadataDefinition();
		vehicelMetadataDefinition.setId(2);
		vehicelMetadataDefinition.setAccountHolder(accountHolder);
		vehicelMetadataDefinition.setName("vehicel");
		
		Operator equalsOp = new Operator();
		equalsOp.setId(1);
		equalsOp.setName("equals");
		equalsOp.setSymbol("=");
		
		Operator startsWithOp = new Operator();
		startsWithOp.setId(5);
		startsWithOp.setName("starts_with");
		
		
		DataType stringDataType = new DataType();
		stringDataType.setName("string");
		stringDataType.setId(1);
		stringDataType.setOperators(Arrays.asList(equalsOp,startsWithOp));
		
		EntityObj customerEntity = new EntityObj();
		customerEntity.setAccountHolder(accountHolder);
		customerEntity.setId(1);
		customerEntity.setMetadataDefinition(custMetadataDefinition);
		customerEntity.setName("customer");
		
		EntityObj vehicelEntity = new EntityObj();
		vehicelEntity.setAccountHolder(accountHolder);
		vehicelEntity.setId(2);
		vehicelEntity.setMetadataDefinition(vehicelMetadataDefinition);
		vehicelEntity.setName("vehicel");
		
		Field modelField = new Field();
		modelField.setDataType(stringDataType);
		modelField.setEntityObj(vehicelEntity);
		modelField.setId(1);
		modelField.setMetadata(true);
		modelField.setxPath("/metaData/vehicle/model");
		modelField.setName("model");
		
		SearchQuery modelEqualsQuery = new SearchQuery();
		modelEqualsQuery.setId(1);
		modelEqualsQuery.setName("QX60_models");
		
		
		
		ConditionLine modelEquals = new ConditionLine();
		modelEquals.setAccountHolder(accountHolder);
		modelEquals.setField(modelField);
		modelEquals.setOperator(equalsOp);
		modelEquals.setValueText("QX60");
		modelEquals.setId(1);
		modelEquals.setSearchQuery(modelEqualsQuery);
		
		modelEqualsQuery.setConditionLines(Arrays.asList(modelEquals));
		

				
		System.out.println("-->simpleSelect");
		System.out.println(modelEqualsQuery.getSQLQuery());
		String sqlRegex = "select\\s+id\\s*,\\s*firstName\\s*,\\s*lastName\\s*,\\s*extractvalue\\s*\\(\\s*metadata\\s*,\\s*'\\/metaData\\/vehicle\\/vin'\\s*\\)\\s+from\\s+customer\\s+where\\s+extractvalue\\s*\\(\\s*metadata\\s*,\\s*'\\/metaData\\/vehicle\\/model'\\s*\\)\\s*=\\s*'QX60'\\s*;";
		
		//assertThat(modelEqualsQuery.getSQLQuery(), Matchers.matchesPattern(sqlRegex));
		
	}
	
	
	@Test
	public void likeAndGreaterThan(){
		
		AccountHolder accountHolder = new AccountHolder();
		accountHolder.setId(1);
		accountHolder.setName("Avaya");
		
		SearchQuery query = new SearchQuery();
		query.setId(1);
		query.setName("like_qx60_car_and_dateofpurchase_after_12");
		
		MetadataDefinition custMetadataDefinition = new MetadataDefinition();
		custMetadataDefinition.setId(1);
		custMetadataDefinition.setAccountHolder(accountHolder);
		custMetadataDefinition.setName("customer");
		
		MetadataDefinition vehicelMetadataDefinition = new MetadataDefinition();
		vehicelMetadataDefinition.setId(2);
		vehicelMetadataDefinition.setAccountHolder(accountHolder);
		vehicelMetadataDefinition.setName("vehicel");
		
		Operator equalsOp = new Operator();
		equalsOp.setId(1);
		equalsOp.setName("equals");
		equalsOp.setSymbol("=");
		
		Operator likeOp = new Operator();
		likeOp.setId(7);
		likeOp.setName("like");
		likeOp.setSymbol("like");		
		
		Operator greaterThanOp = new Operator();
		greaterThanOp.setId(3);
		greaterThanOp.setName("greater_than");
		greaterThanOp.setSymbol(">");
		
		
		DataType stringDataType = new DataType();
		stringDataType.setName("string");
		stringDataType.setId(1);
		stringDataType.setOperators(Arrays.asList(equalsOp,likeOp));
		
		DataType dateDataType = new DataType();
		dateDataType.setName("date");
		dateDataType.setId(3);
		dateDataType.setOperators(Arrays.asList(equalsOp,greaterThanOp));		
		
		EntityObj customerEntity = new EntityObj();
		customerEntity.setAccountHolder(accountHolder);
		customerEntity.setId(1);
		customerEntity.setMetadataDefinition(custMetadataDefinition);
		customerEntity.setName("customer");
		
		EntityObj vehicelEntity = new EntityObj();
		vehicelEntity.setAccountHolder(accountHolder);
		vehicelEntity.setId(2);
		vehicelEntity.setMetadataDefinition(vehicelMetadataDefinition);
		vehicelEntity.setName("vehicel");
		
		Field modelField = new Field();
		modelField.setDataType(stringDataType);
		modelField.setEntityObj(vehicelEntity);
		modelField.setId(1);
		modelField.setMetadata(true);
		modelField.setxPath("/metaData/vehicle/model");
		modelField.setName("model");
		
		Field dateOfPurchasedField = new Field();
		dateOfPurchasedField.setDataType(dateDataType);
		dateOfPurchasedField.setEntityObj(vehicelEntity);
		dateOfPurchasedField.setId(2);
		dateOfPurchasedField.setMetadata(true);
		dateOfPurchasedField.setxPath("/metaData/vehicle/dateOfPurchase");
		dateOfPurchasedField.setName("dateOfPurchase");		
		
		SearchQuery modelLikeQuery = new SearchQuery();
		modelLikeQuery.setId(1);
		modelLikeQuery.setName("QX60_Post_12");
		
		
		
		ConditionLine modelLike = new ConditionLine();
		modelLike.setAccountHolder(accountHolder);
		modelLike.setField(modelField);
		modelLike.setOperator(likeOp);
		modelLike.setValueText("QX");
		modelLike.setId(1);
		modelLike.setSearchQuery(modelLikeQuery);
		
		ConditionLine purchaseAfter = new ConditionLine();
		purchaseAfter.setAccountHolder(accountHolder);
		purchaseAfter.setField(dateOfPurchasedField);
		purchaseAfter.setOperator(greaterThanOp);
		purchaseAfter.setValueText("06/27/2012");
		purchaseAfter.setId(2);
		purchaseAfter.setSearchQuery(modelLikeQuery);		
		
		modelLikeQuery.setConditionLines(Arrays.asList(modelLike,purchaseAfter));
		
		
		System.out.println("-->likeAndGreaterThan");
		System.out.println(modelLikeQuery.getSQLQuery());		
//		String sqlRegex = "select\\s+id\\s*,\\s*firstName\\s*,\\s*lastName\\s*,\\s*extractvalue\\s*\\(\\s*metadata\\s*,\\s*'\\/metaData\\/vehicle\\/vin'\\s*\\)\\s+from\\s+customer\\s+where\\s+extractvalue\\s*\\(\\s*metadata\\s*,\\s*'\\/metaData\\/vehicle\\/model'\\s*\\)\\s*=\\s*'QX60'\\s*;";
//		
//		assertThat(service.getSQLQuery(modelLikeQuery), Matchers.matchesPattern(sqlRegex));
		
	}
	
	@Test
	public void mileageLessThan30K(){
		
		AccountHolder accountHolder = new AccountHolder();
		accountHolder.setId(1);
		accountHolder.setName("Avaya");
		
		SearchQuery query = new SearchQuery();
		query.setId(1);
		query.setName("mileage_less_than_30K");
		
		MetadataDefinition custMetadataDefinition = new MetadataDefinition();
		custMetadataDefinition.setId(1);
		custMetadataDefinition.setAccountHolder(accountHolder);
		custMetadataDefinition.setName("customer");
		
		MetadataDefinition vehicelMetadataDefinition = new MetadataDefinition();
		vehicelMetadataDefinition.setId(2);
		vehicelMetadataDefinition.setAccountHolder(accountHolder);
		vehicelMetadataDefinition.setName("vehicel");
		
		Operator lessThanOp = new Operator();
		lessThanOp.setId(2);
		lessThanOp.setName("less_than");
		lessThanOp.setSymbol("<");
		
		DataType numberDataType = new DataType();
		numberDataType.setName("number");
		numberDataType.setId(2);
		numberDataType.setOperators(Arrays.asList(lessThanOp));
		
		
		
		EntityObj customerEntity = new EntityObj();
		customerEntity.setAccountHolder(accountHolder);
		customerEntity.setId(1);
		customerEntity.setMetadataDefinition(custMetadataDefinition);
		customerEntity.setName("customer");
		
		EntityObj vehicelEntity = new EntityObj();
		vehicelEntity.setAccountHolder(accountHolder);
		vehicelEntity.setId(2);
		vehicelEntity.setMetadataDefinition(vehicelMetadataDefinition);
		vehicelEntity.setName("vehicel");
		
		Field mileageField = new Field();
		mileageField.setDataType(numberDataType);
		mileageField.setEntityObj(vehicelEntity);
		mileageField.setId(1);
		mileageField.setMetadata(true);
		mileageField.setxPath("/metaData/vehicle/service/mileage");
		mileageField.setName("mileage");
		
		SearchQuery mileageLessThanQuery = new SearchQuery();
		mileageLessThanQuery.setId(1);
		mileageLessThanQuery.setName("less_than_30k");
		
		
		
		ConditionLine mileageLessThan30KConditionLine = new ConditionLine();
		mileageLessThan30KConditionLine.setAccountHolder(accountHolder);
		mileageLessThan30KConditionLine.setField(mileageField);
		mileageLessThan30KConditionLine.setOperator(lessThanOp);
		mileageLessThan30KConditionLine.setValueText("30000");
		mileageLessThan30KConditionLine.setId(1);
		mileageLessThan30KConditionLine.setSearchQuery(mileageLessThanQuery);
		
	
		
		mileageLessThanQuery.setConditionLines(Arrays.asList(mileageLessThan30KConditionLine));
		
		
		System.out.println("-->mileageLessThan30K");
		System.out.println(mileageLessThanQuery.getSQLQuery());		
//		String sqlRegex = "select\\s+id\\s*,\\s*firstName\\s*,\\s*lastName\\s*,\\s*extractvalue\\s*\\(\\s*metadata\\s*,\\s*'\\/metaData\\/vehicle\\/vin'\\s*\\)\\s+from\\s+customer\\s+where\\s+extractvalue\\s*\\(\\s*metadata\\s*,\\s*'\\/metaData\\/vehicle\\/model'\\s*\\)\\s*=\\s*'QX60'\\s*;";
//		
//		assertThat(service.getSQLQuery(mileageLessThanQuery), Matchers.matchesPattern(sqlRegex));
		
	}	
	
	@Test
	public void mileageLessThan30KAndModelsIn(){
		
		AccountHolder accountHolder = new AccountHolder();
		accountHolder.setId(1);
		accountHolder.setName("Avaya");
		
		SearchQuery query = new SearchQuery();
		query.setId(1);
		query.setName("mileage_less_than_30K");
		
		MetadataDefinition custMetadataDefinition = new MetadataDefinition();
		custMetadataDefinition.setId(1);
		custMetadataDefinition.setAccountHolder(accountHolder);
		custMetadataDefinition.setName("customer");
		
		MetadataDefinition vehicelMetadataDefinition = new MetadataDefinition();
		vehicelMetadataDefinition.setId(2);
		vehicelMetadataDefinition.setAccountHolder(accountHolder);
		vehicelMetadataDefinition.setName("vehicel");
		
		Operator lessThanOp = new Operator();
		lessThanOp.setId(2);
		lessThanOp.setName("less_than");
		lessThanOp.setSymbol("<");
		
		Operator inOp = new Operator();
		inOp.setId(11);
		inOp.setName("in");
		inOp.setSymbol("in");
		
		
		DataType numberDataType = new DataType();
		numberDataType.setName("number");
		numberDataType.setId(2);
		numberDataType.setOperators(Arrays.asList(lessThanOp));
		
		DataType stringDataType = new DataType();
		stringDataType.setName("string");
		stringDataType.setId(1);
		stringDataType.setOperators(Arrays.asList(inOp));
		
		
		EntityObj customerEntity = new EntityObj();
		customerEntity.setAccountHolder(accountHolder);
		customerEntity.setId(1);
		customerEntity.setMetadataDefinition(custMetadataDefinition);
		customerEntity.setName("customer");
		
		EntityObj vehicelEntity = new EntityObj();
		vehicelEntity.setAccountHolder(accountHolder);
		vehicelEntity.setId(2);
		vehicelEntity.setMetadataDefinition(vehicelMetadataDefinition);
		vehicelEntity.setName("vehicel");
		
		Field modelField = new Field();
		modelField.setDataType(stringDataType);
		modelField.setEntityObj(vehicelEntity);
		modelField.setId(1);
		modelField.setMetadata(true);
		modelField.setxPath("/metaData/vehicle/model");
		modelField.setName("model");
		
		Field mileageField = new Field();
		mileageField.setDataType(numberDataType);
		mileageField.setEntityObj(vehicelEntity);
		mileageField.setId(1);
		mileageField.setMetadata(true);
		mileageField.setxPath("/metaData/vehicle/service/mileage");
		mileageField.setName("mileage");
		
		SearchQuery mileageLessThanQuery = new SearchQuery();
		mileageLessThanQuery.setId(1);
		mileageLessThanQuery.setName("less_than_30k");
		
		
		
		ConditionLine mileageLessThan30KConditionLine = new ConditionLine();
		mileageLessThan30KConditionLine.setAccountHolder(accountHolder);
		mileageLessThan30KConditionLine.setField(mileageField);
		mileageLessThan30KConditionLine.setOperator(lessThanOp);
		mileageLessThan30KConditionLine.setValueText("30000");
		mileageLessThan30KConditionLine.setId(1);
		mileageLessThan30KConditionLine.setSearchQuery(mileageLessThanQuery);
		
		ConditionLine modelIn = new ConditionLine();
		modelIn.setAccountHolder(accountHolder);
		modelIn.setField(modelField);
		modelIn.setOperator(inOp);
		modelIn.setValueText("'QX60','QX80'");
		modelIn.setId(1);
		modelIn.setSearchQuery(mileageLessThanQuery);
	
		
		mileageLessThanQuery.setConditionLines(Arrays.asList(mileageLessThan30KConditionLine,modelIn));
		
		
		System.out.println("-->mileageLessThan30KAndModelsIn");
		System.out.println(mileageLessThanQuery.getSQLQuery());		
//		String sqlRegex = "select\\s+id\\s*,\\s*firstName\\s*,\\s*lastName\\s*,\\s*extractvalue\\s*\\(\\s*metadata\\s*,\\s*'\\/metaData\\/vehicle\\/vin'\\s*\\)\\s+from\\s+customer\\s+where\\s+extractvalue\\s*\\(\\s*metadata\\s*,\\s*'\\/metaData\\/vehicle\\/model'\\s*\\)\\s*=\\s*'QX60'\\s*;";
//		
//		assertThat(service.getSQLQuery(mileageLessThanQuery), Matchers.matchesPattern(sqlRegex));
		
	}	
	
}
