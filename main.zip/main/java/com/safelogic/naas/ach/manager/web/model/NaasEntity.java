package com.safelogic.naas.ach.manager.web.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.hibernate.annotations.Type;
import org.joda.time.DateTime;

import com.safelogic.naas.ach.manager.listener.NaasEntityListener;

@MappedSuperclass
@EntityListeners(NaasEntityListener.class)
public abstract class NaasEntity implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -3809711836141335907L;

	@Id
	@GeneratedValue
	protected long id;
	
	@Column(name="name")
	protected String name;

	@Column(name="create_user")
	protected String createdByUser;
	
	@Column(name="update_user")
	protected String modifiedByUser;
	
	@Column(name="create_date")
	@Type(type="org.jadira.usertype.dateandtime.joda.PersistentDateTime")	
	protected DateTime createDate;
	
	@Column(name="update_date")
	@Type(type="org.jadira.usertype.dateandtime.joda.PersistentDateTime")	
	protected DateTime modifiedDate;
	
	public String getCreatedByUser() {
		return createdByUser;
	}

	public void setCreatedByUser(String createdByUser) {
		this.createdByUser = createdByUser;
	}

	public String getModifiedByUser() {
		return modifiedByUser;
	}

	public void setModifiedByUser(String modifiedByUser) {
		this.modifiedByUser = modifiedByUser;
	}

	public DateTime getCreateDate() {
		return createDate;
	}

	public void setCreateDate(DateTime createDate) {
		this.createDate = createDate;
	}

	public DateTime getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(DateTime modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	public long getId(){
		return this.id;
	}
	
	public void setId(long id){
		this.id = id;
	}
	
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder("Entity Class: ");
		builder.append(getClass().getName())
		.append(" Entity Name: ")
		.append(getName())
		.append(" Entity Id: ")
		.append(getId());
		return builder.toString();
	}
}
