package com.safelogic.naas.ach.manager.web.model;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name="customer_group")
public class CustomerGroup extends NaasEntity {
	
	private static final long serialVersionUID = 7169966828726784908L;
	
	@ManyToMany(cascade=CascadeType.ALL)
    @JoinTable(name="customer_group_mapping", joinColumns=@JoinColumn(name="group_id"),inverseJoinColumns= @JoinColumn(name="customer_id"))
	List<Customer> customers = null;
	
	public CustomerGroup(){
		
	}

	/**
	 * @return the customers
	 */
	public List<Customer> getCustomers() {
		return customers;
	}

	/**
	 * @param customers the customers to set
	 */
	public void setCustomers(List<Customer> customers) {
		this.customers = customers;
	}
	
	
}
