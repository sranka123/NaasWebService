package com.safelogic.naas.ach.manager.web.service;

import java.util.List;

public interface EmailService {
	public void sendEmail(List<String> toList,String from,String subject,String content);
}
