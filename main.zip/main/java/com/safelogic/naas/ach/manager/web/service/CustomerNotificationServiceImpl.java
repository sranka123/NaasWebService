package com.safelogic.naas.ach.manager.web.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicReference;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessageCreator;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.safelogic.naas.ach.manager.web.dao.CustomerDAO;
import com.safelogic.naas.ach.manager.web.dao.DeliveredNotificationDAO;
import com.safelogic.naas.ach.manager.web.dao.NaasRepository;
import com.safelogic.naas.ach.manager.web.model.AccountHolder;
import com.safelogic.naas.ach.manager.web.model.Customer;
import com.safelogic.naas.ach.manager.web.model.CustomerGroup;
import com.safelogic.naas.ach.manager.web.model.DeliveredNotification;
import com.safelogic.naas.ach.manager.web.model.Notification;

@Service
@Transactional
public class CustomerNotificationServiceImpl implements CustomerNotificationService {

	Logger logger = LoggerFactory.getLogger("fileLogger");
	private CustomerDAO customerDao;
	
	private NaasRepository<CustomerGroup> customerGroupRepo;

	private NaasRepository<Notification> naasNotificationRepository;
	
	@Autowired
	@Qualifier("deliveredNotificationDao")	
	private DeliveredNotificationDAO deliveredNotificationDao;
	
	@Autowired
	private JmsTemplate jmsQueueTemplate;
	
	@Override
	public Customer saveCustomer(Customer customer) {
		return customerDao.create(customer);
	}
	
	@Override
	public Customer getCustomer(long id) {
		return customerDao.findById(id);
	}

	@Override
	public Customer getCustomer(String emailId) {
		return (Customer)customerDao.findByAttribute("emailId", emailId).get(0);
	}

	@Override
	public CustomerGroup getGroup(String groupName) {
		return (CustomerGroup)customerGroupRepo.findByAttribute("name", groupName).get(0);
	}


	@Override
	public Notification saveNotification(Notification notification) {
		Notification notification2 = naasNotificationRepository.create(notification);
		final AtomicReference<TextMessage> message = new AtomicReference<TextMessage>();
		
		jmsQueueTemplate.send(new MessageCreator() {
			
			@Override
			public Message createMessage(Session session) throws JMSException {
				TextMessage textMessage = session.createTextMessage();
				textMessage.setText(String.valueOf(notification.getId()));
				message.set(textMessage);
				return message.get();
			}
		});		
		try {
			logger.debug("### JMS Message " + message.get().getJMSMessageID());
		} catch (JMSException e) {
			throw new RuntimeException(e);
		}
		return notification2;
	}

	@Override
	public List<Notification> getAllNotifications() {
		return naasNotificationRepository.findAll();
	}
	
	@Override
	public Notification getNotificationByName(String name) {
		return naasNotificationRepository.findByName(name);
	}
	
	@Override
	public CustomerGroup saveCustomerGroup(CustomerGroup customerGroup) {
		return customerGroupRepo.create(customerGroup);
	}
	
	@Override
	public CustomerGroup updateCustomerGroup(CustomerGroup customerGroup) {
		return customerGroupRepo.update(customerGroup);
	}

	@Override
	public List<CustomerGroup> getAllCustomerGroups() {
		return customerGroupRepo.findAll();
	}

	@Override
	public List<Customer> getAllCustomers() {
		return customerDao.findAll();
	}

	@Override
	public Customer updateCustomer(Customer customer) {
		return customerDao.update(customer);
	}
	
	@Override
	public boolean deleteCustomer(Customer customer) {
		return customerDao.delete(customer);
	}


	@Override
	public int getCustomerCount(long groupId) {
		return customerDao.getCustomerCount(groupId);
	}

	@Override
	public List<Customer> getCustomersForGroup(long groupId) {
		return customerDao.getCustomers(groupId);
	}

	@Autowired
	@Qualifier("naasRepository")
	public void setCustomerGroupRepo(NaasRepository<CustomerGroup> customerGroupRepo) {
		this.customerGroupRepo = customerGroupRepo;
		this.customerGroupRepo.setType(CustomerGroup.class);
	}
	
	@Autowired
	@Qualifier("naasRepository")
	public void setNaasNotificationRepository(NaasRepository<Notification> naasNotificationRepository) {
		this.naasNotificationRepository = naasNotificationRepository;
		this.naasNotificationRepository.setType(Notification.class);
	}	
	
	@Autowired
	@Qualifier("customerDao")
	public void setCustomerDao(CustomerDAO naasCustomerRepository){
		this.customerDao = naasCustomerRepository;
		this.customerDao.setType(Customer.class);
	}

	@Override
	public List<Customer> getCustomersForAccountHolder(AccountHolder ach) {
		return customerDao.getCustomersForAccountHolder(ach);
	}

	@Override
	public int getMonthlyDeliveredSmsCount(AccountHolder ach) {
		return deliveredNotificationDao.countOfDeliveredSmss(ach, DateTime.now().withDayOfMonth(1), DateTime.now());
	}

	@Override
	public int getMonthlyDeliveredEmailCount(AccountHolder ach) {
		return deliveredNotificationDao.countOfDeliveredEmails(ach, DateTime.now().withDayOfMonth(1), DateTime.now());
	}

	@Override
	public Map<Customer, Long> getCustomersWithNotificationCount(AccountHolder ach) {
		Map<Customer, Long> map = new HashMap<>();
		List<Object[]> list = customerDao.getCustomersWithNotificationCount(ach);
		
		for(Object[] objects : list){
			Customer customer = (Customer)objects[0];
			Long count = (Long)objects[1];
			map.put(customer, count);
		}
		return map;
	}

	@Override
	public List<DeliveredNotification> listOfNotificationDeliveredToCustomer(Customer customer) {
		return deliveredNotificationDao.listOfNotificationDeliveredToCustomer(customer);
	}	
}
