package com.safelogic.naas.ach.manager.web.configuration;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

import org.slf4j.MDC;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;

import com.safelogic.naas.ach.manager.web.security.NaasAccountHolderUser;

@Component
public class MDCFilter implements Filter {

	@Override
	public void init(FilterConfig filterConfig) throws ServletException {
		// TODO Auto-generated method stub

	}

	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {
		
		
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		if (authentication != null) {
			if (authentication.getPrincipal() instanceof NaasAccountHolderUser) {
				NaasAccountHolderUser user = (NaasAccountHolderUser) authentication.getPrincipal();
				
				MDC.put("userName", user.getUsername());
				MDC.put("achName", user.getAccountHolderName());

				try {
					chain.doFilter(request, response);
				} finally {
					if (authentication != null) {
						
						MDC.remove("userName");
						MDC.remove("achName");
					}
				}

			}
		}else{
			chain.doFilter(request, response);
		}
	}

	@Override
	public void destroy() {
		// TODO Auto-generated method stub

	}

}
