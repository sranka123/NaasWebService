package com.safelogic.naas.ach.manager.web.customer.group;

import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.safelogic.naas.ach.manager.web.model.AccountHolder;
import com.safelogic.naas.ach.manager.web.model.NaasEntity;

@Entity
@Table(name="metadata_definition")
public class MetadataDefinition extends NaasEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1084221205315379744L;
	
	@ManyToOne
	@JoinColumn(name="ach_id")	
	private AccountHolder accountHolder;

	public MetadataDefinition() {
		super();
	}

	public AccountHolder getAccountHolder() {
		return accountHolder;
	}

	public void setAccountHolder(AccountHolder accountHolder) {
		this.accountHolder = accountHolder;
	}
	
}
