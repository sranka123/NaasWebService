package com.safelogic.naas.ach.manager.web.service;

import java.util.List;

import com.safelogic.naas.ach.manager.web.model.AccountHolder;
import com.safelogic.naas.ach.manager.web.model.AccountHolderUser;
import com.safelogic.naas.ach.manager.web.model.AccountHolderUserSetup;
import com.safelogic.naas.ach.manager.web.model.Role;

public interface AccountHolderUserService {
	public AccountHolderUser createAccountHolderUser(AccountHolderUser accountHolderUser);
	public void setUpAccountHolderUser(AccountHolderUser accountHolderUser);
	public AccountHolderUser getAccountHolderUser(String emailId, AccountHolder accountHolder);
	public List<AccountHolderUser> getAccountHolderUserByRole(String roleName, AccountHolder accountHolder);
	public boolean isUserNameUnique(String emailId,AccountHolder accountHolder);
	public List<String> getSecurityQuestion();
	public AccountHolderUser getActiveAccoutHolderUser(String emailId,AccountHolder accountHolder);
	public Role getUserRole(String emailId,AccountHolder accountHolder);
	public Role getRole(String roleName);
	public List<Role> getAllRoles();
	public AccountHolderUser updateAccountHolderUser(AccountHolderUser accountHolderUser);
	public AccountHolderUserSetup getAccountHolderUserSetup(String token);
	public AccountHolderUserSetup updateAccountHolderUserSetup(AccountHolderUserSetup accountHolderUserSetup);

}
