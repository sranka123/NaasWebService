package com.safelogic.naas.ach.manager.web.util;

import com.safelogic.naas.ach.manager.web.NaasContext;

public class Context extends ThreadLocal<NaasContext> {
	private static ThreadLocal<NaasContext> context = new ThreadLocal<>();
	
	public static void setVal(NaasContext val) {
		context.set(val);
	}
	
	public static NaasContext getVal(){
		return context.get();
	}
}
