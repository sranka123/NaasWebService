package com.safelogic.naas.ach.manager.web.model;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="sub_industry_master")
public class SubIndustry {

	@Id
	@GeneratedValue
	@Column(name="sub_industry_id")
	private long id;
	
	@Column(name="sub_industry_name")
	private String name;
	
//	@Column(name="sub_industry_desc")
//	private String description;
	
//	@ManyToOne(cascade=CascadeType.ALL)
//    @JoinTable(
//        name="industry_mapping_table",
//        joinColumns = @JoinColumn( name="sub_industry_id"),
//        inverseJoinColumns = @JoinColumn(name="industry_id")
//    )
//	private Industry industry;   
	
	public SubIndustry() {
		// TODO Auto-generated constructor stub
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

//	public String getDescription() {
//		return description;
//	}
//
//	public void setDescription(String description) {
//		this.description = description;
//	}

//	public Industry getIndustry() {
//		return industry;
//	}
//
//	public void setIndustry(Industry industry) {
//		this.industry = industry;
//	}
	
	
}
