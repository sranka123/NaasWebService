package com.safelogic.naas.ach.manager.web.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.safelogic.naas.ach.manager.web.NaasURIConstants;
import com.safelogic.naas.ach.manager.web.dao.AccountHolderDAO;
import com.safelogic.naas.ach.manager.web.model.Industry;
import com.safelogic.naas.ach.manager.web.model.SubIndustry;

@RestController
public class AccountHolderRestController {
	
	@Autowired
	AccountHolderDAO accountHolderDAO;
	
	
	@RequestMapping(value="/{industryId}", method=RequestMethod.GET ,produces = {MediaType.APPLICATION_JSON_VALUE})
	public List<SubIndustry> isUniqueName(@PathVariable String industryId){
		long id = Long.parseLong(industryId);
		Industry industry = new Industry();
		industry.setId(id);
		return accountHolderDAO.getSubIndustries(industry);
	}
}
