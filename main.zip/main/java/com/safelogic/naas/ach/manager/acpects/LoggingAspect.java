package com.safelogic.naas.ach.manager.acpects;

import java.util.Arrays;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Component;

import com.safelogic.naas.ach.manager.web.model.AccountHolderUser;
import com.safelogic.naas.ach.manager.web.model.AccountHolderUserSetup;
import com.safelogic.naas.ach.manager.web.model.ContentSms;
import com.safelogic.naas.ach.manager.web.model.Notification;
import com.safelogic.naas.ach.manager.web.security.NaasAccountHolderUser;

@Aspect
@Component
public class LoggingAspect {
	
	Logger logger = LoggerFactory.getLogger("dbLogger");
		

	@AfterReturning(
	        pointcut="execution(* com.safelogic.naas.ach.manager.web.service.ContentService+.saveNewSmsContent(..))",
	        returning="contentSms")
	public void logCreateContentSms(JoinPoint joinPoint,ContentSms contentSms){
		
		MDC.put("entityName", contentSms.getName());
		MDC.put("entityId", ""+contentSms.getId());
		MDC.put("eventType", "SMS_CREATED");
		logger.debug("SMS Content created. Content Name: "+contentSms.getName());
		MDC.remove("eventType");
		MDC.remove("entityName");
		MDC.remove("entityId");
		
	}	

	@AfterReturning(
	        pointcut="execution(* com.safelogic.naas.ach.manager.web.service.ContentService+.updateSmsContent(..))",
	        returning="contentSms")
	public void logUpdateContentSms(JoinPoint joinPoint,ContentSms contentSms){
		
		MDC.put("entityName", contentSms.getName());
		MDC.put("entityId", ""+contentSms.getId());
		MDC.put("eventType", "SMS_UPDATED");
		logger.debug("SMS Content created. Content Name: "+contentSms.getName());
		MDC.remove("eventType");
		MDC.remove("entityName");
		MDC.remove("entityId");
		
	}
	
	@AfterReturning(
	        pointcut="execution(* com.safelogic.naas.ach.manager.web.service.CustomerNotificationService+.saveNotification(..))",
	        returning="notification")
	public void logCreateNotification(JoinPoint joinPoint,Notification notification){
		
		MDC.put("entityName", notification.getName());
		MDC.put("entityId", ""+notification.getId());
		MDC.put("eventType", "NOTIFICATION_CREATED");
		logger.debug("Notification created. Notification Name: "+notification.getName());
		MDC.remove("eventType");
		MDC.remove("entityName");
		MDC.remove("entityId");
		
	}	
	
	
	
	@AfterReturning(
	        pointcut="execution(* com.safelogic.naas.ach.manager.web.service.AccountHolderUserService+.updateAccountHolderUserSetup(..))",
	        returning="achUserSetUp")
	public void logUserEnabled(JoinPoint joinPoint,AccountHolderUserSetup achUserSetUp){
		
		MDC.put("eventType", "USER_ENABLED");
		MDC.put("entityName", achUserSetUp.getClass().getSimpleName());
		MDC.put("entityId", ""+achUserSetUp.getId());
		logger.debug("Account Holder User Enabled: "+achUserSetUp.getAccountHolderUser().getEmailId());
		MDC.remove("eventType");
		MDC.remove("entityName");
		MDC.remove("entityId");
		
	}	
	
	@After("execution(* com.safelogic.naas.ach.manager.web.service.AccountHolderUserService+.setUpAccountHolderUser(..))")
	public void logUserSetUpEvent(JoinPoint joinPoint){
		AccountHolderUser accountHolderUser = (AccountHolderUser)joinPoint.getArgs()[0];
		
		MDC.put("eventType", "USER_SETUP");
		MDC.put("entityName", accountHolderUser.getClass().getSimpleName());
		MDC.put("entityId", ""+accountHolderUser.getId());
		logger.debug("AccountHolderUser created with user name: "+accountHolderUser.getEmailId());
		MDC.remove("eventType");
		MDC.remove("entityName");
		MDC.remove("entityId");
		
	}

	
	@After("execution(* com.safelogic.naas.ach.manager.web.security.NaasAuthSuccessHandler.onAuthenticationSuccess(..))")
	public void userLoggedIn(JoinPoint joinPoint){
		Authentication authentication = (Authentication)joinPoint.getArgs()[2];
		if(authentication.getPrincipal()  instanceof NaasAccountHolderUser){
			NaasAccountHolderUser user = (NaasAccountHolderUser)authentication.getPrincipal();
			MDC.put("eventType", "LOGIN");		
			MDC.put("entityName", user.getClass().getSimpleName());
			MDC.put("entityId", ""+user.getId());
			MDC.put("achName", user.getAccountHolderName());
			logger.debug("Logged in user: "+user.getUsername());
			MDC.remove("eventType");
			MDC.remove("entityName");
			MDC.remove("entityId");
			MDC.remove("achName");
			
			
		}
	}
	@After("execution(* com.safelogic.naas.ach.manager.web.security.NaasLogoutSuccessHandler.onLogoutSuccess(..))")
	public void userLoggedOut(JoinPoint joinPoint){
		Authentication authentication = (Authentication)joinPoint.getArgs()[2];
		if(authentication!=null && authentication.getPrincipal()  instanceof NaasAccountHolderUser){
			NaasAccountHolderUser user = (NaasAccountHolderUser)authentication.getPrincipal();
			MDC.put("eventType", "LOGOUT");		
			MDC.put("entityName", user.getClass().getSimpleName());
			MDC.put("entityId", ""+user.getId());
			MDC.put("achName", user.getAccountHolderName());
			logger.debug("Logged Out user: "+user.getUsername());
			MDC.remove("eventType");
			MDC.remove("entityName");
			MDC.remove("entityId");
			MDC.remove("achName");
			logger.debug("User logged out: "+user.getUsername());
		}
	}

	@AfterReturning(
	        pointcut="execution(* com.safelogic.naas.ach.manager.web.service.ContentService+.approveOrRejectSmsContent(..))",
	        returning="contentSms")
	public void logApproveReject(JoinPoint joinPoint,ContentSms contentSms){
		System.out.println("@@ "+Arrays.toString(joinPoint.getArgs()));
		Boolean approve = (Boolean)joinPoint.getArgs()[1];
		if(approve.booleanValue()){
			MDC.put("entityName", contentSms.getName());
			MDC.put("entityId", ""+contentSms.getId());
			MDC.put("eventType", "APPROVE_CONTENT");
			logger.debug("SMS Content approved. Content Name: "+contentSms.getName());
			MDC.remove("eventType");
			MDC.remove("entityName");
			MDC.remove("entityId");

		}else{
			MDC.put("eventType", "REJECT_CONTENT");
			MDC.put("entityName", contentSms.getName());
			MDC.put("entityId", ""+contentSms.getId());
			logger.debug("SMS Content rejected. Content Name: "+contentSms.getName());
			MDC.remove("eventType");
			MDC.remove("entityName");
			MDC.remove("entityId");

		}

	}
	
	@AfterReturning(
	        pointcut="execution(* com.safelogic.naas.ach.manager.web.service.ContentService+.sendForApproval(..))",
	        returning="contentSms")
	public void logPendingApproval(JoinPoint joinPoint,ContentSms contentSms){
		Boolean sentForApproval = (Boolean)joinPoint.getArgs()[1];
		if(sentForApproval.booleanValue()){
			MDC.put("eventType", "PENDING_APPROVAL");
			MDC.put("entityName", contentSms.getName());
			MDC.put("entityId", ""+contentSms.getId());
			logger.debug("Content sent for approval: "+contentSms.getName());
			MDC.remove("eventType");
			MDC.remove("entityName");
			MDC.remove("entityId");
		}
	}	
}
