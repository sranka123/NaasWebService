package com.safelogic.naas.ach.manager.web.customer.group;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.safelogic.naas.ach.manager.web.model.NaasEntity;

@Entity
@Table(name="field")
public class Field extends NaasEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3165810346296990221L;

	@ManyToOne
	@JoinColumn(name="entity_id", referencedColumnName="id")
	private EntityObj entityObj;
	
	@Column(name="display_text")
	private String displayText;
	
	
	@ManyToOne
	@JoinColumn(name="data_type_id", referencedColumnName="id")	
	private DataType dataType;
	
	@Column(name="isMetadata")
	private boolean isMetadata;
	
	@Column(name="xpath")
	private String xPath;
	
	public Field() {
		super();
	}

	public EntityObj getEntityObj() {
		return entityObj;
	}

	public void setEntityObj(EntityObj entityObj) {
		this.entityObj = entityObj;
	}

	public String getDisplayText() {
		return displayText;
	}

	public void setDisplayText(String displayText) {
		this.displayText = displayText;
	}

	public DataType getDataType() {
		return dataType;
	}

	public void setDataType(DataType dataType) {
		this.dataType = dataType;
	}

	public boolean isMetadata() {
		return isMetadata;
	}

	public void setMetadata(boolean isMetadata) {
		this.isMetadata = isMetadata;
	}

	public String getxPath() {
		return xPath;
	}

	public void setxPath(String xPath) {
		this.xPath = xPath;
	}
	
	public String getSQLColumn(){
		if(isMetadata()){
			String columnName = "extractvalue(metadata, '"+getxPath()+"')";
			if(dataType.getName().equals("date")){
				columnName  = "str_to_date("+columnName+",    '%m/%d/%Y')";
				return columnName;
			}else{
				return  columnName;
			}
		}else{
			return getName();
		}
	}
	
}
