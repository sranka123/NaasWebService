package com.safelogic.naas.ach.manager.web.model;

import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.Type;
import org.joda.time.DateTime;

@Entity
@Table(name="notification")
public class Notification extends NaasEntity /*implements Serializable*/{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -8405078696724259739L;
	
	@ManyToOne
	@JoinColumn(name="ach_id")
	private AccountHolder accountHolder;
	
	@ManyToOne
	@JoinColumn(name="email_id", referencedColumnName="id")
	private ContentEmail contentEmail;
	
	@ManyToOne
	@JoinColumn(name="sms_id", referencedColumnName="id")
	private ContentSms contentSms;
	
	
	@Type(type="org.jadira.usertype.dateandtime.joda.PersistentDateTime")
	private DateTime dateTime;
	


	@ManyToOne
	@JoinColumn(name="group_id", referencedColumnName="id")
	private CustomerGroup customerGroup;
	
	
	private boolean sendEmail;
	
	private boolean sendSms;
	
	@Transient
	private String selectCustomer="";
	
	@Transient
	private String selectForm="";
	
	@Transient
	private String sendNotification="";
	
	public String getSelectCustomer() {
		return selectCustomer;
	}


	public void setSelectCustomer(String selectCustomer) {
		this.selectCustomer = selectCustomer;
	}


	public String getSelectForm() {
		return selectForm;
	}


	public void setSelectForm(String selectForm) {
		this.selectForm = selectForm;
	}


	public Notification() {
		
	}


	public DateTime getDateTime() {
		return dateTime;
	}


	public void setDateTime(DateTime dateTime) {
		this.dateTime = dateTime;
	}


	public AccountHolder getAccountHolder() {
		return accountHolder;
	}

	public void setAccountHolder(AccountHolder accountHolder) {
		this.accountHolder = accountHolder;
	}


	public CustomerGroup getCustomerGroup() {
		return customerGroup;
	}


	public void setCustomerGroup(CustomerGroup customerGroup) {
		this.customerGroup = customerGroup;
	}

	public boolean isSendEmail() {
		return sendEmail;
	}


	public void setSendEmail(boolean sendEmail) {
		this.sendEmail = sendEmail;
	}


	public boolean isSendSms() {
		return sendSms;
	}


	public void setSendSms(boolean sendSms) {
		this.sendSms = sendSms;
	}


	public ContentEmail getContentEmail() {
		return contentEmail;
	}


	public void setContentEmail(ContentEmail contentEmail) {
		this.contentEmail = contentEmail;
	}


	public ContentSms getContentSms() {
		return contentSms;
	}


	public void setContentSms(ContentSms contentSms) {
		this.contentSms = contentSms;
	}


	public String getSendNotification() {
		return sendNotification;
	}


	public void setSendNotification(String sendNotification) {
		this.sendNotification = sendNotification;
	}

}
