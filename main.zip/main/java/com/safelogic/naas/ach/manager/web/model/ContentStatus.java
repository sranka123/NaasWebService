package com.safelogic.naas.ach.manager.web.model;

public enum ContentStatus {
	DRAFT(0,"Draft"),
	PENDING_APPROVAL(1,"Pending Approval"),
	APPROVED(2,"Approved");
	
	private int code;
	
	private String name;
	
	private ContentStatus(int code,String name){
		this.code = code;
		this.name = name;
	}
	
	public int getCode(){
		return code;
	}
	public String getName(){
		return name;
	}
	
	public static ContentStatus getContentStatus(int i){
		switch (i){
			case 0: return ContentStatus.DRAFT;
			case 1: return ContentStatus.PENDING_APPROVAL;
			case 2: return ContentStatus.APPROVED;
			default:
				throw new IllegalArgumentException("valid values are [0-DRAFT,1-PENDING_APPROVAL,2-APPROVED]");
		}
	}
}
