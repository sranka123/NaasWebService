package com.safelogic.naas.ach.manager.web.customer.group;

import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.safelogic.naas.ach.manager.web.model.AccountHolder;
import com.safelogic.naas.ach.manager.web.model.NaasEntity;

@Entity
@Table(name="search_query")
public class SearchQuery extends NaasEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4517413292537345288L;
	

	@ManyToOne
	@JoinColumn(name="ach_id")
	AccountHolder accountHolder;
	
	@OneToMany(mappedBy = "searchQuery", fetch=FetchType.EAGER, cascade = CascadeType.ALL)
	List<ConditionLine> conditionLines;

	public SearchQuery() {
		super();
	}
	public AccountHolder getAccountHolder() {
		return accountHolder;
	}

	public void setAccountHolder(AccountHolder accountHolder) {
		this.accountHolder = accountHolder;
	}

	public List<ConditionLine> getConditionLines() {
		return conditionLines;
	}

	public void setConditionLines(List<ConditionLine> conditionLines) {
		this.conditionLines = conditionLines;
	}
	
	public String getSQLQuery() {
		
		StringBuffer sqlQuery  = new StringBuffer();
		
		sqlQuery.append("select id, firstName, lastName, useEmail, emailId, usePhone, phoneNumber ")
				.append(" from customer ")
				.append(getSQLWhereClause());		

		return sqlQuery.toString();
	}
	
	public String getSQLWhereClause() {
		
		StringBuffer sqlQuery  = new StringBuffer(" where ");

		String whereClause = getConditionLines().stream().map(ConditionLine::getSQLWhereClause).collect(Collectors.joining(" and "));
		sqlQuery.append(whereClause);//hack for now
		
		sqlQuery.append(" and ")
		.append(" accountHolder_ach_id = ")
		.append(accountHolder.getId());

		return sqlQuery.toString();
	}

}
