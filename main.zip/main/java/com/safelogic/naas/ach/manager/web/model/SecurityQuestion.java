package com.safelogic.naas.ach.manager.web.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="security_questions")
public class SecurityQuestion extends NaasEntity {
	
	@Column(name="question")
	private String question;

	public SecurityQuestion() {
		super();
		// TODO Auto-generated constructor stub
	}


	public String getQuestion() {
		return question;
	}

	public void setQuestion(String question) {
		this.question = question;
	}
	
	
}
