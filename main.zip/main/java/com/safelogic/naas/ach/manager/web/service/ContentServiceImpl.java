/**
 * 
 */
package com.safelogic.naas.ach.manager.web.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.safelogic.naas.ach.manager.web.dao.NaasRepository;
import com.safelogic.naas.ach.manager.web.model.ContentEmail;
import com.safelogic.naas.ach.manager.web.model.ContentSms;
import com.safelogic.naas.ach.manager.web.model.ContentStatus;
import com.safelogic.naas.ach.manager.web.model.ContentTemplate;

@Service
@Transactional
public class ContentServiceImpl implements ContentService {
	
	private NaasRepository<ContentEmail> emailContentRepo;
	
	private NaasRepository<ContentSms> smsContentRepo;
	
	private NaasRepository<ContentTemplate> templateContentRepo;

	/* (non-Javadoc)
	 * @see com.safelogic.naas.ach.manager.web.service.ContentService#getEmailContent(com.safelogic.naas.ach.manager.web.model.ContentEmail)
	 */
	@Override
	public ContentEmail getEmailContent(long id) {
		return emailContentRepo.findById(id);
	}
	
	@Override
	public List<ContentEmail> getAllEmailContent() {
		return emailContentRepo.findAll();
	}

	/* (non-Javadoc)
	 * @see com.safelogic.naas.ach.manager.web.service.ContentService#saveNewEmailContent(com.safelogic.naas.ach.manager.web.model.ContentEmail)
	 */
	@Override
	public ContentEmail saveNewEmailContent(ContentEmail content) {
		return emailContentRepo.create(content);
	}
	
	public void updateEmailContent(ContentEmail content) {
		emailContentRepo.update(content);
	}

	/* (non-Javadoc)
	 * @see com.safelogic.naas.ach.manager.web.service.ContentService#getTemplateContent(com.safelogic.naas.ach.manager.web.model.ContentTemplate)
	 */
	@Override
	public ContentTemplate getTemplateContent(long id) {
		return templateContentRepo.findById(id);
	}
	
	@Override
	public List<ContentTemplate> getAllTemplateContent() {
		return templateContentRepo.findAll();
	}

	/* (non-Javadoc)
	 * @see com.safelogic.naas.ach.manager.web.service.ContentService#saveNewTemplateContent(com.safelogic.naas.ach.manager.web.model.ContentTemplate)
	 */
	@Override
	public ContentTemplate saveNewTemplateContent(ContentTemplate content) {
		return templateContentRepo.create(content);
	}
	
	public void updateTemplateContent(ContentTemplate content) {
		templateContentRepo.update(content);
	}

	/* (non-Javadoc)
	 * @see com.safelogic.naas.ach.manager.web.service.ContentService#getSmsContent(com.safelogic.naas.ach.manager.web.model.ContentSms)
	 */
	@Override
	public ContentSms getSmsContent(long id) {
		return smsContentRepo.findById(id);
	}
	
	@Override
	public List<ContentSms> getAllSmsContent() {
		return smsContentRepo.findAll();
	}

	/* (non-Javadoc)
	 * @see com.safelogic.naas.ach.manager.web.service.ContentService#saveNewSmsContent(com.safelogic.naas.ach.manager.web.model.ContentSms)
	 */
	@Override
	public ContentSms saveNewSmsContent(ContentSms content) {
		return smsContentRepo.create(content);
	}
	
	@Override
	public ContentSms updateSmsContent(ContentSms content) {
		return smsContentRepo.update(content);
	}
	
	@Override
	public void deleteSmsContent(ContentSms content) {
		smsContentRepo.delete(content);
	}
	
	@Autowired
	@Qualifier("naasRepository")
	public void setEmailContentRepo(NaasRepository<ContentEmail> emailContentRepo) {
		this.emailContentRepo = emailContentRepo;
		this.emailContentRepo.setType(ContentEmail.class);
	}
	

	@Autowired
	@Qualifier("naasRepository")
	public void setSmsContentRepo(NaasRepository<ContentSms> smsContentRepo) {
		this.smsContentRepo = smsContentRepo;
		this.smsContentRepo.setType(ContentSms.class);
	}

	@Autowired
	@Qualifier("naasRepository")
	public void setTemplateContentRepo(NaasRepository<ContentTemplate> templateContentRepo) {
		this.templateContentRepo = templateContentRepo;
		this.templateContentRepo.setType(ContentTemplate.class);
	}

	@Override
	public ContentSms approveOrRejectSmsContent(ContentSms content, Boolean approveOrNot) {
		if(approveOrNot.booleanValue()){
			content.setStatus(ContentStatus.APPROVED);
		}else{
			content.setStatus(ContentStatus.DRAFT);
			
		}
		return this.updateSmsContent(content);
	}

	@Override
	public ContentSms sendForApproval(ContentSms content,Boolean sendForApproval) {
		if(sendForApproval.booleanValue()){
			content.setStatus(ContentStatus.PENDING_APPROVAL);
		}else{
			content.setStatus(ContentStatus.DRAFT);
		}
		
		return this.updateSmsContent(content);
	}

}
