package com.safelogic.naas.ach.manager.web.util;


import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.StringWriter;
import java.io.UnsupportedEncodingException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Result;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class XMLUtil
{

    /**
     * Takes an XML document, looks for the first node and gets the node name.
     * 
     * @param Document
     *            doc
     * @return String elementName
     */
    public static String getRootElementName(Document doc)
    {
        Element root = null;
        String elementName = null;
        if (doc != null && doc.hasChildNodes())
        {
            root = doc.getDocumentElement();
            if (root != null)
            {
                elementName = root.getNodeName();
            }
        }
        return elementName;
    }

    public static Element getRootElement(Document doc)
    {
        Element root = null;
        if (doc != null && doc.hasChildNodes())
        {
            root = doc.getDocumentElement();
        }
        return root;
    }

    /**
     * Get the Document parsing the input XML string supplied.
     * 
     * @param xml
     * @throws SAXException
     * @throws IOException
     * @throws ParserConfigurationException
     */
    public static Document getDocument(String xmlString) throws SAXException, IOException, ParserConfigurationException
    {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        InputStream is = new ByteArrayInputStream(xmlString.getBytes());

        return factory.newDocumentBuilder().parse(is);
    }

    /**
     * Takes an Element as a starting point and a tag, returns the name of the first Element of that tag.
     * 
     * @param Element
     *            element
     * @param String
     *            tagName
     * @return String textVal
     */
    public static String getElementTextValue(Element element, String tagName)
    {
        String textVal = null;
        Element el = null;
        NodeList nl = element.getElementsByTagName(tagName);
        if (nl != null && nl.getLength() > 0)
        {
            el = (Element) nl.item(0);
            if (el.getFirstChild() != null)
            {
                textVal = el.getFirstChild().getNodeValue();
            }
        }
        return textVal;
    }

    /**
     * Takes an XML document and a tag name, looks for the tag and gets a reference to that Element.
     * 
     * @param Element
     *            element
     * @param String
     *            tagName
     * @return Element targetElement
     */
    public static Element getElement(Document doc, String target)
    {
        NodeList nodeList = null;
        Node targetNode = null;
        Element targetElement = null;
        int targetCount = 0;

        nodeList = doc.getElementsByTagName(target);
        targetCount = nodeList.getLength();
        // System.out.println("  found " + targetCount + " " + target);
        if (targetCount > 1)
        {
            // System.out.println("  Can't get more than 1 " + target);
        }
        else if (targetCount < 1)
        {
            // System.out.println("  Can't find element " + target);
        }
        else
        {
            targetNode = nodeList.item(0);
            if (targetNode.getNodeType() == 1)
            {
                targetElement = (Element) targetNode;
            }
            else
            {
                // System.out.println("  Target node not an Element");
            }
        }
        return targetElement;
    } // end getElement

    /**
     * Takes an XML element as a starting point and a tag name, looks for the tag and gets a reference to that
     * Element.
     * 
     * @param Element
     *            element
     * @param String
     *            tagName
     * @return Element targetElement
     */
    public static Element getElement(Element start, String target)
    {
        NodeList nodeList = null;
        Node targetNode = null;
        Element targetElement = null;
        int targetCount = 0;

        nodeList = start.getElementsByTagName(target);
        targetCount = nodeList.getLength();
        // System.out.println("  found " + targetCount + " " + target);
        if (targetCount > 1)
        {
            // System.out.println("  Can't get more than 1 " + target);
        }
        else if (targetCount < 1)
        {
            // System.out.println("  Can't find element " + target);
        }
        else
        {
            targetNode = nodeList.item(0);
            if (targetNode.getNodeType() == 1)
            {
                targetElement = (Element) targetNode;
            }
            else
            {
                // System.out.println("  Target node not an Element");
            }
        }
        return targetElement;
    } // end getElement

    /**
     * Takes an XML element as a starting point and a tag name, looks for the tag among its child nodes and
     * gets a reference to that element.
     * 
     * @param Element
     *            element
     * @param String
     *            tagName
     * @return Element targetElement
     */
    public static Element getChildElement(Element start, String target)
    {
        NodeList nodeList = null;
        Node targetNode = null;
        Element targetElement = null;

        nodeList = start.getChildNodes();
        for (int i = 0; i < nodeList.getLength(); i++)
        {
            targetNode = nodeList.item(i);
            // System.out.println(targetNode.getNodeName() + " is a child of " + start.getNodeName() +
// ". NodeType = " + targetNode.getNodeType());
            if (targetNode.getNodeType() == 1 && targetNode.getNodeName().equals(target))
            {
                // System.out.println(targetNode.getNodeName() + " is the target child of " +
// start.getNodeName());
                targetElement = (Element) targetNode;
                break;
            }
        }
        if (targetElement == null)
        {
            // System.out.println("Could not find child of " + start.getNodeName() + " named " + target);
        }
        return targetElement;
    } // end getElement

    /**
     * Takes an XML element as a starting point and the tag name, looks for the tag and gets a reference to
     * that Element.
     * 
     * @param Element
     *            element
     * @param String
     *            tagName
     * @return Element targetElement
     */
    public static String getAttributeValue(Element start, String target, String attribute)
    {
        String aValue;
        Element targetElement = getElement(start, target);
        aValue = targetElement.getAttribute(attribute);
        return aValue;
    }

    /**
     * 
     * @param doc
     * @param xpathString
     * @return
     * @throws Exception
     */
    public static NodeList getNodeListByXpath(Document doc, String xpathString) throws Exception
    {
        NodeList nodeList = null;

        XPathFactory factory = XPathFactory.newInstance();
        XPath xpath = factory.newXPath();
        XPathExpression expr = xpath.compile(xpathString);

        Object result = expr.evaluate(doc, XPathConstants.NODESET);
        nodeList = (NodeList) result;

        return nodeList;
    }

    /**
     * Gets the element found using the xpath string
     * 
     * @param doc
     * @param xpathString
     * @return
     * @throws Exception
     */
    public static Element getElementByXpath(Document doc, String xpathString) throws Exception
    {
        Element targetElement = null;

        XPathFactory factory = XPathFactory.newInstance();
        XPath xpath = factory.newXPath();
        XPathExpression expr = xpath.compile(xpathString);

        Object result = expr.evaluate(doc, XPathConstants.NODESET);
        NodeList nodes = (NodeList) result;

        if (nodes.getLength() > 0)
            targetElement = (Element) nodes.item(0);

        return targetElement;
    }

    /**
     * Gets the element value found using the xpath string
     * 
     * @param doc
     * @param xpathString
     * @return
     * @throws Exception
     */
    public static String getElementValueByXpath(Document doc, String xpathString) throws Exception
    {
        String strValue = null;

        XPathFactory factory = XPathFactory.newInstance();
        XPath xpath = factory.newXPath();
        XPathExpression expr = xpath.compile(xpathString);

        Object result = expr.evaluate(doc, XPathConstants.NODESET);
        NodeList nodes = (NodeList) result;

        if (nodes.getLength() > 0)
        {
            Element targetElement = (Element) nodes.item(0);
            if (targetElement != null && targetElement.getFirstChild() != null)
            {
                strValue = targetElement.getFirstChild().getNodeValue();
            }
        }

        return strValue;
    }
    
    /**
     * 
     * @param doc
     * @param xpathString
     * @param value
     * @throws Exception
     */
    public static void setElementValueUsingXpath(Document doc, String xpathString, String value) throws Exception {
    	
    	Element element = getElementByXpath(doc, xpathString);
    	if(element == null) {
    		if(xpathString.startsWith("//") || 
    				!xpathString.substring(1, xpathString.indexOf("/", 2)).equals(doc.getDocumentElement().getNodeName()) ) {
    			throw new Exception("Invalid xpath string supplied: " + xpathString);
    		}
    		
    		element = createElementForXpath(doc, xpathString);
    		
    	}
    	
    	element.setTextContent(value);
    	
    }
    
    /**
     * Note: This is a recursive method
     * 
     * @param doc
     * @param xpathString
     * @return
     * @throws Exception
     */
    public static Element createElementForXpath(Document doc, String xpathString) throws Exception {
    	int elementIdx = xpathString.lastIndexOf("/");
    	String newXpathString = xpathString.substring(0, elementIdx);    		
		Element parentElement = getElementByXpath(doc, newXpathString);
		
		if(parentElement == null) {
			parentElement = createElementForXpath(doc, newXpathString);
		} 
		
		Element element = doc.createElement(xpathString.substring(elementIdx + 1));
		return (Element) parentElement.appendChild(element);
		
    }

    /**
     * Gets the attribute value belongs to an element found using the xpath string
     * 
     * @param doc
     * @param xpathString
     * @param attribName
     * @return
     * @throws Exception
     */
    public static String getAttributeValueByXpath(Document doc, String xpathString, String attribName) throws Exception
    {
        String strValue = null;

        XPathFactory factory = XPathFactory.newInstance();
        XPath xpath = factory.newXPath();
        XPathExpression expr = xpath.compile(xpathString);

        Object result = expr.evaluate(doc, XPathConstants.NODESET);
        NodeList nodes = (NodeList) result;

        if (nodes.getLength() > 0)
        {
            Element targetElement = (Element) nodes.item(0);
            if (targetElement != null)
            {
                strValue = targetElement.getAttribute(attribName);
            }
        }

        return strValue;
    }

    /**
     * Print the XML Document
     * 
     * @param document  DOM object
     * @param out       OutputStream for printed document
     * @return
     * @throws UnsupportedEncodingException
     * @throws TransformerException
     */
    public static void printDocument(Document doc, OutputStream out) throws UnsupportedEncodingException, TransformerException
    {
        printDocument(doc, null, 0, out);
    }

    /**
     * Print the XML Document
     * 
     * @param document  DOM object
     * @param indentLen Number of characters for indentation
     * @param out       OutputStream for printed document
     * @return
     * @throws UnsupportedEncodingException
     * @throws TransformerException
     */
    public static void printDocument(Document doc, int indentLen, OutputStream out) throws UnsupportedEncodingException, TransformerException
    {
        printDocument(doc, null, indentLen, out);
    }

    /**
     * Print the XML Document
     * 
     * @param document  DOM object
     * @param xsl       DOM object
     * @param out       OutputStream for printed document
     * @return
     * @throws UnsupportedEncodingException
     * @throws TransformerException
     */
    public static void printDocument(Document doc, StreamSource xsl, OutputStream out) throws UnsupportedEncodingException, TransformerException
    {
        printDocument(doc, xsl, 0, out);
    }

    /**
     * Print the XML Document
     * 
     * @param document  DOM object
     * @param xsl       DOM object
     * @param indentLen Number of characters for indentation
     * @param out       OutputStream for printed document
     * @return
     * @throws UnsupportedEncodingException
     * @throws TransformerException
     */
    public static void printDocument(Document doc, StreamSource xsl, int indentLen, OutputStream out) throws UnsupportedEncodingException, TransformerException
    {
        Transformer transformer = getTransformer(xsl, indentLen);

        transformer.transform(new DOMSource(doc), new StreamResult(new OutputStreamWriter(out, "UTF-8")));
    }

    /**
     * Convert to String the XML Document
     * 
     * @param doc
     * @return String
     * @throws TransformerException
     * @throws UnsupportedEncodingException
     */
    public static String toString(Document doc) throws UnsupportedEncodingException, TransformerException
    {
        return toString(doc, null, 0);
    }

    /**
     * Convert to String the XML Document
     * 
     * @param doc
     * @param indentLen
     * @return String
     * @throws TransformerException
     * @throws UnsupportedEncodingException
     */
    public static String toString(Document doc, int indentLen) throws UnsupportedEncodingException, TransformerException
    {
        return toString(doc, null, indentLen);
    }

    /**
     * Convert to String the XML Document
     * 
     * @param doc
     * @param indentLen
     * @return String
     * @throws TransformerException
     * @throws UnsupportedEncodingException
     */
    public static String toString(Document doc, StreamSource xsl) throws UnsupportedEncodingException, TransformerException
    {
        return toString(doc, xsl, 0);
    }

    /**
     * Convert to String the XML Document
     * 
     * @param doc
     * @param xsl
     * @param indentLen
     * @return String
     * @throws TransformerException
     * @throws UnsupportedEncodingException
     */
    public static String toString(Document doc, StreamSource xsl, int indentLen) throws UnsupportedEncodingException, TransformerException
    {
        Transformer transformer = getTransformer(xsl, indentLen);
        StringWriter writer = new StringWriter();
        Result result = new StreamResult(writer);
        transformer.transform(new DOMSource(doc), result);
        return writer.toString();
    }

    /**
     * Get the transformer for the XML Document
     * 
     * @param xsl
     * @param indentLen
     * @return Transformer
     * @throws TransformerException
     * @throws UnsupportedEncodingException
     */
    public static Transformer getTransformer(StreamSource xsl, int indentLen) throws UnsupportedEncodingException, TransformerException
    {
        TransformerFactory tf = TransformerFactory.newInstance();
        Transformer transformer = null;
        if (xsl != null)
        {
            transformer = tf.newTransformer(xsl);
        }
        else
        {
            transformer = tf.newTransformer();
            transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "no");
            transformer.setOutputProperty(OutputKeys.METHOD, "xml");
            transformer.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
            if (indentLen > 0)
            {
                transformer.setOutputProperty(OutputKeys.INDENT, "yes");
                transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", Integer.toString(indentLen));
            }
            else
            {
                transformer.setOutputProperty(OutputKeys.INDENT, "no");
            }
        }

        return transformer;
    }
    
    public static void main(String[] args) {
    	FileReader reader = null;
		
		try {
			/*
			reader = new FileReader("C:/Projects/NAAS/metaData2.xml");
			
			BufferedReader br = new BufferedReader(reader);
			String xmlString = br.readLine();
			
			Document doc = XMLUtil.getDocument(xmlString);
			*/
			
			File fXmlFile = new File("C:/Projects/NAAS/metaData.xml");
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(fXmlFile);
			
			String mileage = XMLUtil.getElementValueByXpath(doc, "/metaData/vehicle/service/mileage");
			
			System.out.println("mileage: " + mileage);
			
			XMLUtil.setElementValueUsingXpath(doc, "/metaData/vehicle2/service2/mileage2", "32000");
			
			String outputString = XMLUtil.toString(doc);
			System.out.println("outputString: " + outputString);
			
		} catch(Exception e) {
			e.printStackTrace();
		}
    }
}

