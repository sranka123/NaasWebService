package com.safelogic.naas.ach.manager.web.util;

import java.util.List;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.safelogic.naas.ach.manager.web.dao.NaasRepositoryImpl;
import com.safelogic.naas.ach.manager.web.model.SecurityQuestion;

public class TestNaasRepository {
	public static void main(String[] args) {
		EntityManagerFactory emFactory = Persistence.createEntityManagerFactory("testing");
		NaasRepositoryImpl<SecurityQuestion> naasRepository = new NaasRepositoryImpl<SecurityQuestion>();
		naasRepository.setType(SecurityQuestion.class);
		naasRepository.setEm(emFactory.createEntityManager());
		
		List<SecurityQuestion> questions = naasRepository.findAll();
		for(SecurityQuestion question:questions){
			System.out.println(question.getName()+" : "+question.getQuestion());
		}
		System.out.println(questions);
	}
}
