package com.safelogic.naas.ach.manager.web.dao;

import java.util.List;

import com.safelogic.naas.ach.manager.web.customer.group.SearchQuery;
import com.safelogic.naas.ach.manager.web.model.Customer;
import com.safelogic.naas.ach.manager.web.model.CustomerGroupBasicInfo;

public interface CustomerGroupDAO extends NaasRepository<Customer> {
	
	public SearchQuery updateSearchQuery(SearchQuery searchQuery);
	
	public List<CustomerGroupBasicInfo> getCustomerGroupsForAccountHolder(long achId);
}
