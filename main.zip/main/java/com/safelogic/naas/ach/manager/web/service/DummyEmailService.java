package com.safelogic.naas.ach.manager.web.service;

import java.util.List;

import javax.transaction.Transactional;
import javax.transaction.Transactional.TxType;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.safelogic.naas.ach.manager.web.NaasException;

@Service
@Qualifier("emailService")
@Transactional(value=TxType.REQUIRED)
public class DummyEmailService implements EmailService {

	Logger logger = LoggerFactory.getLogger(DummyEmailService.class);
	@Override
	public void sendEmail(List<String> toList,String from, String subject, String content) throws NaasException{
		if(toList.contains("rsawant@Avaya")){
			logger.error("Email sending failed");
			throw new NaasException("Failed to send email");
		}else{
			logger.debug("Sent email successfully!! below are email details!! ");
			logger.debug("to: {} :: subject: {} :: content: {}",toList,subject,content);
		}

	}

}
