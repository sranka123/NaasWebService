package com.safelogic.naas.ach.manager.web.customer.group;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.LazyCollection;
import org.hibernate.annotations.LazyCollectionOption;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.safelogic.naas.ach.manager.web.model.AccountHolder;
import com.safelogic.naas.ach.manager.web.model.NaasEntity;

@Entity
@Table(name="entity")
public class EntityObj extends NaasEntity{
	

	private static final long serialVersionUID = -5030518221159079435L;
	
	@LazyCollection(LazyCollectionOption.FALSE)
	@ManyToOne
	@JoinColumn(name="ach_id")
	@JsonIgnore
	AccountHolder accountHolder;
	
	@ManyToOne
	@JoinColumn(name="metadata_definition_id", referencedColumnName="id")	
	@JsonIgnore
	MetadataDefinition metadataDefinition;
	
	@Column(name="xpath_text")
	String xPath;

	public EntityObj() {
		super();
	}
	
	
	public AccountHolder getAccountHolder() {
		return accountHolder;
	}

	public void setAccountHolder(AccountHolder accountHolder) {
		this.accountHolder = accountHolder;
	}

	public MetadataDefinition getMetadataDefinition() {
		return metadataDefinition;
	}

	public void setMetadataDefinition(MetadataDefinition metadataDefinition) {
		this.metadataDefinition = metadataDefinition;
	}

	public String getxPath() {
		return xPath;
	}

	public void setxPath(String xPath) {
		this.xPath = xPath;
	}
	
	
}
