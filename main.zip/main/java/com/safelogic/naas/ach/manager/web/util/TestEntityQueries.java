package com.safelogic.naas.ach.manager.web.util;

import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import com.safelogic.naas.ach.manager.web.model.Category;
import com.safelogic.naas.ach.manager.web.model.Industry;
import com.safelogic.naas.ach.manager.web.model.SubIndustry;

public class TestEntityQueries {
	public static void main(String[] args) {
		EntityManagerFactory emFactory = Persistence.createEntityManagerFactory("naas-entity-mapping");
	    EntityManager em = emFactory.createEntityManager();
	    testSubIndustriesFromIndustry(em);
	    emFactory.close();
	}

	private static void testSubIndustriesFromIndustry(EntityManager em) {
		 em.getTransaction().begin();
		
		Industry industry = new Industry();
		industry.setName("Agriculture and Mining");
		em.persist(industry);
		
		SubIndustry sub1 = new SubIndustry();
		sub1.setName("Farming and Ranching");
		
		SubIndustry sub2 = new SubIndustry();
		sub2.setName("Mining and Quarrying");
		em.persist(sub1);
		em.persist(sub2);
		
		Category category1 = new Category();
		category1.setIndustry(industry);
		category1.setSubIndustry(sub1);
		
		Category category2 = new Category();
		category2.setIndustry(industry);
		category2.setSubIndustry(sub2);

		em.persist(category1);
		em.persist(category2);
		TypedQuery<Category> query =  em.createQuery("Select category from Category category where category.industry.id = :industry_id",Category.class);
		query.setParameter("industry_id", industry.getId());
		List<SubIndustry> list = query.getResultList().stream()
				.map(elt->elt.getSubIndustry()).collect(Collectors.toList());
		for(SubIndustry subIndustry:list){
			System.out.println(subIndustry.getName());
		}
		
	    em.getTransaction().commit();
	    em.close();		
	}
}
