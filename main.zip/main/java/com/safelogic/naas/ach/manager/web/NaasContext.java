package com.safelogic.naas.ach.manager.web;

public class NaasContext {
	
	private static final NaasContext naasContext = new NaasContext();
	
	private String userEmail;
	
	private String adminEmail;
	
	private String tokenUrl;

	private NaasContext() {
		// TODO Auto-generated constructor stub
	}
	public String getTokenUrl() {
		return tokenUrl;
	}

	public void setTokenUrl(String tokenUrl) {
		this.tokenUrl = tokenUrl;
	}
	
	public static NaasContext getInstane(){
		return naasContext;
	}
	public String getUserEmail() {
		return userEmail;
	}
	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}
	public String getAdminEmail() {
		return adminEmail;
	}
	public void setAdminEmail(String adminEmail) {
		this.adminEmail = adminEmail;
	}
}
