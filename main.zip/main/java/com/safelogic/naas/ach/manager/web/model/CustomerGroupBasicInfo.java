package com.safelogic.naas.ach.manager.web.model;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name="customer_group")
public class CustomerGroupBasicInfo extends NaasEntity {
	
	private static final long serialVersionUID = 7169966828726784908L;
	
	public CustomerGroupBasicInfo(){
		
	}
	@ManyToOne(fetch=FetchType.LAZY)
	private AccountHolder accountHolder;

	@JsonIgnore
	public AccountHolder getAccountHolder() {
		return accountHolder;
	}
	public void setAccountHolder(AccountHolder accountHolder) {
		this.accountHolder = accountHolder;
	}
	
	
}
