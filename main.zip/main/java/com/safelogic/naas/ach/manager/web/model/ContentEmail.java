package com.safelogic.naas.ach.manager.web.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Lob;
import javax.persistence.Table;

@Entity
@Table(name="email_content")
public class ContentEmail extends NaasEntity {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 93883737373784L;

	@Column(name="subject")
	private String subject;
	
	@Lob
	@Column(name="source_content")
	private String sourceContent;

	@Lob
	@Column(name="delivery_content")
	private String deliveryContent;	
	
	
	
	public String getSourceContent() {
		return sourceContent;
	}

	public void setSourceContent(String content) {
		this.sourceContent = content;
	}

	public String getDeliveryContent() {
		return deliveryContent;
	}

	public void setDeliveryContent(String deliveryContent) {
		this.deliveryContent = deliveryContent;
	}

	/**
	 * @return the subject
	 */
	public String getSubject() {
		return subject;
	}

	/**
	 * @param subject the subject to set
	 */
	public void setSubject(String subject) {
		this.subject = subject;
	}

	
}
