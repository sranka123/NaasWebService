package com.safelogic.naas.ach.manager.web.util;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.safelogic.naas.ach.manager.web.model.ContentEmail;

public class AddContent {
	public static void main(String[] args) throws IOException {
		EntityManagerFactory emFactory = Persistence.createEntityManagerFactory("testing");
	    EntityManager em = emFactory.createEntityManager();
	    em.getTransaction().begin();
	    ContentEmail contentEmail  = new ContentEmail();
	    contentEmail.setDeliveryContent(new String(Files.readAllBytes(Paths.get("F:/work/Git_Repos_SafeLogic/ACHManager/src/main/webapp/static/test.html"))));
	    em.persist(contentEmail);
	    em.getTransaction().commit();
	    //em.flush();
	    em.close();
	    emFactory.close();
	}
}
