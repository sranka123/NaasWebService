/**
 * 
 */
package com.safelogic.naas.ach.manager.web.service;

import java.util.List;

import com.safelogic.naas.ach.manager.web.model.ContentEmail;
import com.safelogic.naas.ach.manager.web.model.ContentSms;
import com.safelogic.naas.ach.manager.web.model.ContentTemplate;

public interface ContentService {

	public ContentEmail getEmailContent(long id);
	public List<ContentEmail> getAllEmailContent();
	public ContentEmail saveNewEmailContent(ContentEmail content);
	public void updateEmailContent(ContentEmail content);
	
	public ContentTemplate getTemplateContent(long id);
	public List<ContentTemplate> getAllTemplateContent();
	public ContentTemplate saveNewTemplateContent(ContentTemplate content);
	public void updateTemplateContent(ContentTemplate content);
	
	public ContentSms getSmsContent(long id);
	public List<ContentSms> getAllSmsContent();
	public ContentSms saveNewSmsContent(ContentSms content);
	public ContentSms updateSmsContent(ContentSms content);
	public ContentSms approveOrRejectSmsContent(ContentSms content,Boolean approveOrNot);
	public ContentSms sendForApproval(ContentSms content,Boolean sendForApproval);
	public void deleteSmsContent(ContentSms content);
}
