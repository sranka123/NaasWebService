package com.safelogic.naas.ach.manager.web.dao;

import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.safelogic.naas.ach.manager.web.model.AccountHolder;
import com.safelogic.naas.ach.manager.web.model.Category;
import com.safelogic.naas.ach.manager.web.model.Industry;
import com.safelogic.naas.ach.manager.web.model.Notification;
import com.safelogic.naas.ach.manager.web.model.SubIndustry;

@Repository("accountHolderDao")
@Transactional(readOnly = true)
public class AccountHolderDAOImpl extends NaasRepositoryImpl<AccountHolder> implements AccountHolderDAO {

    @PersistenceContext
    private EntityManager em;
    
	@Override
	public List<Industry> getAllIndustries() {
		return em.createQuery("Select industry from Industry industry",Industry.class).getResultList();
	}

	@Override
	public List<SubIndustry> getSubIndustries(Industry industry) {
		
		TypedQuery<Category> query =  em.createQuery("Select category from Category category where category.industry.id = :industry_id",Category.class);
		query.setParameter("industry_id", industry.getId());
		List<SubIndustry> list = query.getResultList().stream()
				.map(elt->elt.getSubIndustry()).collect(Collectors.toList());

		return list;
	}


	@Override
	public Category getCategory(Industry industry, SubIndustry subIndustry) {
		TypedQuery<Category> query = em.createQuery("Select category from Category category where category.industry.id = :industry_id and category.subIndustry.id = :subindustry_id",Category.class);
		query.setParameter("industry_id", industry.getId());
		query.setParameter("subindustry_id",subIndustry.getId());
		return query.getSingleResult();
	}

}
