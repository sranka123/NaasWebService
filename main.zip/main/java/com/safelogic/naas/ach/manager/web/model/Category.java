package com.safelogic.naas.ach.manager.web.model;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="industry_mapping_table")
public class Category {
	
	@Id
	@GeneratedValue
	@Column(name="industry_mapping_id")
	private long id;
	
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="industry_id")
	private Industry industry;
	
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="sub_industry_id")
	private SubIndustry subIndustry;
	
	public Category() {
		// TODO Auto-generated constructor stub
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public Industry getIndustry() {
		return industry;
	}

	public void setIndustry(Industry industry) {
		this.industry = industry;
	}

	public SubIndustry getSubIndustry() {
		return subIndustry;
	}

	public void setSubIndustry(SubIndustry subIndustry) {
		this.subIndustry = subIndustry;
	}
	
	
}
