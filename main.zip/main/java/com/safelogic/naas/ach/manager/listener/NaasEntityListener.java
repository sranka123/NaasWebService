package com.safelogic.naas.ach.manager.listener;

import javax.persistence.PostPersist;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;

import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

import com.safelogic.naas.ach.manager.web.model.NaasEntity;
import com.safelogic.naas.ach.manager.web.security.NaasAccountHolderUser;

public class NaasEntityListener {
	
	Logger fileLogger = LoggerFactory.getLogger("fileLogger");
	@PrePersist
	public void prePersist(NaasEntity naasEntity){
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		if(auth.getPrincipal() instanceof NaasAccountHolderUser){
			NaasAccountHolderUser currentUser = (NaasAccountHolderUser)auth.getPrincipal();
			naasEntity.setCreatedByUser(currentUser.getUsername());
			naasEntity.setCreateDate(DateTime.now());
		}
	}
	
	@PostPersist
	public void postPersist(NaasEntity naasEntity){
		
	}
	
	
	@PreUpdate
	public void preUpdate(NaasEntity naasEntity){
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		if(auth.getPrincipal() instanceof NaasAccountHolderUser){
			NaasAccountHolderUser currentUser = (NaasAccountHolderUser)auth.getPrincipal();
			naasEntity.setModifiedByUser(currentUser.getUsername());
			naasEntity.setModifiedDate(DateTime.now());
		}
	}
}
