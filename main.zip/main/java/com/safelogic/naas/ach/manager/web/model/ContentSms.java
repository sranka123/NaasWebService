package com.safelogic.naas.ach.manager.web.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="sms_content")
public class ContentSms extends NaasEntity {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 7484958383794L;

	private String content;
	
	
	private int contentStatus;
	
	private String lastRejectReason;
	
	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	
	public ContentStatus getStatus() {
		return ContentStatus.getContentStatus(contentStatus);
	}

	public void setStatus(ContentStatus status) {
		this.contentStatus = status.getCode();
	}

	public String getLastRejectReason() {
		return lastRejectReason;
	}

	public void setLastRejectReason(String lastRejectReason) {
		this.lastRejectReason = lastRejectReason;
	}
	
	
}
