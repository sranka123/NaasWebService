package com.safelogic.naas.ach.manager.web.customer.group;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.LazyCollection;
import org.hibernate.annotations.LazyCollectionOption;

import com.safelogic.naas.ach.manager.web.model.AccountHolder;
import com.safelogic.naas.ach.manager.web.model.NaasEntity;

@Entity
@Table(name = "condition_line")
public class ConditionLine extends NaasEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8999547445465030283L;

	@ManyToOne
	@JoinColumn(name = "ach_id")
	AccountHolder accountHolder;

	@ManyToOne
	@JoinColumn(name = "field_id", referencedColumnName = "id")
	private Field field;

	@LazyCollection(LazyCollectionOption.FALSE)
	@ManyToOne(cascade=CascadeType.ALL) 
	@JoinColumn(name = "search_query_id", referencedColumnName = "id")
	private SearchQuery searchQuery;

	@ManyToOne
	@JoinColumn(name = "operator_id", referencedColumnName = "id")
	private Operator operator;

	@Column(name = "value_text")
	private String valueText;

	public ConditionLine() {
		super();
	}

	public AccountHolder getAccountHolder() {
		return accountHolder;
	}

	public void setAccountHolder(AccountHolder accountHolder) {
		this.accountHolder = accountHolder;
	}

	public Field getField() {
		return field;
	}

	public void setField(Field field) {
		this.field = field;
	}

	public SearchQuery getSearchQuery() {
		return searchQuery;
	}

	public void setSearchQuery(SearchQuery searchQuery) {
		this.searchQuery = searchQuery;
	}

	public Operator getOperator() {
		return operator;
	}

	public void setOperator(Operator operator) {
		this.operator = operator;
	}

	public String getValueText() {
		return valueText;
	}

	public void setValueText(String valueText) {
		this.valueText = valueText;
	}

	public String getSQLWhereClause() {

		
		String leftHand = field.getSQLColumn();
		String sqlOperator = operator.getSymbol();
		String rightHand = convertRHSForDataType();
		StringBuffer sqlWhereClause = new StringBuffer();

		sqlWhereClause.append(leftHand).append(" ").append(sqlOperator).append(" ").append(rightHand).append(" ");
		return sqlWhereClause.toString();
	}

	public String convertRHSForDataType(){
		DataType dataType = field.getDataType();
		
		String rightHand = "";
		if(dataType.getName().equals("string")){
			if(operator.getName().equals("equals")){
				rightHand = "'"+valueText+"'";
			}else if(operator.getName().equals("starts_with")){
				rightHand = "'"+valueText+"%'";
			}else if(operator.getName().equals("ends_with")){
				rightHand = "'%"+valueText+"'";
			}else if(operator.getName().equals("like")){
				rightHand = "'%"+valueText+"%'";
			}else if(operator.getName().equals("in")){
				rightHand = "("+valueText+")"; // parse string and enclose with single quotes
			}
		}else if(dataType.getName().equals("number")){
			
			if(operator.getName().equals("in")){
				rightHand = "("+valueText+")";
			}else{
				rightHand = valueText;
			}
		}else if(dataType.getName().equals("date")){
			rightHand = "str_to_date('"+valueText+"', '%m/%d/%Y')";
		}else if(dataType.getName().equals("boolean")){
			rightHand = valueText.equalsIgnoreCase("Yes")?"1":"0";
		}
		
		return rightHand;
	}
}
