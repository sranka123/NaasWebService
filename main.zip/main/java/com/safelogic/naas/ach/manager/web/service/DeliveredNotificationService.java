package com.safelogic.naas.ach.manager.web.service;

import com.safelogic.naas.ach.manager.web.model.AccountHolder;

public interface DeliveredNotificationService {
	
	public int getMonthlyCountOfEmail(AccountHolder ach);
	
	public int getMonthlyCountOfSms(AccountHolder ach);
	
	
}
