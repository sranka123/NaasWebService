package com.safelogic.naas.ach.manager.web.dao;

import java.util.List;

import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.safelogic.naas.ach.manager.web.model.AccountHolder;
import com.safelogic.naas.ach.manager.web.model.Customer;

@Repository("customerDao")
public class CustomerDAOImpl extends NaasRepositoryImpl<Customer> implements CustomerDAO {

	
	@Override
	public int getCustomerCount(long groupId) {
		return getCustomers(groupId).size();
	}

	@Override
	public List<Customer> getCustomers(long groupId) {
		TypedQuery<Customer> queryMemberOf = em.createQuery(
			    "SELECT customer FROM Customer customer INNER JOIN customer.customerGroups cGroup WHERE cGroup.id =:groupId", Customer.class);
			queryMemberOf.setParameter("groupId", groupId);
		return queryMemberOf.getResultList();
	}
	
	@Override
	public long getCustomerCount(String sqlWhereClause) {
		Query query = em.createQuery("select count(customer) FROM Customer customer " + sqlWhereClause);
		
		Object obj = query.getSingleResult();
		
		return (Long) obj;	
	}

	@Override
	public List<Customer> getCustomers(String sqlWhereClause) {
		TypedQuery<Customer> queryMemberOf = em.createQuery(
			    "select customer FROM Customer customer " + sqlWhereClause, 
			    Customer.class);
		
		return queryMemberOf.getResultList();
	}

	@Override
	public List<Customer> getCustomersForAccountHolder(AccountHolder ach) {
		TypedQuery<Customer> queryMemberOf = em.createQuery(
			    "select customer FROM Customer customer where customer.accountHolder.id = :ach_id" , Customer.class);
		queryMemberOf.setParameter("ach_id", ach.getId());
		return queryMemberOf.getResultList();
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<Object[]> getCustomersWithNotificationCount(AccountHolder ach) {
		
		Query queryMemberOf = 
				em.createQuery("select c ,count(dnc) FROM  DeliveredNotification dnc "
						+ "right join dnc.customer c"
						+ " where c.accountHolder.id = :ach_id"			 
						+" group by c.id");
						
		queryMemberOf.setParameter("ach_id", ach.getId());
		return queryMemberOf.getResultList();
	}
	
}
