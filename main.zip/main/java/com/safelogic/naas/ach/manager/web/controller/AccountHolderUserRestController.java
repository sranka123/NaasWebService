package com.safelogic.naas.ach.manager.web.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.safelogic.naas.ach.manager.web.model.AccountHolder;
import com.safelogic.naas.ach.manager.web.security.NaasAccountHolderUser;
import com.safelogic.naas.ach.manager.web.service.AccountHolderUserService;

@RestController
//@RequestMapping(value=NaasURIConstants.ach)
public class AccountHolderUserRestController {
	
	@Autowired
	AccountHolderUserService accountHolderUserService;
	
	
	@RequestMapping(value="/{userName}", params={"isUnique"}, method=RequestMethod.GET)
	public String isUniqueName(@PathVariable String userName, @AuthenticationPrincipal NaasAccountHolderUser currentUser){
		AccountHolder accountHolder = new AccountHolder();
		accountHolder.setName(currentUser.getAccountHolderName());
		return accountHolderUserService.isUserNameUnique(userName,accountHolder)?"true":"false";
	}
}
