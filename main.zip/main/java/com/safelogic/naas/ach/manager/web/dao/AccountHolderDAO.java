package com.safelogic.naas.ach.manager.web.dao;

import java.util.List;

import com.safelogic.naas.ach.manager.web.model.AccountHolder;
import com.safelogic.naas.ach.manager.web.model.Category;
import com.safelogic.naas.ach.manager.web.model.Industry;
import com.safelogic.naas.ach.manager.web.model.SubIndustry;

public interface AccountHolderDAO extends NaasRepository<AccountHolder> {
	public List<Industry> getAllIndustries();
	public List<SubIndustry> getSubIndustries(Industry industry);
	public Category getCategory(Industry industry,SubIndustry subIndustry);	
}
