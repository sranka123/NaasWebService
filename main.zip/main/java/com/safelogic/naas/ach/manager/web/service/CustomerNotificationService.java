package com.safelogic.naas.ach.manager.web.service;

import java.util.List;
import java.util.Map;

import com.safelogic.naas.ach.manager.web.model.AccountHolder;
import com.safelogic.naas.ach.manager.web.model.Customer;
import com.safelogic.naas.ach.manager.web.model.CustomerGroup;
import com.safelogic.naas.ach.manager.web.model.DeliveredNotification;
import com.safelogic.naas.ach.manager.web.model.Notification;

public interface CustomerNotificationService {
	
	
	public Customer saveCustomer(Customer customer);
	public Customer updateCustomer(Customer customer);
	
	public Customer getCustomer(long id);
	public Customer getCustomer(String emailId);//assuming email is the primary key. This needs some discussion
	public List<Customer> getAllCustomers();
	public List<Customer> getCustomersForAccountHolder(AccountHolder ach);
	public Map<Customer, Long> getCustomersWithNotificationCount(AccountHolder ach);
	public int getCustomerCount(long groupId);
	public List<Customer> getCustomersForGroup(long groupId);
	public boolean deleteCustomer(Customer customer);
	
	//temperory thing...will go away
	public CustomerGroup saveCustomerGroup(CustomerGroup customerGroup);
	public CustomerGroup updateCustomerGroup(CustomerGroup customerGroup);
	public CustomerGroup getGroup(String groupName);
	
	public List<CustomerGroup> getAllCustomerGroups();
	public Notification saveNotification(Notification notification);
	public List<Notification> getAllNotifications();
	public Notification getNotificationByName(String name);
	
	public int getMonthlyDeliveredSmsCount(AccountHolder ach);
	public int getMonthlyDeliveredEmailCount(AccountHolder ach);
	public List<DeliveredNotification> listOfNotificationDeliveredToCustomer(Customer customer);
}
