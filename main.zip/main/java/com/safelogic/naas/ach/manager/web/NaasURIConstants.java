package com.safelogic.naas.ach.manager.web;

public final class NaasURIConstants {
	
	public static final String  userBase = "/user";
	
	public static final String userNameParamName = "username";
	
	public static final String passwordParamName = "password";
	
	public static final String companyCodeParamName = "companycode";
	
	public static final String contentRest = "/app/content/rest";
	
	public static final String contentGroupingRest = "/app/content_groping/rest";
	
	public static final String naasAppUrl = "/app";
	
	public static final String loginProcessingUrl = "/j_spring_security_check";
	
	public static final String loginFailureUrl = "/au/l?error=true";
	
	public static final String login = "/rest/login";
	
	public static final String customerBase = "/rest/customer";
	
	public static final String customerGroupBase = "/rest/customergroup";
}
