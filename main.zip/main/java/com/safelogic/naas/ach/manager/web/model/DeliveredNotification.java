package com.safelogic.naas.ach.manager.web.model;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name="delivered_notifiaction")
public class DeliveredNotification extends NaasEntity{
	
	private static final long serialVersionUID = 3386705534763270121L;
	
	@ManyToOne(fetch=FetchType.LAZY)
	private ContentEmail contentEmail;
	
	@ManyToOne(fetch=FetchType.LAZY)
	private ContentSms contentSms;
	
	@ManyToOne(fetch=FetchType.LAZY)
	private Customer customer;
	
	@ManyToOne
	private Notification notification;
	
	@ManyToOne(fetch=FetchType.LAZY)
	private AccountHolder accountHolder;
	
	@Transient
	private String deliveryChannel;
	


	public DeliveredNotification() {
		super();
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public AccountHolder getAccountHolder() {
		return accountHolder;
	}

	public void setAccountHolder(AccountHolder accountHolder) {
		this.accountHolder = accountHolder;
	}
	public ContentEmail getContentEmail() {
		return contentEmail;
	}

	public void setContentEmail(ContentEmail contentEmail) {
		this.contentEmail = contentEmail;
	}

	public ContentSms getContentSms() {
		return contentSms;
	}

	public void setContentSms(ContentSms contentSms) {
		this.contentSms = contentSms;
		
	}

	public Notification getNotification() {
		return notification;
	}

	public void setNotification(Notification notification) {
		this.notification = notification;
	}
	public String getDeliveryChannel() {
		return contentEmail != null?"Email":"SMS";
	}

	public void setDeliveryChannel(String deliveryChannel) {
		this.deliveryChannel = deliveryChannel;
	}
}
