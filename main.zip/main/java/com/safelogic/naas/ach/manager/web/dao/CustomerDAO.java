package com.safelogic.naas.ach.manager.web.dao;

import java.util.List;

import com.safelogic.naas.ach.manager.web.model.AccountHolder;
import com.safelogic.naas.ach.manager.web.model.Customer;

public interface CustomerDAO extends NaasRepository<Customer>{
	public int getCustomerCount(long groupId);
	public List<Customer> getCustomersForAccountHolder(AccountHolder ach);
	public List<Customer> getCustomers(long groupId);	
	public List<Customer> getCustomers(String sqlWhereClause);
	public long getCustomerCount(String sqlWhereClause);
	public List<Object[]>getCustomersWithNotificationCount(AccountHolder ach);
}
