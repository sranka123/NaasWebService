-- MySQL dump 10.13  Distrib 5.7.12, for Win64 (x86_64)
--
-- Host: naas-demo.co6qvh4uzonj.us-east-1.rds.amazonaws.com    Database: naas_db
-- ------------------------------------------------------
-- Server version	5.6.27-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `condition_line`
--

DROP TABLE IF EXISTS `condition_line`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `condition_line` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `value_text` varchar(255) DEFAULT NULL,
  `ach_id` bigint(20) DEFAULT NULL,
  `field_id` bigint(20) DEFAULT NULL,
  `operator_id` bigint(20) DEFAULT NULL,
  `search_query_id` bigint(20) DEFAULT NULL,
  `create_user` varchar(200) DEFAULT NULL,
  `update_user` varchar(200) DEFAULT NULL,
  `create_date` datetime DEFAULT NULL,
  `update_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKgblt64f857n96r81j10u2bbmd` (`ach_id`),
  KEY `FKf8kf71musjr7vy9r7e0h76jp6` (`field_id`),
  KEY `FKn0s1qh52at24dn1wmxq242mti` (`operator_id`),
  KEY `FK66uqagw9vlpipfi2nuaq2i0hk` (`search_query_id`),
  CONSTRAINT `FK66uqagw9vlpipfi2nuaq2i0hk` FOREIGN KEY (`search_query_id`) REFERENCES `search_query` (`id`),
  CONSTRAINT `FKf8kf71musjr7vy9r7e0h76jp6` FOREIGN KEY (`field_id`) REFERENCES `field` (`id`),
  CONSTRAINT `FKgblt64f857n96r81j10u2bbmd` FOREIGN KEY (`ach_id`) REFERENCES `account_holder_master` (`ach_id`),
  CONSTRAINT `FKn0s1qh52at24dn1wmxq242mti` FOREIGN KEY (`operator_id`) REFERENCES `operator` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `condition_line`
--

LOCK TABLES `condition_line` WRITE;
/*!40000 ALTER TABLE `condition_line` DISABLE KEYS */;
INSERT INTO `condition_line` VALUES (34,NULL,'30000',NULL,19,3,11,NULL,NULL,NULL,NULL),(35,NULL,'35000',NULL,19,2,11,NULL,NULL,NULL,NULL),(37,NULL,'Feroz Khan',NULL,1,1,12,'sashi_v@hotmail.com',NULL,'2016-08-31 17:22:52',NULL),(38,NULL,'Rajan',NULL,2,1,13,'sashi_v@hotmail.com',NULL,'2016-09-08 01:31:36',NULL),(41,NULL,'25000',NULL,19,3,15,'sashi_v@hotmail.com',NULL,'2016-10-04 14:26:00',NULL),(42,NULL,'35000',NULL,19,2,15,'sashi_v@hotmail.com',NULL,'2016-10-04 14:26:00',NULL),(43,NULL,'78727',NULL,12,1,15,'sashi_v@hotmail.com',NULL,'2016-10-04 14:26:00',NULL),(44,NULL,'25000',NULL,19,3,14,'sashi_v@hotmail.com',NULL,'2016-12-07 20:55:55',NULL),(45,NULL,'35000',NULL,19,2,14,'sashi_v@hotmail.com',NULL,'2016-12-07 20:55:55',NULL),(46,NULL,'78727',NULL,12,1,16,'sashi_v@hotmail.com',NULL,'2016-12-24 19:54:43',NULL),(47,NULL,'40000',NULL,19,3,17,'sashi_v@hotmail.com',NULL,'2017-02-11 12:19:57',NULL);
/*!40000 ALTER TABLE `condition_line` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-02-26 16:11:06
