-- MySQL dump 10.13  Distrib 5.7.12, for Win64 (x86_64)
--
-- Host: naas-demo.co6qvh4uzonj.us-east-1.rds.amazonaws.com    Database: naas_db
-- ------------------------------------------------------
-- Server version	5.6.27-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `search_query`
--

DROP TABLE IF EXISTS `search_query`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `search_query` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `ach_id` bigint(20) DEFAULT NULL,
  `create_user` varchar(200) DEFAULT NULL,
  `update_user` varchar(200) DEFAULT NULL,
  `create_date` datetime DEFAULT NULL,
  `update_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKgja7ifr4d61dxsd4xxcsknf0a` (`ach_id`),
  CONSTRAINT `FKgja7ifr4d61dxsd4xxcsknf0a` FOREIGN KEY (`ach_id`) REFERENCES `account_holder_master` (`ach_id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `search_query`
--

LOCK TABLES `search_query` WRITE;
/*!40000 ALTER TABLE `search_query` DISABLE KEYS */;
INSERT INTO `search_query` VALUES (11,'Customer Group 03',1,'Sashi Rajan','Sashi Rajan','2016-06-13 22:34:41','2016-06-14 21:58:52'),(12,'Feroz-My-Group',1,'sashi_v@hotmail.com','sashi_v@hotmail.com','2016-08-31 17:22:18','2016-08-31 17:22:52'),(13,'Sashi_Group',1,'sashi_v@hotmail.com','Sashi Rajan','2016-09-08 01:31:36','2016-09-08 01:31:36'),(14,'30k_mileage_for_all_zipcodes',1,'sashi_v@hotmail.com','sashi_v@hotmail.com','2016-10-01 17:48:58','2016-12-07 20:55:55'),(15,'30K_promo_zipcode_78727',1,'sashi_v@hotmail.com','Sashi_V Rajan','2016-10-04 14:26:00','2016-10-04 14:26:00'),(16,'test',1,'sashi_v@hotmail.com','Sashi Rajan','2016-12-24 19:54:43','2016-12-24 19:54:43'),(17,'Tire_Promotion_Grouping',1,'sashi_v@hotmail.com','Sashi Rajan','2017-02-11 12:19:57','2017-02-11 12:19:57');
/*!40000 ALTER TABLE `search_query` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-02-26 16:11:21
