-- MySQL dump 10.13  Distrib 5.7.12, for Win64 (x86_64)
--
-- Host: naas-demo.co6qvh4uzonj.us-east-1.rds.amazonaws.com    Database: naas_db
-- ------------------------------------------------------
-- Server version	5.6.27-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `customer_group`
--

DROP TABLE IF EXISTS `customer_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customer_group` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `ach_id` bigint(20) DEFAULT NULL,
  `create_user` varchar(200) DEFAULT NULL,
  `update_user` varchar(200) DEFAULT NULL,
  `create_date` datetime DEFAULT NULL,
  `update_date` datetime DEFAULT NULL,
  `delete_date` datetime DEFAULT NULL,
  `delete_user` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKgja7ifr4d61dxsd4xxcsknf0a` (`ach_id`),
  CONSTRAINT `FKgja7ifr4d61dxsd4xxcsknf0a` FOREIGN KEY (`ach_id`) REFERENCES `account_holder_master` (`ach_id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer_group`
--

LOCK TABLES `customer_group` WRITE;
/*!40000 ALTER TABLE `customer_group` DISABLE KEYS */;
INSERT INTO `customer_group` VALUES (11,'Customer Group 03',1,'Sashi Rajan','Sashi Rajan','2016-06-13 22:34:41','2016-06-14 21:58:52',NULL,NULL),(12,'Feroz-My-Group',1,'sashi_v@hotmail.com','sashi_v@hotmail.com','2016-08-31 17:22:18','2016-08-31 17:22:52',NULL,NULL),(13,'Sashi_Group',1,'sashi_v@hotmail.com','Sashi Rajan','2016-09-08 01:31:36','2016-09-08 01:31:36',NULL,NULL),(14,'30k_mileage_for_all_zipcodes',1,'sashi_v@hotmail.com','sashi_v@hotmail.com','2016-10-01 17:48:58','2016-12-07 20:55:55',NULL,NULL),(15,'30K_promo_zipcode_78727',1,'sashi_v@hotmail.com','Sashi_V Rajan','2016-10-04 14:26:00','2016-10-04 14:26:00',NULL,NULL),(16,'test',1,'sashi_v@hotmail.com','Sashi Rajan','2016-12-24 19:54:43','2016-12-24 19:54:43',NULL,NULL),(20,'Sumanth Test Customer Group',1,NULL,NULL,'2017-03-07 22:40:31','2017-03-07 22:40:31',NULL,NULL),(21,'Sumanth Test Customer Group',1,NULL,NULL,'2017-03-07 22:42:01','2017-03-07 22:42:01',NULL,NULL),(22,'Sumanth Test Customer Group Again',1,NULL,NULL,'2017-03-07 23:00:41','2017-03-07 23:00:41',NULL,NULL),(23,'Sumanth Test Customer Group Again',1,NULL,NULL,'2017-03-07 23:00:00','2017-03-07 23:00:00',NULL,NULL),(24,'Sumanth Test Customer Group Again',1,NULL,NULL,'2017-03-07 23:05:49','2017-03-07 23:05:49',NULL,NULL),(25,'Sumanth Test Customer Group Again',1,NULL,NULL,'2017-03-07 23:06:50','2017-03-07 23:06:50',NULL,NULL);
/*!40000 ALTER TABLE `customer_group` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-03-08  8:31:19
