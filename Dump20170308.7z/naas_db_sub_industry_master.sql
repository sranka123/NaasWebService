-- MySQL dump 10.13  Distrib 5.7.12, for Win64 (x86_64)
--
-- Host: naas-demo.co6qvh4uzonj.us-east-1.rds.amazonaws.com    Database: naas_db
-- ------------------------------------------------------
-- Server version	5.6.27-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `sub_industry_master`
--

DROP TABLE IF EXISTS `sub_industry_master`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sub_industry_master` (
  `sub_industry_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `sub_industry_name` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`sub_industry_id`)
) ENGINE=InnoDB AUTO_INCREMENT=163 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sub_industry_master`
--

LOCK TABLES `sub_industry_master` WRITE;
/*!40000 ALTER TABLE `sub_industry_master` DISABLE KEYS */;
INSERT INTO `sub_industry_master` VALUES (1,'Farming and Ranching'),(2,'Fishing, Hunting and Forestry and Logging'),(3,'Mining and Quarrying'),(4,'Agriculture and Mining'),(5,'Accounting and Tax Preparation'),(6,'Advertising, Marketing and PR'),(7,'Data and Records Management'),(8,'Facilities Management and Maintenance'),(9,'HR and Recruiting Services'),(10,'Legal Services'),(11,'Management Consulting'),(12,'Payroll Services'),(13,'Sales Services'),(14,'Security Services'),(15,'Business Services Other'),(16,'Audio, Video and Photography'),(17,'Computers, Parts and Repair'),(18,'Consumer Electronics, Parts and Repair'),(19,'IT and Network Services and Support'),(20,'Instruments and Controls'),(21,'Network Security Products'),(22,'Networking equipment and Systems'),(23,'Office Machinery and Equipment'),(24,'Peripherals Manufacturing'),(25,'Semiconductor and Microchip Manufacturing'),(26,'Computer and Electronics Other'),(27,'Automotive Repair and Maintenance'),(28,'Funeral Homes and Services'),(29,'Laundry and Dry Cleaning'),(30,'Parking Lots and Garage Management'),(31,'Personal Care'),(32,'Photofinishing Services'),(33,'Consumer Services Other'),(34,'Colleges and Universities'),(35,'Elementary and Secondary Schools'),(36,'Libraries, Archives and Museums'),(37,'Sports, Arts, and Recreation Instruction'),(38,'Technical and Trade Schools'),(39,'Test Preparation'),(40,'Education Other'),(41,'Alternative Energy Sources'),(42,'Gas and Electric Utilities'),(43,'Gasoline and Oil Refineries'),(44,'Sewage Treatment Facilities'),(45,'Waste Management and Recycling'),(46,'Water Treatment and Utilities'),(47,'Energy and Utilities Other'),(48,'Banks'),(49,'Credit Cards and Related Services'),(50,'Credit Unions'),(51,'Insurance and Risk Management'),(52,'Investment Banking and Venture Capital'),(53,'Lending and Mortgage'),(54,'Personal Financial Planning and Private Banking'),(55,'Securities Agents and Brokers'),(56,'Trust, Fiduciary, and Custody Activities'),(57,'Financial Services Other'),(58,'International Bodies and Organizations'),(59,'Local Government'),(60,'National Government'),(61,'State/Provincial Government'),(62,'Government Other'),(63,'Biotechnology'),(64,'Diagnostic Laboratories'),(65,'Doctors and Health Care Practitioners'),(66,'Hospitals'),(67,'Medical Devices'),(68,'Medical Supplies and Equipment'),(69,'Outpatient Care Centers'),(70,'Personal Health Care Products'),(71,'Pharmaceuticals'),(72,'Residential and Long-term Care Facilities'),(73,'Veterinary Clinics and Services'),(74,'Health, Pharmaceuticals, and Biotech Other'),(75,'Aerospace and Defense'),(76,'Automobiles, Boats and Motor Vehicles'),(77,'Chemicals and Petrochemicals'),(78,'Concrete, Glass and Building Materials'),(79,'Farming and Mining Machinery and Equipment'),(80,'Food and Dairy Product Manufacturing and Packaging'),(81,'Furniture Manufacturing'),(82,'Metals Manufacturing'),(83,'Nonalcoholic Beverages'),(84,'Paper and Paper Products'),(85,'Plastics and Rubber Manufacturing'),(86,'Textiles, Apparel and Accessories'),(87,'Tools, Hardware and Light Machinery'),(88,'Manufacturing Other'),(89,'Motion Picture Exhibitors'),(90,'Motion Picture and Recording Producers'),(91,'Newspapers, Books, and Periodicals'),(92,'Performing Arts'),(93,'Radio, Television Broadcasting'),(94,'Media and Entertainment Other'),(95,'Advocacy Organizations'),(96,'Charitable Organizations and Foundations'),(97,'Professional Associations'),(98,'Religious Organizations'),(99,'Social and Membership Organizations'),(100,'Trade Groups and Labor Unions'),(101,'Non-profit Other'),(102,'Architecture, Engineering and Design'),(103,'Construction Equipment and Supplies'),(104,'Construction and Remodeling'),(105,'Property Leasing and Management'),(106,'Real Estate Agents and Appraisers'),(107,'Real Estate Investment and Development'),(108,'Real Estate and Construction Other'),(109,'Automobile Dealers'),(110,'Automobile Parts and Supplies'),(111,'Beer, Wine and Liquor Stores'),(112,'Clothing and Shoe Stores'),(113,'Department Stores'),(114,'Florist'),(115,'Furniture Stores'),(116,'Gasoline Stations'),(117,'Grocery and Specialty Stores'),(118,'Hardware and Building Material Dealers'),(119,'Jewelry, Luggage, and Leather Goods'),(120,'Office Supplies Stores'),(121,'Restaurants and Bars'),(122,'Sporting Goods, Hobby, Books and Music Stores'),(123,'Retail Others'),(124,'Data Analytics, Management, and Internet'),(125,'E-Commerce and Internet Business'),(126,'Games and Gaming'),(127,'Software'),(128,'Software and Internet Other'),(129,'Cable and Television Providers'),(130,'Telecommunications Equipment and Accessories'),(131,'Telephone Service Providers and Carriers'),(132,'Video and Teleconferencing'),(133,'Wireless and Mobile'),(134,'Telecommunications Other'),(135,'Air Couriers and Caro Services'),(136,'Airport, Harbor, and Terminal Operations'),(137,'Freight Hauling (Rail and Truck)'),(138,'Marine and Inland Shipping'),(139,'Moving Companies and Services'),(140,'Postal, Express Delivery and Couriers'),(141,'Warehousing and Storage'),(142,'Transportation and Storage Other'),(143,'Amusement Parks and Attractions'),(144,'Cruise Ship Operations'),(145,'Gambling and Gaming Lodging'),(146,'Participatory Sports and Recreation'),(147,'Passenger Airlines'),(148,'Rental Cars'),(149,'Resorts and Casinos'),(150,'Spectator Sports and Teams'),(151,'Taxi, Buses and Transit Systems'),(152,'Travel Agents and Services'),(153,'Travel, Recreations and Leisure Other'),(154,'Apparel Wholesalers'),(155,'Automobile Parts Wholesalers'),(156,'Food and Beverages Wholesalers'),(157,'Chemicals and Plastics Wholesalers'),(158,'Grocery and Food Wholesalers'),(159,'Lumber and Construction Materials Wholesalers'),(160,'Metal and Mineral Wholesalers'),(161,'Office Equipment and Suppliers Wholesalers'),(162,'Petroleum Products Wholesalers');
/*!40000 ALTER TABLE `sub_industry_master` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-03-08  8:31:16
