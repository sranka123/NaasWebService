-- MySQL dump 10.13  Distrib 5.7.12, for Win64 (x86_64)
--
-- Host: naas-demo.co6qvh4uzonj.us-east-1.rds.amazonaws.com    Database: naas_db
-- ------------------------------------------------------
-- Server version	5.6.27-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `sms_content`
--

DROP TABLE IF EXISTS `sms_content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sms_content` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `content` varchar(255) DEFAULT NULL,
  `create_user` varchar(200) DEFAULT NULL,
  `update_user` varchar(200) DEFAULT NULL,
  `create_date` datetime DEFAULT NULL,
  `update_date` datetime DEFAULT NULL,
  `contentStatus` int(11) DEFAULT NULL,
  `lastRejectReason` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sms_content`
--

LOCK TABLES `sms_content` WRITE;
/*!40000 ALTER TABLE `sms_content` DISABLE KEYS */;
INSERT INTO `sms_content` VALUES (1,'first_sms','Austin Infiniti - 30K Promotion\n\nTake advantage of this promotion for buy 3 and get 1 tire free.\n\nPromo cod: 30KDEC2016\n','Sashi Rajan','sashi_v@hotmail.com','2016-05-22 05:38:39','2016-12-07 21:00:09',2,NULL),(2,'second_sms','second SMS','Sashi Rajan','sashi_v@hotmail.com','2016-05-22 05:38:39','2016-11-02 09:01:57',2,NULL),(3,'Sample 06','This sms was empty...','Sashi Rajan','Sashi Rajan','2016-05-25 22:24:46','2016-05-25 23:16:29',0,NULL),(4,'Sample 07','Sample sms text','Sashi Rajan','Sashi Rajan','2016-05-25 22:30:05','2016-05-25 23:17:04',0,NULL),(5,'Sample 02','Austin Infiniti Service\n\n30,000 Mile Special for $59.95\n\nPROMO CODE: 30KMAY2016\n\nhttp://demo.safelogicsolutions/naas/emails/email30k17159.htm','Sashi Rajan','Sashi Rajan','2016-05-25 22:38:41','2016-05-26 00:01:08',0,NULL),(6,'Sample 03','Sample another sms content text...','Sashi Rajan','Sashi Rajan','2016-05-25 22:44:55','2016-05-25 22:44:55',0,NULL),(7,'Emily SMS','This is a sample SMS for Emily.\n\nHope she gets this message.','Sashi Rajan','sashi_v@hotmail.com','2016-05-26 00:48:46','2016-10-05 00:05:48',2,NULL),(8,'Test SMS for WFLCHK','Test SMS for WFLCHK','sashi_v@hotmail.com','Sashi Rajan','2016-09-25 17:33:08','2016-09-25 17:33:08',2,NULL),(9,'SMS test for alignment','SMS test for alignment','sashi_v@hotmail.com','Sashi Rajan','2016-09-25 17:39:54','2016-09-25 17:39:54',2,NULL),(10,'test for feroz','test for feroz','sashi_v@hotmail.com','Sashi Rajan','2016-10-13 01:27:47','2016-10-13 01:27:47',2,NULL),(11,'test SMS by Feroz','test SMS by Feroz','fero90@yahoo.com','Feroz Khan','2016-10-14 02:21:23','2016-10-14 02:21:23',2,NULL),(12,'','From Austin Infiniti \nWe want to give you $150 for your old tires no matter their condition\nvisit us at goo.gl/mX5euX or contact us at 512 453 0660 ','sashi_v@hotmail.com','sashi_v@hotmail.com','2017-02-07 21:20:21','2017-02-08 15:11:53',2,NULL);
/*!40000 ALTER TABLE `sms_content` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-03-08  8:31:14
