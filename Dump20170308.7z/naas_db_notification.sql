-- MySQL dump 10.13  Distrib 5.7.12, for Win64 (x86_64)
--
-- Host: naas-demo.co6qvh4uzonj.us-east-1.rds.amazonaws.com    Database: naas_db
-- ------------------------------------------------------
-- Server version	5.6.27-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `notification`
--

DROP TABLE IF EXISTS `notification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notification` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `dateTime` datetime DEFAULT NULL,
  `sendEmail` bit(1) NOT NULL,
  `sendSms` bit(1) NOT NULL,
  `ach_id` bigint(20) DEFAULT NULL,
  `email_id` bigint(20) DEFAULT NULL,
  `sms_id` bigint(20) DEFAULT NULL,
  `group_id` bigint(20) DEFAULT NULL,
  `create_user` varchar(200) DEFAULT NULL,
  `update_user` varchar(200) DEFAULT NULL,
  `create_date` datetime DEFAULT NULL,
  `update_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_mhsj0ux1n9ex7prk5ky0k3jhl` (`ach_id`),
  KEY `FK_r32efw9dgcchc2beo5na8ailb` (`group_id`),
  KEY `FKbn9v0m1n7seyo8d0npf2j3fpi` (`email_id`),
  KEY `FKim28coubcmg9hu6sl513vdj0e` (`sms_id`),
  CONSTRAINT `FK_mhsj0ux1n9ex7prk5ky0k3jhl` FOREIGN KEY (`ach_id`) REFERENCES `account_holder_master` (`ach_id`),
  CONSTRAINT `FKbn9v0m1n7seyo8d0npf2j3fpi` FOREIGN KEY (`email_id`) REFERENCES `email_content` (`id`),
  CONSTRAINT `FKim28coubcmg9hu6sl513vdj0e` FOREIGN KEY (`sms_id`) REFERENCES `sms_content` (`id`),
  CONSTRAINT `notification_ibfk_1` FOREIGN KEY (`group_id`) REFERENCES `customer_group` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=86 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notification`
--

LOCK TABLES `notification` WRITE;
/*!40000 ALTER TABLE `notification` DISABLE KEYS */;
INSERT INTO `notification` VALUES (6,'Notification_20161506175419','2016-06-15 17:55:03','','',1,3,6,NULL,NULL,NULL,NULL,NULL),(7,'Notification_20161506180118','2016-06-15 18:01:36','','',1,3,1,NULL,NULL,NULL,NULL,NULL),(8,'Notification_20161506180451','2016-06-15 18:05:13','','',1,3,1,NULL,NULL,NULL,NULL,NULL),(9,'Notification_20161506193902','2016-06-15 19:40:06','','',1,3,5,11,NULL,NULL,NULL,NULL),(10,'Feroz-Test-Notification','2016-08-31 17:23:44','','',1,3,1,12,'sashi_v@hotmail.com',NULL,'2016-08-31 17:24:16',NULL),(11,'Feroz_Test_Notification','2016-09-01 02:14:22','','',1,6,4,13,'sashi_v@hotmail.com',NULL,'2016-09-01 02:15:37',NULL),(12,'Notification_20160809012316','2016-09-08 01:32:07','','',1,3,1,14,'sashi_v@hotmail.com',NULL,'2016-09-08 01:32:31',NULL),(13,'Notification_20161509051845','2016-09-15 05:19:15','','',1,3,1,15,'sashi_v@hotmail.com',NULL,'2016-09-15 05:19:25',NULL),(14,'Notification_20161609005021','2016-09-16 00:50:47','','',1,3,1,16,'sashi_v@hotmail.com',NULL,'2016-09-16 00:50:55',NULL),(15,'Notification_20161609005055','2016-09-16 00:53:13','','',1,3,1,12,'sashi_v@hotmail.com',NULL,'2016-09-16 00:53:22',NULL),(16,'Notification_20161609005321','2016-09-16 00:55:37','','',1,3,1,NULL,'sashi_v@hotmail.com',NULL,'2016-09-16 00:55:44',NULL),(17,'Notification_20161609114842','2016-09-16 11:49:00','','',1,3,1,NULL,'sashi_v@hotmail.com',NULL,'2016-09-16 11:49:08',NULL),(18,'Notification_20161609114908','2016-09-16 11:54:28','','',1,3,1,NULL,'sashi_v@hotmail.com',NULL,'2016-09-16 11:54:35',NULL),(19,'Feroz_Test_Notification 2','2016-09-17 19:40:33','','',1,3,1,NULL,'sashi_v@hotmail.com',NULL,'2016-09-17 19:40:43',NULL),(20,'Notification_20162609223950','2016-09-26 22:40:18','','',1,3,1,NULL,'sashi_v@hotmail.com',NULL,'2016-09-26 22:40:28',NULL),(21,'Notification_20162709084213','2016-09-27 08:42:41','','',1,3,1,NULL,'sashi_v@hotmail.com',NULL,'2016-09-27 08:42:49',NULL),(22,'Notification_20162709084249','2016-09-27 08:47:16','','',1,3,1,NULL,'sashi_v@hotmail.com',NULL,'2016-09-27 08:47:26',NULL),(23,'Notification_20162709084726','2016-09-27 08:52:35','','',1,3,1,NULL,'sashi_v@hotmail.com',NULL,'2016-09-27 08:52:43',NULL),(24,'Notification_20162709085242','2016-09-27 08:59:01','','',1,3,1,NULL,'sashi_v@hotmail.com',NULL,'2016-09-27 08:59:07',NULL),(25,'Notification_20162709215339','2016-09-27 21:54:06','','',1,3,1,NULL,'sashi_v@hotmail.com',NULL,'2016-09-27 21:54:19',NULL),(26,'Notification_20162709223936','2016-09-27 22:39:55','','',1,3,1,NULL,'sashi_v@hotmail.com',NULL,'2016-09-27 22:40:05',NULL),(27,'Notification_20162809020824','2016-09-28 02:09:44','','\0',1,3,NULL,NULL,'sashi_v@hotmail.com',NULL,'2016-09-28 02:09:49',NULL),(28,'Notification_20162809020950','2016-09-28 02:16:11','','',1,3,1,NULL,'sashi_v@hotmail.com',NULL,'2016-09-28 02:16:18',NULL),(29,'Notification_20162909010035','2016-09-29 01:01:20','','\0',1,6,NULL,NULL,'sashi_v@hotmail.com',NULL,'2016-09-29 01:01:28',NULL),(30,'Notification_20162909010128','2016-09-29 01:02:34','\0','',1,NULL,8,NULL,'sashi_v@hotmail.com',NULL,'2016-09-29 01:02:41',NULL),(31,'Notification_20162909010241','2016-09-29 01:04:25','','',1,3,1,NULL,'sashi_v@hotmail.com',NULL,'2016-09-29 01:04:28',NULL),(32,'Notification_20162909010428','2016-09-29 01:11:25','','',1,3,1,NULL,'sashi_v@hotmail.com',NULL,'2016-09-29 01:11:29',NULL),(33,'Notification_20162909011129','2016-09-29 01:12:25','','',1,3,1,NULL,'sashi_v@hotmail.com',NULL,'2016-09-29 01:12:30',NULL),(34,'My Notification in oct 2016','2016-10-01 18:19:44','','',1,3,1,NULL,'sashi_v@hotmail.com',NULL,'2016-10-01 18:20:30',NULL),(35,'Notification_for_Vijay','2016-10-04 14:43:01','','',1,3,1,NULL,'sashi_v@hotmail.com',NULL,'2016-10-04 14:43:29',NULL),(36,'Notification sashi demo for sms','2016-10-08 14:51:51','','',1,3,1,NULL,'sashi_v@hotmail.com',NULL,'2016-10-08 14:51:59',NULL),(37,'Notification_20160910010307','2016-10-09 01:04:27','','',2,5,8,NULL,'fero90@yahoo.com',NULL,'2016-10-09 01:04:37',NULL),(38,'Notification_20161210230626','2016-10-12 23:07:25','','\0',1,3,NULL,NULL,'sashi_v@hotmail.com',NULL,'2016-10-12 23:07:31',NULL),(39,'Notification_20161210230731','2016-10-12 23:15:03','','\0',1,3,NULL,NULL,'sashi_v@hotmail.com',NULL,'2016-10-12 23:15:13',NULL),(40,'Notification_20161210231513','2016-10-12 23:29:42','','\0',1,3,NULL,NULL,'sashi_v@hotmail.com',NULL,'2016-10-12 23:29:47',NULL),(41,'Notification_20161210232947','2016-10-12 23:33:33','','\0',1,3,NULL,NULL,'sashi_v@hotmail.com',NULL,'2016-10-12 23:33:39',NULL),(42,'Notification_20161210233339','2016-10-12 23:35:07','\0','',1,NULL,1,NULL,'sashi_v@hotmail.com',NULL,'2016-10-12 23:35:13',NULL),(43,'Notification_20161210233513','2016-10-12 23:46:03','\0','',1,NULL,1,NULL,'sashi_v@hotmail.com',NULL,'2016-10-12 23:46:08',NULL),(44,'Notification_20161310001633','2016-10-13 00:16:50','','',1,3,1,NULL,'sashi_v@hotmail.com',NULL,'2016-10-13 00:16:57',NULL),(45,'Notification_20161310012016','2016-10-13 01:23:10','','',1,3,1,NULL,'sashi_v@hotmail.com',NULL,'2016-10-13 01:23:45',NULL),(46,'Notification_20161310012345','2016-10-13 01:24:24','','',1,3,1,NULL,'sashi_v@hotmail.com',NULL,'2016-10-13 01:24:28',NULL),(48,'Notification_20161510041707',NULL,'','',NULL,3,1,NULL,'sashi_v@hotmail.com',NULL,'2016-10-15 04:17:54',NULL),(52,'Notification_20161610001910','2016-10-16 00:20:46','','\0',1,3,NULL,NULL,'sashi_v@hotmail.com',NULL,'2016-10-16 00:20:54',NULL),(53,'Notification_20161610002054','2016-10-16 00:26:35','','\0',1,3,NULL,NULL,'sashi_v@hotmail.com',NULL,'2016-10-16 00:26:49',NULL),(54,'Notification_20161610002649','2016-10-16 00:28:29','','',1,5,9,NULL,'sashi_v@hotmail.com',NULL,'2016-10-16 00:28:34',NULL),(55,'Notification_20161610172345','2016-10-16 17:24:01','','\0',1,3,NULL,NULL,'sashi_v@hotmail.com',NULL,'2016-10-16 17:24:13',NULL),(56,'Notification_20161610172413','2016-10-16 17:31:04','','\0',1,3,NULL,NULL,'sashi_v@hotmail.com',NULL,'2016-10-16 17:31:17',NULL),(57,'Notification_20161710224039','2016-10-17 22:41:54','','\0',1,6,NULL,NULL,'sashi_v@hotmail.com',NULL,'2016-10-17 22:42:08',NULL),(58,'Notification_20161710224209','2016-10-17 22:45:57','','\0',1,5,NULL,NULL,'sashi_v@hotmail.com',NULL,'2016-10-17 22:46:03',NULL),(59,'Notification_20161810013630','2016-10-18 01:37:07','','\0',1,3,NULL,NULL,'sashi_v@hotmail.com',NULL,'2016-10-18 01:37:29',NULL),(60,'Notification_20161810013729','2016-10-18 01:50:15','','\0',1,3,NULL,NULL,'sashi_v@hotmail.com',NULL,'2016-10-18 01:50:48',NULL),(61,'Notification_20161810015047','2016-10-18 01:52:59','','',1,3,1,NULL,'sashi_v@hotmail.com',NULL,'2016-10-18 01:53:34',NULL),(62,'Notification_20162210005748','2016-10-22 00:58:15','','',1,3,1,NULL,'sashi_v@hotmail.com',NULL,'2016-10-22 00:58:20',NULL),(63,'Notification_20162310172226','2016-10-23 17:24:24','','',1,7,7,NULL,'sashi_v@hotmail.com',NULL,'2016-10-23 17:24:35',NULL),(64,'Notification_20162310184612','2016-10-23 18:46:28','','\0',1,4,NULL,NULL,'sashi_v@hotmail.com',NULL,'2016-10-23 18:46:36',NULL),(65,'Notification_20163110233431','2016-10-31 23:34:49','','',1,3,1,NULL,'sashi_v@hotmail.com',NULL,'2016-10-31 23:34:54',NULL),(66,'Notification_20160411155858','2016-11-04 15:59:12','','',1,3,1,NULL,'sashi_v@hotmail.com',NULL,'2016-11-04 15:59:18',NULL),(67,'Notification_20160411182443','2016-11-04 18:24:57','','\0',1,3,NULL,NULL,'sashi_v@hotmail.com',NULL,'2016-11-04 18:25:05',NULL),(68,'Notification_20160411182505','2016-11-04 18:31:08','','\0',1,3,NULL,NULL,'sashi_v@hotmail.com',NULL,'2016-11-04 18:31:14',NULL),(69,'Notification_20160411183114','2016-11-04 18:33:56','','\0',1,4,NULL,NULL,'sashi_v@hotmail.com',NULL,'2016-11-04 18:34:01',NULL),(70,'Notification_20160411183400','2016-11-04 18:39:15','','\0',1,5,NULL,NULL,'sashi_v@hotmail.com',NULL,'2016-11-04 18:39:20',NULL),(71,'Notification_20160411183920','2016-11-04 18:51:52','','\0',1,3,NULL,NULL,'sashi_v@hotmail.com',NULL,'2016-11-04 18:51:57',NULL),(72,'Notification_20160411234205','2016-11-04 23:42:38','','\0',1,7,NULL,NULL,'sashi_v@hotmail.com',NULL,'2016-11-04 23:42:49',NULL),(73,'Notification_20160511111446','2016-11-05 11:15:02','','\0',1,3,NULL,NULL,'sashi_v@hotmail.com',NULL,'2016-11-05 11:15:12',NULL),(74,'Notification_20160511111512','2016-11-05 11:16:42','','\0',1,5,NULL,NULL,'sashi_v@hotmail.com',NULL,'2016-11-05 11:16:47',NULL),(75,'Notification_20160511111647','2016-11-05 11:32:25','','\0',1,3,NULL,NULL,'sashi_v@hotmail.com',NULL,'2016-11-05 11:32:30',NULL),(76,'Notification_20160511113230','2016-11-05 11:41:54','','\0',1,6,NULL,NULL,'sashi_v@hotmail.com',NULL,'2016-11-05 11:42:00',NULL),(77,'Notification_20160511131228','2016-11-05 13:12:54','','\0',1,4,NULL,NULL,'sashi_v@hotmail.com',NULL,'2016-11-05 13:13:12',NULL),(78,'Notification_20160511192337','2016-11-05 19:23:51','','\0',1,7,NULL,NULL,'sashi_v@hotmail.com',NULL,'2016-11-05 19:23:57',NULL),(79,'Notification_20160511192356','2016-11-05 19:25:33','','\0',1,3,NULL,NULL,'sashi_v@hotmail.com',NULL,'2016-11-05 19:25:39',NULL),(80,'Notification_20160611033658','2016-11-06 03:37:16','','\0',1,7,NULL,NULL,'sashi_v@hotmail.com',NULL,'2016-11-06 03:37:25',NULL),(81,'Notification_20160711104512','2016-11-07 10:45:36','','',1,6,8,NULL,'sashi_v@hotmail.com',NULL,'2016-11-07 10:45:41',NULL),(82,'Notification_20160911174903','2016-11-09 17:53:49','','\0',1,3,NULL,NULL,'sashi_v@hotmail.com',NULL,'2016-11-09 17:56:05',NULL),(83,'Notification_20160911180852','2016-11-09 18:09:09','','\0',1,5,NULL,NULL,'sashi_v@hotmail.com',NULL,'2016-11-09 18:09:14',NULL),(84,'30 K December Notification','2016-12-07 21:10:31','','',1,3,1,NULL,'sashi_v@hotmail.com',NULL,'2016-12-07 21:11:08',NULL),(85,'Notification_20170802131706','2017-02-08 13:17:25','\0','',1,NULL,1,NULL,'sashi_v@hotmail.com',NULL,'2017-02-08 13:17:30',NULL);
/*!40000 ALTER TABLE `notification` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-03-08  8:31:19
